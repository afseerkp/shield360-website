<#
.SYNOPSIS
    Removes the HOT System Agent (agent and tray) from this PC. Runs silently.

.DESCRIPTION
    Stops and deletes the FleetPulseAgent service, stops the tray in every session, removes the sign-in entry, the
    Apps & features entry and the install folder. Unless -KeepData is given it also deletes C:\ProgramData\FleetPulse
    (the agent's key, queue and unsent reports), so a later install enrolls the PC again.
    The PC stays in the dashboard with its history: retire it under Admin > Machines & keys.

    Exit codes: 0 removed (or nothing to remove), 1 failed, 2 not run as Administrator.

.EXAMPLE
    .\Uninstall-FleetPulse.ps1
.EXAMPLE
    .\Uninstall-FleetPulse.ps1 -KeepData
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$InstallDir = (Join-Path $env:ProgramFiles 'FleetPulse'),
    [switch]$KeepData
)

$ErrorActionPreference = 'Stop'
$ServiceName = 'FleetPulseAgent'
$DataDir = Join-Path $env:ProgramData 'FleetPulse'

$admin = (New-Object Security.Principal.WindowsPrincipal ([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin -and -not $WhatIfPreference) {
    [Console]::Error.WriteLine("HOT System Agent uninstall: run this as Administrator (or as SYSTEM from your deployment tool).")
    exit 2
}

try {
    if ((Get-Service $ServiceName -ErrorAction SilentlyContinue) -and $PSCmdlet.ShouldProcess($ServiceName, 'Stop and delete service')) {
        Stop-Service $ServiceName -Force -ErrorAction SilentlyContinue
        (Get-Service $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
        & sc.exe delete $ServiceName | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "sc.exe delete failed (exit $LASTEXITCODE)" }
    }

    if ($PSCmdlet.ShouldProcess('FleetPulse.Tray', 'Stop tray and remove it from sign-in')) {
        Get-Process FleetPulse.Tray -ErrorAction SilentlyContinue | Stop-Process -Force
        Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'FleetPulseTray' -ErrorAction SilentlyContinue
        Remove-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FleetPulse' -Recurse -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    }

    # This script may itself live in the install folder; PowerShell has already read it, so deleting it is fine.
    if ((Test-Path $InstallDir) -and $PSCmdlet.ShouldProcess($InstallDir, 'Delete install folder')) {
        Remove-Item $InstallDir -Recurse -Force
    }

    if (-not $KeepData -and (Test-Path $DataDir) -and $PSCmdlet.ShouldProcess($DataDir, 'Delete agent data (key, queue, reports)')) {
        Remove-Item $DataDir -Recurse -Force
    }

    if ($WhatIfPreference) {
        Write-Host "Checks passed. Nothing was changed (-WhatIf)."
    }
    else {
        Write-Host "HOT System Agent removed$(if ($KeepData) { ' (agent data kept)' }). Retire this PC in the dashboard under Admin > Machines & keys."
    }
    exit 0
}
catch {
    [Console]::Error.WriteLine("HOT System Agent uninstall failed: $($_.Exception.Message)")
    exit 1
}
