<#
.SYNOPSIS
    Installs or upgrades the HOT System Agent (agent and tray) on this PC. Runs silently; suitable for Intune, Group Policy,
    ConfigMgr or a remote PowerShell session.

.DESCRIPTION
    - Copies the agent and tray from the package's bin folder to the install folder (default C:\Program Files\FleetPulse).
    - Writes the agent's settings (readable only by SYSTEM and Administrators) and, on a first install, the enrollment
      token. The agent enrolls itself on first start and deletes the token.
    - Registers the "FleetPulseAgent" service (LocalSystem, delayed automatic start, restarts after a failure).
    - Starts the tray at every user's sign-in, and now for the signed-in user when run interactively.
    - Adds an entry to Apps & features with silent uninstall, which Intune can also use as its detection rule.
    Re-running it upgrades in place; an enrolled PC keeps its identity, key and data.

    Exit codes: 0 installed (or would be, with -WhatIf), 1 failed, 2 bad parameters or not run as Administrator.
    Log: C:\ProgramData\FleetPulse\install.log

.PARAMETER ServerUrl
    The agent address of the HOT System Agent server, e.g. https://agents.contoso.com (behind Cloudflare Tunnel).
.PARAMETER EnrollmentToken
    A wave token from the dashboard (Admin > Enrollment). Needed on a first install; ignored once the PC is enrolled.
.PARAMETER AllowHttp
    Accept an http:// ServerUrl. Only for a short pilot on a trusted network: requests are signed but not encrypted.
.PARAMETER AllowUnsignedTray
    Let the agent talk to a tray that is not Authenticode-signed (development and pilot builds). Leave off once you
    sign the tray.
.PARAMETER TrayPublisher
    When set, the tray's signing certificate subject must contain this, e.g. "O=Contoso Ltd".
.PARAMETER KillList
    Process names the KillProcess command may end on this PC, e.g. teams.exe,outlook.exe. Empty means none.
.PARAMETER NoScreenshots
    Turn screenshots off in Report an Issue.

.EXAMPLE
    .\Install-FleetPulse.ps1 -ServerUrl https://agents.contoso.com -EnrollmentToken fpe_xxxxxxxx -AllowUnsignedTray
.EXAMPLE
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File Install-FleetPulse.ps1 -ServerUrl https://agents.contoso.com -EnrollmentToken fpe_xxx -AllowUnsignedTray
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)] [string]$ServerUrl,
    [string]$EnrollmentToken,
    [string]$InstallDir = (Join-Path $env:ProgramFiles 'FleetPulse'),
    [string]$CfAccessClientId,
    [string]$CfAccessClientSecret,
    [string[]]$KillList = @(),
    [string]$TrayPublisher,
    [switch]$NoScreenshots,
    [switch]$AllowUnsignedTray,
    [switch]$AllowHttp,
    [int]$WaitSeconds = 60
)

$ErrorActionPreference = 'Stop'
$ServiceName = 'FleetPulseAgent'
$DataDir = Join-Path $env:ProgramData 'FleetPulse'
$Source = Join-Path $PSScriptRoot 'bin'
$Version = if (Test-Path (Join-Path $PSScriptRoot 'version.txt')) { (Get-Content (Join-Path $PSScriptRoot 'version.txt') -Raw).Trim() } else { 'unknown' }
$ArpKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FleetPulse'
$RunKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'

function Fail([int]$code, [string]$message) {
    [Console]::Error.WriteLine("HOT System Agent install: $message")
    exit $code
}

function Write-Utf8([string]$path, [string]$text) {
    [IO.File]::WriteAllText($path, $text, (New-Object Text.UTF8Encoding $false))
}

# Only SYSTEM and Administrators: the settings hold the Cloudflare Access secret, the data folder the key and token.
function Protect-Path([string]$path) {
    $isDir = Test-Path $path -PathType Container
    $acl = if ($isDir) { New-Object Security.AccessControl.DirectorySecurity } else { New-Object Security.AccessControl.FileSecurity }
    $acl.SetAccessRuleProtection($true, $false)
    $inherit = if ($isDir) { 'ContainerInherit, ObjectInherit' } else { 'None' }
    foreach ($sid in 'S-1-5-18', 'S-1-5-32-544') {
        $id = New-Object Security.Principal.SecurityIdentifier $sid
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule $id, 'FullControl', $inherit, 'None', 'Allow'))
    }
    Set-Acl -Path $path -AclObject $acl
}

# ---------- checks ----------
$uri = $null
if (-not [Uri]::TryCreate($ServerUrl, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -notin 'https', 'http') {
    Fail 2 "ServerUrl must be an absolute https:// address, e.g. https://agents.contoso.com"
}
if ($uri.Scheme -eq 'http' -and -not $AllowHttp) {
    Fail 2 "ServerUrl uses http://. Agent traffic would not be encrypted; use https (Cloudflare Tunnel) or pass -AllowHttp for a short pilot on a trusted network."
}
if ($EnrollmentToken -and $EnrollmentToken -notmatch '^fpe_[A-Za-z0-9_-]{20,}$') {
    Fail 2 "EnrollmentToken does not look like a HOT System Agent token (fpe_...). Copy it from the dashboard: Admin > Enrollment."
}
if ([bool]$CfAccessClientId -ne [bool]$CfAccessClientSecret) {
    Fail 2 "Give both -CfAccessClientId and -CfAccessClientSecret, or neither."
}
foreach ($f in 'FleetPulse.Agent.exe', 'e_sqlite3.dll', 'FleetPulse.Tray.exe') {
    if (-not (Test-Path (Join-Path $Source $f))) { Fail 2 "The package is incomplete: bin\$f is missing next to this script." }
}
$admin = (New-Object Security.Principal.WindowsPrincipal ([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin -and -not $WhatIfPreference) {
    Fail 2 "Run this as Administrator (or as SYSTEM from your deployment tool)."
}

$enrolled = Test-Path (Join-Path $DataDir 'agent.key')
if (-not $enrolled -and -not $EnrollmentToken) {
    Fail 2 "This PC is not enrolled yet: pass -EnrollmentToken (Admin > Enrollment in the dashboard)."
}

if ($WhatIfPreference) {
    Write-Host "Checks passed. Would install HOT System Agent $Version to $InstallDir, server $ServerUrl, $(if ($enrolled) { 'keeping the existing enrollment' } else { 'enrolling with the token' })."
}

if (-not $WhatIfPreference) {
    New-Item -ItemType Directory -Force $DataDir | Out-Null
    Protect-Path $DataDir
    Start-Transcript -Path (Join-Path $DataDir 'install.log') -Append | Out-Null
}

try {
    Write-Host "HOT System Agent $Version -> $InstallDir (server $ServerUrl)"

    # ---------- stop what is running (upgrade) ----------
    $service = Get-Service $ServiceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne 'Stopped' -and $PSCmdlet.ShouldProcess($ServiceName, 'Stop service')) {
        Stop-Service $ServiceName -Force
        (Get-Service $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
    }
    if ($PSCmdlet.ShouldProcess('FleetPulse.Tray', 'Stop tray in all sessions')) {
        Get-Process FleetPulse.Tray -ErrorAction SilentlyContinue | Stop-Process -Force
        Start-Sleep -Milliseconds 500
    }

    # ---------- files ----------
    if ($PSCmdlet.ShouldProcess($InstallDir, 'Copy agent and tray')) {
        New-Item -ItemType Directory -Force $InstallDir | Out-Null
        Copy-Item (Join-Path $Source '*') $InstallDir -Force
        Copy-Item (Join-Path $PSScriptRoot 'Uninstall-FleetPulse.ps1') $InstallDir -Force
        Write-Utf8 (Join-Path $InstallDir 'version.txt') $Version
    }

    # ---------- settings ----------
    $agent = [ordered]@{
        ServerUrl            = $uri.AbsoluteUri.TrimEnd('/')
        DataDirectory        = $DataDir
        TrayPath             = (Join-Path $InstallDir 'FleetPulse.Tray.exe')
        TrayRequireSignature = (-not $AllowUnsignedTray)
        AllowScreenshots     = (-not $NoScreenshots)
        # -File passes "a.exe,b.exe" as one string; accept both forms.
        KillList             = @($KillList | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    }
    if ($TrayPublisher) { $agent.TrayPublisher = $TrayPublisher }
    if ($CfAccessClientId) { $agent.CfAccessClientId = $CfAccessClientId; $agent.CfAccessClientSecret = $CfAccessClientSecret }
    $settings = [ordered]@{
        Logging = @{ LogLevel = [ordered]@{ Default = 'Information'; 'Microsoft.Hosting.Lifetime' = 'Information'; 'System.Net.Http.HttpClient' = 'Warning' } }
        Agent   = $agent
    }
    $settingsPath = Join-Path $InstallDir 'appsettings.json'
    if ($PSCmdlet.ShouldProcess($settingsPath, 'Write agent settings')) {
        Write-Utf8 $settingsPath ($settings | ConvertTo-Json -Depth 5)
        Protect-Path $settingsPath
    }

    if ($enrolled) {
        if ($EnrollmentToken) { Write-Host "Already enrolled; the token is not needed and was not stored." }
    }
    elseif ($PSCmdlet.ShouldProcess((Join-Path $DataDir 'enroll.token'), 'Store enrollment token')) {
        $tokenPath = Join-Path $DataDir 'enroll.token'
        Write-Utf8 $tokenPath $EnrollmentToken
        Protect-Path $tokenPath
    }

    # ---------- service ----------
    $exe = Join-Path $InstallDir 'FleetPulse.Agent.exe'
    if ($PSCmdlet.ShouldProcess($ServiceName, 'Register service')) {
        if (-not (Get-Service $ServiceName -ErrorAction SilentlyContinue)) {
            New-Service -Name $ServiceName -BinaryPathName "`"$exe`"" -DisplayName 'HOT System Agent' -StartupType Automatic `
                -Description 'Monitors this PC''s health for IT and runs the maintenance tasks IT queues.' | Out-Null
        }
        else {
            & sc.exe config $ServiceName binPath= "`"$exe`"" obj= LocalSystem DisplayName= "HOT System Agent" | Out-Null
        }
        & sc.exe config $ServiceName start= delayed-auto | Out-Null
        # Restart after 1 min, 1 min, then 5 min; count resets after a day without failures. Also on non-crash failures.
        & sc.exe failure $ServiceName reset= 86400 actions= restart/60000/restart/60000/restart/300000 | Out-Null
        & sc.exe failureflag $ServiceName 1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "sc.exe could not set the recovery options (exit $LASTEXITCODE)" }
        Start-Service $ServiceName
    }

    # ---------- tray ----------
    $tray = Join-Path $InstallDir 'FleetPulse.Tray.exe'
    if ($PSCmdlet.ShouldProcess($RunKey, 'Start the tray at sign-in')) {
        New-ItemProperty -Path $RunKey -Name 'FleetPulseTray' -Value "`"$tray`"" -PropertyType String -Force | Out-Null
        $isSystem = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq 'S-1-5-18'
        if (-not $isSystem -and [Environment]::UserInteractive) {
            # explorer.exe starts it as the signed-in user without elevation, as at sign-in.
            Start-Process explorer.exe -ArgumentList "`"$tray`""
        }
    }

    # ---------- Apps & features ----------
    if ($PSCmdlet.ShouldProcess($ArpKey, 'Register in Apps & features')) {
        $uninstall = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $InstallDir 'Uninstall-FleetPulse.ps1')`""
        New-Item -Path $ArpKey -Force | Out-Null
        $values = @{
            DisplayName = 'HOT System Agent'; DisplayVersion = $Version; Publisher = 'HOT Systems'; InstallLocation = $InstallDir
            DisplayIcon = $tray; UninstallString = $uninstall; QuietUninstallString = $uninstall
        }
        foreach ($k in $values.Keys) { New-ItemProperty -Path $ArpKey -Name $k -Value $values[$k] -PropertyType String -Force | Out-Null }
        foreach ($k in 'NoModify', 'NoRepair') { New-ItemProperty -Path $ArpKey -Name $k -Value 1 -PropertyType DWord -Force | Out-Null }
    }

    if ($WhatIfPreference) { exit 0 }

    # ---------- verify ----------
    (Get-Service $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
    $keyPath = Join-Path $DataDir 'agent.key'
    $deadline = (Get-Date).AddSeconds($WaitSeconds)
    while (-not (Test-Path $keyPath) -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 2 }
    if (Test-Path $keyPath) {
        Write-Host "Installed and enrolled. The PC appears in the dashboard within a minute; if its name did not match the token's pattern, approve it under Admin > Machines & keys."
    }
    else {
        Write-Warning "Installed and running, but not enrolled after $WaitSeconds s. The agent keeps trying every 5 minutes. Check that $ServerUrl is reachable from this PC and that the token is still valid (Event Viewer > Application, source FleetPulseAgent)."
    }
    exit 0
}
catch {
    [Console]::Error.WriteLine("HOT System Agent install failed: $($_.Exception.Message)")
    exit 1
}
finally {
    if (-not $WhatIfPreference) { Stop-Transcript | Out-Null }
}
