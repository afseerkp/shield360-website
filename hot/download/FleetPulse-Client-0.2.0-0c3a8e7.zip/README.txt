HOT System Agent client package
===============================

Contents
  bin\FleetPulse.Agent.exe    the agent (Windows service, runs as SYSTEM; no .NET runtime needed)
  bin\e_sqlite3.dll           its local database engine
  bin\FleetPulse.Tray.exe     the tray app users see (self-contained; no .NET runtime needed)
  bin\appsettings.json        replaced by the installer with your settings
  Install-FleetPulse.ps1      install or upgrade (silent)
  Uninstall-FleetPulse.ps1    remove (silent)
  version.txt

Before you start
  1. The HOT System Agent server (FleetPulse API) must be reachable from client PCs, normally https://<your agent hostname> through Cloudflare
     Tunnel. (For a short pilot on a trusted network, http://<server>:5080 with -AllowHttp.)
  2. Create a wave token in the dashboard: Admin > Enrollment. Use the auto-approve pattern for your PC naming scheme,
     or approve each PC afterwards under Admin > Machines & keys.

Easiest: FleetPulseSetup.exe (built next to this folder)
  Double-click it and allow the Administrator prompt. It asks for the server address and the enrollment token.
  Silent:    FleetPulseSetup.exe /quiet /server=https://agents.contoso.com /token=fpe_xxxx /allowunsignedtray
  Remove:    FleetPulseSetup.exe /uninstall /quiet        (add /keepdata to keep the agent's key and queue)
  Check only: add /whatif.  All switches: FleetPulseSetup.exe /help
  A pre-configured build (Build-Package.ps1 -ServerUrl ... -EnrollmentToken ...) needs no switches at all; it contains a
  live token, so share it only with the people installing.
  The exe is not code-signed yet: on PCs that downloaded it, SmartScreen shows "Windows protected your PC"; choose
  More info > Run anyway, or sign it with your code-signing certificate (signtool) before distributing.

Install with the script instead (PowerShell as Administrator, in this folder)
  .\Install-FleetPulse.ps1 -ServerUrl https://agents.contoso.com -EnrollmentToken fpe_xxxx -AllowUnsignedTray

  Add -WhatIf first to check the settings without changing anything.

Install silently (Intune Win32 app, Group Policy startup script, ConfigMgr, remote PowerShell)
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File Install-FleetPulse.ps1 -ServerUrl https://agents.contoso.com -EnrollmentToken fpe_xxxx -AllowUnsignedTray

  Uninstall command:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File Uninstall-FleetPulse.ps1

  Intune detection rule: registry key HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FleetPulse exists
  (or the file C:\Program Files\FleetPulse\FleetPulse.Agent.exe).
  Exit codes: 0 success, 1 failed, 2 bad parameters / not Administrator. Log: C:\ProgramData\FleetPulse\install.log

Options
  -AllowUnsignedTray      needed until you sign FleetPulse.Tray.exe with your code-signing certificate; then drop it
                          (and optionally pass -TrayPublisher "O=Your Company") so only your signed tray is accepted.
  -KillList teams.exe,outlook.exe   apps IT may end remotely with KillProcess (default: none)
  -NoScreenshots          no screenshots in Report an Issue
  -CfAccessClientId / -CfAccessClientSecret   Cloudflare Access service token, if your tunnel requires one
  -InstallDir             default C:\Program Files\FleetPulse

Upgrading
  Run the install command from a newer package. The PC keeps its identity, key and queued data; no token is needed.

What it changes on the PC
  - C:\Program Files\FleetPulse (program files; appsettings.json readable only by SYSTEM and Administrators)
  - C:\ProgramData\FleetPulse   (agent key, local queue, reports; SYSTEM and Administrators only)
  - Service "FleetPulseAgent", shown as "HOT System Agent" (delayed automatic start, restarts itself after a failure)
  - HKLM\...\Run\FleetPulseTray (tray at every user's sign-in)
  - Apps & features entry "HOT System Agent" (publisher HOT Systems)

Troubleshooting
  - Not in the dashboard after a few minutes: Event Viewer > Windows Logs > Application, source FleetPulseAgent.
    Usual causes: the server address is not reachable from the PC, or the token expired or is used up.
  - Disk health (SMART) needs the service's SYSTEM account, which the installed service has.
