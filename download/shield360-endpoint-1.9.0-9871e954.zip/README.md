# Shield360 Endpoint

Shield360 Endpoint is an endpoint monitoring and security-posture tool for **Windows Servers and Windows PCs**. You install a lightweight agent on each machine. The agent reports to a central server, and administrators use the web console to monitor every endpoint and act on it.

```
 Windows Server / PC                         Management server                 Admin
┌─────────────────────┐   HTTPS (60s)   ┌──────────────────────────┐   browser  ┌──────────┐
│ Shield360Agent.ps1   │ ──check-in────▶ │ Node.js + SQLite         │ ◀───────── │ Console  │
│ (SYSTEM, sched task)│ ◀──actions───── │ alerts · audit · API     │            └──────────┘
└─────────────────────┘                 └──────────────────────────┘
```

## What the admin sees

| Area | Details |
|---|---|
| **Overview** | Endpoint counts, online/offline, % protected, alerts grouped by severity, machines that need attention |
| **Endpoints** | Searchable list with filters for servers, workstations, offline and at-risk machines. Shows live CPU, memory, disk, AV status, alerts and last-seen time |
| **System** | OS and build, domain, logged-on users (console and RDP), hardware, serial, last boot, 24-hour performance chart, disks |
| **Security** | Defender (real-time, tamper protection, signature age, mode), third-party AV, threat detections, firewall profiles, BitLocker, failed logons, UAC, RDP/NLA, local administrators |
| **Inventory** | Installed software, hotfixes, pending Windows Updates, stopped automatic services, listening ports, shared folders |
| **Actions** | Refresh inventory, Defender quick or full scan, update signatures, list processes, list connections, restart (users get a 2-minute warning), cancel restart |
| **Alerts** | Raised and resolved automatically, with an acknowledge button |
| **Audit log** | Logins, failed logins, actions, enrollments and token rotations |

## Licensing

A new server runs a **30-day trial for 25 endpoints**. To continue, install the license you received under **License** in the console (paste it or load the `.lic` file). The License page shows the customer, edition, seats used, expiry date and this server's **Server ID**, which you need when requesting a license.

- **Seats:** each enrolled endpoint uses one seat. When all seats are used, new endpoints can't enroll; remove unused endpoints or upgrade the license. The **Deploy agent** page shows the remaining seats.
- **Expiry:** a banner appears 30 days before expiry, and a 14-day grace period follows. After that the console enters **restricted mode**: new endpoints can't enroll and configuration can't be changed. **Endpoints stay protected**, and monitoring, alerts and response actions such as isolation keep working. Installing a renewed license ends restricted mode immediately.

Vendors: see [LICENSING.md](LICENSING.md) for issuing licenses. The `license-tools/` folder and its private key must never be shipped to customers.

## Endpoint groups

Use **Endpoint groups** to organise computers, for example *Finance Workstations*, *Production Servers* or *Domain Controllers*. **Each group has a protection policy**, so each group gets different antivirus, USB, website and isolation settings.

- **Every endpoint is in exactly one group.** New endpoints join **Default** unless an auto-assignment rule of another group matches. The Default group can't be renamed or deleted.
- **Auto-assignment rules (optional, per group):** endpoint type (Workstation, Server, Domain Controller) and/or hostname patterns with `*` and `?` wildcards, for example `FIN-*`. When both are set, both must match. Groups are checked in **priority** order (lowest number first) when a new endpoint enrolls. **Apply rules to endpoints in Default** sorts endpoints that are already enrolled.
- **Move endpoints:** on **Endpoints**, tick endpoints (or "select all" after filtering), choose a group in the bar that appears, and click **Move**. A single endpoint can also be moved from the **Protection** tab of its page.
- **Policy override:** on an endpoint's **Protection** tab you can choose a different policy for just that machine. The endpoint list labels it *(override)*. Choose *"Use the group's policy"* to remove it.
- **Effective policy** = the endpoint override if set, otherwise the group's policy. Changes reach endpoints at their next check-in (about 1 minute).
- **Deleting a group** moves its endpoints to Default. **Deleting a policy** switches groups that used it to the Default policy and removes overrides that pointed to it.

Example setup:

| Group | Auto-assignment | Policy |
|---|---|---|
| Domain Controllers | Type: Domain Controller | *Servers*: no auto-isolation, USB blocked |
| Production Servers | Type: Server | *Servers* |
| Finance Workstations | Type: Workstation, hostname `FIN-*` (priority 10) | *Finance*: USB read-only, file sharing and webmail blocked |
| Office Workstations | Type: Workstation (priority 50) | *Standard*: social media blocked, auto-isolation on |
| Default | (anything else) | *Default* |

When upgrading from 1.3 or earlier, existing endpoints move into the Default group. Any policy that was assigned directly to an endpoint is kept as an override.

## Antivirus and attack prevention

Shield360 uses **Microsoft Defender**, which is built into every supported Windows version, as its antivirus engine. Shield360 manages Defender centrally and adds its own prevention layer. You configure everything under **Protection policies** and assign a policy to each endpoint.

| Layer | What it does |
|---|---|
| **Antivirus** | Enforces real-time, behavior, script (AMSI), download and cloud protection, plus the cloud block level, PUA blocking and signature update interval. Runs a daily quick scan and manages scan exclusions |
| **Virus definitions** | Keeps every endpoint on the latest Microsoft definitions, with a server mirror for endpoints that can't reach Microsoft (see below) |
| **Exploit protection** | Applies 19 attack surface reduction (ASR) rules, each set to Block, Audit or Off. Examples: LSASS credential theft, Office macro abuse, obfuscated scripts, PsExec/WMI lateral movement, webshells, USB malware, rebooting into Safe Mode, copied system tools |
| **Ransomware** | Advanced ransomware protection rule, plus **controlled folder access**: untrusted programs can't change files in Documents, Desktop, Pictures and any extra folders you add. You set allowed business apps in the policy. Blocks and audit-mode findings appear as *Ransomware blocked* or *Ransomware (audit only)* attack events, and ransomware activity can isolate the PC automatically. New policies use **Block**: pilot with Audit, add the business apps that show up in Attack events to the allowed apps, then switch to Block. |
| **Malicious sites / C2** | Defender network protection, plus blocklisted domains (hosts file) and IPs (firewall) |
| **Brute-force blocking** | Watches failed logons (RDP, SMB and others) and automatically blocks the attacking IP in the firewall for a set time, with an allowlist for trusted IPs |
| **Blocklist (IOCs)** | SHA-256 file hashes (matching programs are killed and quarantined), IPs/CIDRs and domains. You can paste whole threat feeds |
| **USB device control** | USB storage set to Allow, Read-only or Block per policy (see below) |
| **Website blocking** | Blocked websites per policy in Edge, Chrome and Firefox, plus system-wide (see below) |
| **Hardening** | Keeps the firewall on, blocks inbound by default, and disables SMBv1, LLMNR and WDigest. Requires NLA for RDP, turns on PowerShell logging, and can enable LSA protection |
| **Attack detection** | Watches event logs for log clearing, new accounts, privileged group changes, suspicious services, ASR/ransomware/network blocks, Defender being turned off and suspicious PowerShell |
| **Automatic isolation** | When an endpoint is compromised, it cuts itself off from the internet and the network (see below) |
| **Response actions** | Isolate/release, kill a process, quarantine a file, scan a path, remove threats, unblock an IP |

The agent re-applies the policy every 15 minutes, which undoes local tampering. Each endpoint reports **compliance** for every setting. Use **Report only** mode to pilot a policy: the agent measures compliance but changes nothing. Settings that Group Policy or Intune also manage take precedence, and they show as non-compliant.

### Ransomware resilience: recovery and readiness

Prevention can fail, so Shield360 also helps make sure data can be **recovered**. You set these up per policy under **Recovery & backup**:

| Setting | What it does |
|---|---|
| **Scheduled restore points** | Creates Windows shadow copies of the chosen drives every N hours. To restore a file, right-click it (or its folder) and choose **Properties → Previous Versions**. |
| **OneDrive folder protection** | Silently moves users' Desktop, Documents and Pictures into OneDrive (Microsoft Known Folder Move; needs your Microsoft 365 tenant ID and users signed in to OneDrive). After an attack, restore the whole OneDrive to an earlier time: **OneDrive → Settings → Restore your OneDrive** (up to 30 days back). Workstations only. |
| **Backup monitoring** | Raises an alert when an endpoint has no backup or restore point newer than the limit (default 48 h). On workstations, user folders in OneDrive count as covered. |

Each endpoint reports its **recovery points**: restore points per drive, the last successful Windows Server Backup, and which signed-in users have their folders in OneDrive.

The **Ransomware readiness** page scores every endpoint on 10 measures: real-time protection, up-to-date definitions, the ransomware rule, controlled folder access in Block, automatic isolation, SMBv1 off, Remote Desktop off or with NLA, firewall on, signed-in users not being local administrators, and a recent backup, restore point or OneDrive coverage. It lists the fleet's biggest gaps with how to fix each one, and the endpoint's **Protection** tab shows its own checklist.

Restore points and synced folders **complement** backups but don't replace them, because a serious attack can target both. Always keep at least one **offline or immutable backup**, and don't give everyday users local administrator rights.

### USB device control

Under **Protection policies → USB device control**, choose one of these for **USB storage** (flash drives, external disks, phones and cameras):

| Setting | Effect |
|---|---|
| **Allow** | No restriction (default) |
| **Read-only** | Users can open files from USB drives but can't copy files to them (data-leak prevention) |
| **Block completely** | No access to removable storage. The USB storage driver is also prevented from loading |

Keyboards, mice, printers, headsets and other non-storage USB devices keep working. A drive that's already plugged in is affected when it's reconnected or after a restart. Each endpoint's **Protection** tab shows the current USB state and any USB drives that are plugged in.

To give some users USB access, create a second policy (for example *"USB allowed"*) and assign it to their PCs.

### Website blocking

Under **Protection policies → Website blocking**, list the domains to block, one per line. You can paste full URLs or `*.domain` entries; they're cleaned up to the base domain automatically. The **Add category** buttons add ready-made lists: social media, video streaming, gaming, file sharing, personal web mail and remote access tools.

Blocked sites are enforced in two layers:
1. **Browser policies for Edge, Chrome and Firefox.** These block the domain **and all its subdomains**, over HTTPS too, and users see a "blocked by your organization" page.
2. **The system hosts file.** This covers other apps and browsers for the domain itself and its `www.` and `m.` variants.

Different groups can have different lists through separate policies. The **Blocklist** page is separate: it holds global malicious indicators that apply to every enforcing policy.

**Coexisting with Group Policy:** Shield360 records which settings it made under `HKLM\SOFTWARE\Shield360`. Browser block entries created by Group Policy are kept. Switching USB back to **Allow**, or uninstalling the agent, only undoes Shield360's own changes, never a Group Policy restriction. Uninstalling restores USB access and removes the Shield360 browser entries.

### Virus definitions (latest virus database)

Microsoft publishes new Defender definitions several times a day. Shield360 keeps every endpoint current in three layers:

1. **Defender's own updater** runs at the interval set in the protection policy (default: every 4 hours).
2. **The agent checks every 15 minutes.** If definitions are older than that interval, it updates them itself. A definition age above twice the interval shows as non-compliant, and above 3 days it raises an alert.
3. **Server mirror.** The Shield360 server downloads Microsoft's official full definition package (`mpam-fe.exe`, about 200 MB) every 4 hours and only keeps it if it carries a valid Microsoft signature. Endpoints that can't reach Microsoft (isolated PCs, offline networks, restricted proxies) download it from your server and verify Microsoft's signature again before installing it. Only enrolled agents can download it.

The **Virus definitions** page shows each endpoint's version against the latest known version and the mirror's status. It also has **Update all endpoints now** and **Update out-of-date endpoints** buttons.

Configure the mirror in `server/config.json`. For example, add `"arm64"` or `"x86"` if you have such endpoints, or set `"enabled": false` to turn the mirror off:
```json
"definitionMirror": { "enabled": true, "arches": ["x64"], "refreshHours": 4 }
```
The server needs outbound HTTPS to `go.microsoft.com` and `download.microsoft.com` for the mirror. The signature check needs a Windows server; on Linux, the agents' own signature check is the only check.

### Automatic isolation of compromised PCs

When any trigger enabled in the policy fires, the agent **immediately isolates the endpoint itself**. This doesn't wait for the server, so it also works while the server is down. Isolation means:

- Windows Firewall block rules stop **all inbound and outbound traffic** (internet and LAN, IPv4 and IPv6) **except to the Shield360 server**, so you keep control.
- The server's address is pinned in the hosts file, so the agent still works without DNS.
- Isolation **survives restarts** and stays on until an administrator clicks **Release isolation** on the endpoint page.
- A critical **AUTO-ISOLATED** alert and event show the reason.

| Trigger (per policy) | Default |
|---|---|
| Malware Defender could not remove | on |
| Any malware detection | off |
| A blocklisted program was running | on |
| Ransomware activity blocked | on |
| Security event log cleared | on |
| Antivirus turned off | off |
| Attack-like PowerShell executed | off |
| **Servers: alert only, don't auto-isolate** | on |

Servers are excluded by default because automatically cutting off a production server can cause an outage. For servers, the agent raises a critical "Compromise detected" alert instead, and you can isolate them with one click. In Report only mode, the same alert is raised without isolating.

To try enforcement and isolation safely on a test VM, follow [TESTING.md](TESTING.md).

If an endpoint loses contact with the server while isolated (for example, the server's IP changed), run this locally as administrator:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\Program Files\Shield360\Shield360Agent.ps1" -ReleaseIsolation
```

### Built-in alert rules

| Alert | Severity |
|---|---|
| No active antivirus / Defender real-time protection off / threat detected | critical |
| Endpoint offline, firewall profile disabled, failed-logon spike, pending security updates | high |
| Disk ≥ 90%, sustained CPU ≥ 90%, memory ≥ 90%, outdated signatures, workstation without BitLocker, pending updates | warning |
| Restart pending | info |

You can change the thresholds in `server/config.json`.

## Requirements

- **Server:** any Windows Server or Windows machine (Linux also works) with **Node.js 22.13 or later**. No npm packages are needed.
- **Endpoints:** Windows Server 2016/2019/2022/2025 or Windows 10/11 with Windows PowerShell 5.1, which is built in. Nothing else needs to be installed.

## 1. Set up the server

Copy the whole `Shield360 Endpoint` folder to the server. Then open an **elevated** PowerShell:

```powershell
cd "C:\Shield360 Endpoint\server"
.\New-Shield360Certificate.ps1 -DnsName shield360.corp.local, shield360   # HTTPS (recommended)
.\Install-Shield360Server.ps1                                           # auto-start + firewall rule
```

- Open `https://<server>:8443` and sign in as **admin**. The installer prints the initial password at the end; it is also in `server\data\initial-admin-password.txt`, which you can read from an Administrator PowerShell. At first sign-in the console **requires** you to set your own password before anything else. Choose at least 10 characters with letters and numbers, not containing the username. The initial password then stops working and its file is deleted automatically.
- If your company has an internal CA, use its certificate instead. Set `tls.pfx` and `tls.passphrase` in `config.json`.
- To try it out without installing, run `npm start` in `server\` and open `http://localhost:8080`.

### Managing computers outside your network (internet-facing server)

To manage PCs that aren't on the server's LAN (home workers, branch offices), the server must be reachable from the internet.

1. **DNS name:** create a DNS record such as `shield360.yourcompany.com` pointing to the server's public IP.
2. **Open the port:** forward TCP **8443** from your router or firewall to the server (the installer already opens it in Windows Firewall).
3. **Trusted HTTPS certificate:** remote PCs don't trust the self-signed certificate. Get a certificate for the DNS name, then set `tls.pfx` and `tls.passphrase` in `server\config.json` and restart the server. Either:
   - use a free Let's Encrypt certificate, for example with [win-acme](https://www.win-acme.com/): choose *manual input*, your DNS name, and *PFX archive* as the store; or
   - use a certificate from your usual certificate provider.
4. **Public address:** under **Settings → Server address & remote access**, set it to `https://shield360.yourcompany.com:8443`. Every install command on **Deploy agent** now uses this address. The Deploy page warns if the commands would point to `localhost`.
5. **Lock down the console:** in the same section, list the IP addresses or ranges your administrators work from. The console and admin API then refuse every other address, while **agents can still connect from anywhere**. You can't lock yourself out: the change is refused unless your current address is included, and the server itself (`localhost`) can always open the console.
6. **Rotate the enrollment token** (**Deploy agent → Rotate**) if it has ever been shared outside your team.

If a reverse proxy (IIS, nginx, Cloudflare) sits in front of the server, set `"trustProxy": true` in `config.json` so the allowlist sees the real client address. Only do this when the proxy is the only way to reach the server.

### Uninstalling the server

1. **Uninstall the agents first** from the console (**Endpoints → select all → Run → Uninstall agent**), and wait until the list is empty. Once the server is gone, agents can no longer be managed or removed remotely.
2. On the server, in an **Administrator PowerShell**, run:
   ```powershell
   irm https://shield360.biz/uninstall.ps1 | iex
   ```
   or `.\Uninstall-Shield360Server.ps1` in the server folder.

The uninstaller:
- finds the installation, and warns if endpoints are still enrolled
- asks whether to **keep the database, license and settings** for a later reinstall
- removes the background task, firewall rule, HTTPS certificate and program files

If you choose to delete the data, it first writes a backup zip, `C:\Shield360-Server-Backup-<date>.zip`. Node.js is left installed unless you add `-RemoveNodeJs`.

Options for unattended use: `-KeepData` or `-DeleteData`, `-BackupPath D:\Backups`, `-NoBackup`, `-InstallDir <folder>`, `-Force` (no questions).

**Restoring a backup:** reinstall the server, stop the `Shield360 Server` task, and unzip the backup into the `server` folder (it contains `config.json` and `data\`). Then start the task again.

## 2. Deploy agents

In the console, go to **Deploy agent**. It shows ready-to-copy commands that already include your server URL and enrollment token:

- **One machine:** paste the one-line command into an elevated prompt.
- **Offline:** download the three `.ps1` files from the console, then run:
  ```powershell
  .\Install-Shield360Agent.ps1 -ServerUrl https://shield360.corp.local:8443 -EnrollToken <token> -CertificateFile .\server.cer
  ```
- **Many machines:** use the GPO startup-script command shown on the Deploy page. Intune, SCCM or an RMM tool can run the same command.

The agent installs to `C:\Program Files\Shield360` and runs as a SYSTEM scheduled task named `\Shield360\Shield360 Agent`. It starts at boot, and a watchdog restarts it within 5 minutes if it stops. Its config and key are in `C:\ProgramData\Shield360`, and only SYSTEM and Administrators can read that folder. Logs are in `C:\ProgramData\Shield360\logs\agent.log`.

If you reinstall the agent on the same machine, it keeps the machine's history, because endpoints are matched by Windows MachineGuid.

**To uninstall from the console (recommended):** on an endpoint's **Actions** tab, click **Uninstall agent**. For many endpoints at once, select them on **Endpoints** and choose **Run → Uninstall agent**; you must type `UNINSTALL` to confirm. Within about a minute the agent:
- restores USB, firewall, isolation, hosts-file and browser website settings
- removes itself
- disappears from the console, which frees its license seat

Defender and hardening settings applied by policy are left in place. A log is written to `C:\Windows\Temp\Shield360-Uninstall.log`.

**To uninstall locally:** run `C:\Program Files\Shield360\Uninstall-Shield360Agent.ps1` as administrator. The endpoint is removed from the console automatically.

**Uninstall protection:** go to **Settings → Agent uninstall** to require an uninstall code for local uninstalls, so users who are local administrators can't simply remove the agent. With protection on, run the uninstaller with `-UninstallCode <code>`, or let it ask for the code. Uninstalls started from the console always work. Endpoints receive only a salted hash of the code, never the code itself.

This is a deterrent, not absolute protection: a determined local administrator can still delete the agent's files and scheduled task. Remove local administrator rights from users where that matters.

**Troubleshooting:** this command runs one check-in in the foreground:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\Program Files\Shield360\Shield360Agent.ps1" -Once
```

## Security design

- Each agent gets its **own random key** when it enrolls. The server stores only a SHA-256 hash of it. Removing an endpoint in the console revokes its key.
- The **enrollment token** is only used to register new machines. You can rotate it in the console without affecting agents that are already enrolled.
- Remote actions come from a **fixed allow-list**. The server cannot run arbitrary scripts on endpoints.
- Admin passwords are hashed with **scrypt**. Sessions use HttpOnly, SameSite=Strict cookies. After 5 failed logins, the source IP is locked out for 5 minutes.
- The console is served with strict security headers (CSP, frame denial, nosniff).
- Use **HTTPS in production**. Agent keys and the enrollment token are sent with every request.

## Configuration (`server/config.json`)

| Key | Default | Meaning |
|---|---|---|
| `port` / `host` | 8080 / 0.0.0.0 | Listen address |
| `publicUrl` | (auto) | URL that agents use, shown on the Deploy page |
| `tls.pfx`, `tls.passphrase` or `tls.cert`, `tls.key` | — | Enables HTTPS |
| `checkinIntervalSec` | 60 | How often agents report |
| `offlineAfterMin` | 5 | When an endpoint counts as offline |
| `metricRetentionDays` | 30 | How long performance history is kept |
| `thresholds` | cpu 90, memory 90, disk 90, signatureAgeDays 3, failedLogonsPerHour 20 | Alert thresholds |

Restart the server after you edit this file.

## Project layout

```
agent/          Shield360Agent.ps1, Install-Shield360Agent.ps1, Uninstall-Shield360Agent.ps1
server/         src/ (server, database, alerts, protection, definitions, license), public/ (console UI), install and certificate scripts
license-tools/  VENDOR ONLY: signing keys and license issuing (never ship to customers)
```

**What to ship to a customer:** the `agent/` and `server/` folders (without `server/data/` and `server/config.json`), plus `README.md`. **Never** include `license-tools/`.

## Roadmap ideas

- Agent self-update
- Email and Teams/Slack alert notifications
- Multiple admin users with roles
- Signed MSI agent package (and code-signing the agent script)
- Restore from quarantine
- Microsoft Defender for Endpoint integration (custom indicators, live response)
