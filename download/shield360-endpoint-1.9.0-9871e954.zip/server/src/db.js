import { DatabaseSync } from 'node:sqlite';

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY,
  key_hash TEXT NOT NULL,
  device_id TEXT,
  hostname TEXT NOT NULL,
  os_name TEXT, os_version TEXT, os_build TEXT,
  product_type INTEGER,
  domain TEXT,
  manufacturer TEXT, model TEXT, serial TEXT,
  cpu_model TEXT, cores INTEGER, ram_total_mb INTEGER,
  ip_addresses TEXT, mac_addresses TEXT,
  logged_on_users TEXT,
  last_boot TEXT,
  agent_version TEXT,
  remote_ip TEXT,
  tags TEXT NOT NULL DEFAULT '',
  state TEXT,
  inventory TEXT,
  inventory_at INTEGER,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER
);
CREATE INDEX IF NOT EXISTS idx_agents_device ON agents(device_id);

CREATE TABLE IF NOT EXISTS metrics (
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  cpu REAL, mem REAL, disk REAL
);
CREATE INDEX IF NOT EXISTS idx_metrics_agent_ts ON metrics(agent_id, ts);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  severity TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  resolved_at INTEGER,
  acknowledged_by TEXT,
  acknowledged_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_alerts_open ON alerts(agent_id, type, resolved_at);

CREATE TABLE IF NOT EXISTS commands (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_by TEXT,
  created_at INTEGER NOT NULL,
  sent_at INTEGER,
  completed_at INTEGER,
  output TEXT
);
CREATE INDEX IF NOT EXISTS idx_commands_agent ON commands(agent_id, status);

CREATE TABLE IF NOT EXISTS policies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  description TEXT NOT NULL DEFAULT '',
  settings TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  updated_by TEXT
);

CREATE TABLE IF NOT EXISTS endpoint_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  description TEXT NOT NULL DEFAULT '',
  policy_id INTEGER NOT NULL DEFAULT 1,
  rules TEXT,                 -- auto-assignment rules for newly enrolled endpoints (JSON)
  priority INTEGER NOT NULL DEFAULT 100,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS iocs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  value TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  created_by TEXT,
  created_at INTEGER NOT NULL,
  UNIQUE(type, value)
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  type TEXT NOT NULL,
  severity TEXT NOT NULL,
  blocked INTEGER NOT NULL DEFAULT 0,
  message TEXT NOT NULL,
  details TEXT,
  dedupe_key TEXT UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
CREATE INDEX IF NOT EXISTS idx_events_agent ON events(agent_id, ts);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  username TEXT,
  ip TEXT,
  action TEXT NOT NULL,
  detail TEXT
);
`;

export function openDb(file) {
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  // Columns added after 1.0.0; ignore "duplicate column" on databases that already have them.
  const addColumn = (sql) => {
    try { db.exec(sql); return true; } catch (e) { if (!/duplicate column/i.test(e.message)) throw e; return false; }
  };
  addColumn('ALTER TABLE agents ADD COLUMN policy_id INTEGER NOT NULL DEFAULT 1');   // legacy (<= 1.3), see policy_override
  addColumn('ALTER TABLE commands ADD COLUMN params TEXT');
  addColumn('ALTER TABLE agents ADD COLUMN group_id INTEGER NOT NULL DEFAULT 1');
  if (addColumn('ALTER TABLE agents ADD COLUMN policy_override INTEGER')) {
    // 1.4 moved policy assignment to groups; keep any per-endpoint choice made earlier as an override.
    db.exec('UPDATE agents SET policy_override = policy_id WHERE policy_id <> 1');
  }
  return db;
}
