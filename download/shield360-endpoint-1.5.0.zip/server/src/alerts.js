// Alert rules. Each rule either raises (or refreshes) one open alert per
// (agent, type), or resolves it when the condition clears.

export const SEVERITY_RANK = { critical: 4, high: 3, warning: 2, info: 1 };

export function createAlerting(db, config) {
  const findOpen = db.prepare(
    'SELECT id, severity, message FROM alerts WHERE agent_id = ? AND type = ? AND resolved_at IS NULL'
  );
  const insert = db.prepare(
    'INSERT INTO alerts (agent_id, type, severity, message, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const refresh = db.prepare('UPDATE alerts SET severity = ?, message = ?, updated_at = ? WHERE id = ?');
  const resolve = db.prepare(
    'UPDATE alerts SET resolved_at = ? WHERE agent_id = ? AND type = ? AND resolved_at IS NULL'
  );
  const recentCpu = db.prepare('SELECT cpu FROM metrics WHERE agent_id = ? ORDER BY ts DESC LIMIT 3');

  function raise(agentId, type, severity, message) {
    const now = Date.now();
    const open = findOpen.get(agentId, type);
    if (!open) insert.run(agentId, type, severity, message, now, now);
    else if (open.severity !== severity || open.message !== message) refresh.run(severity, message, now, open.id);
  }

  function clear(agentId, type) {
    resolve.run(Date.now(), agentId, type);
  }

  function rule(agentId, type, condition, severity, message) {
    if (condition) raise(agentId, type, severity, message);
    else clear(agentId, type);
  }

  // Evaluate everything an agent reported in a check-in.
  function evaluate(agent, report) {
    const t = config.thresholds;
    const id = agent.id;
    const m = report.metrics || {};
    const s = report.security || {};
    const isWorkstation = Number(report.system?.productType) === 1;

    clear(id, 'offline');

    const cpuSamples = recentCpu.all(id).map((r) => r.cpu);
    rule(id, 'cpu', cpuSamples.length >= 3 && cpuSamples.every((c) => c >= t.cpu),
      'warning', `Sustained CPU usage above ${t.cpu}% (now ${Math.round(m.cpu ?? 0)}%)`);

    rule(id, 'memory', (m.memPct ?? 0) >= t.memory,
      'warning', `Memory usage at ${Math.round(m.memPct)}%`);

    const fullDisks = (m.disks || []).filter((d) => d.usedPct >= t.disk);
    const worstDisk = Math.max(0, ...fullDisks.map((d) => d.usedPct));
    rule(id, 'disk', fullDisks.length > 0, worstDisk >= 97 ? 'high' : 'warning',
      `Low disk space: ${fullDisks.map((d) => `${d.drive} ${Math.round(d.usedPct)}% used (${d.freeGB} GB free)`).join(', ')}`);

    // Antivirus: Defender if active, otherwise any enabled product from Security Center.
    const def = s.defender || {};
    const defenderActive = def.present && def.antivirusEnabled && def.mode !== 'Passive Mode';
    const thirdPartyAv = (s.antivirus || []).filter((a) => a.enabled && !/defender/i.test(a.name || ''));
    const hasAv = defenderActive || thirdPartyAv.length > 0;
    rule(id, 'av_missing', !hasAv, 'critical', 'No active antivirus protection detected');

    rule(id, 'av_realtime', defenderActive && def.realTimeProtection === false,
      'critical', 'Microsoft Defender real-time protection is turned off');

    rule(id, 'av_signatures', defenderActive && (def.signatureAgeDays ?? 0) > t.signatureAgeDays,
      'warning', `Defender signatures are ${def.signatureAgeDays} days old`);

    const fwOff = (s.firewall || []).filter((p) => !p.enabled).map((p) => p.name);
    rule(id, 'firewall', fwOff.length > 0, 'high', `Windows Firewall disabled: ${fwOff.join(', ')} profile`);

    rule(id, 'failed_logons', (s.failedLogons1h ?? 0) >= t.failedLogonsPerHour,
      'high', `${s.failedLogons1h} failed logons in the last hour (possible brute force)`);

    const osVol = (s.bitlocker || []).find((v) => v.isOsVolume);
    rule(id, 'bitlocker', isWorkstation && osVol && !osVol.protected,
      'warning', `System drive ${osVol?.drive ?? ''} is not BitLocker encrypted`);

    rule(id, 'reboot', !!s.pendingReboot, 'info', 'Restart pending to complete updates');

    const p = report.protection;
    if (p) {
      const failed = (p.compliance || []).filter((c) => !c.ok);
      rule(id, 'noncompliant', failed.length > 0, 'warning',
        `${failed.length} protection setting(s) not applied: ${failed.slice(0, 3).map((c) => c.setting).join(', ')}${failed.length > 3 ? ', …' : ''}`);
      rule(id, 'isolated', !!p.isolated, p.isolationReason ? 'critical' : 'info',
        p.isolationReason ? `Automatically isolated from the network: ${p.isolationReason}` : 'Endpoint is isolated from the network');
    }

    for (const t of s.threats || []) {
      recordEvent(id, {
        time: t.time, type: 'malware', severity: t.actionSuccess ? 'high' : 'critical', blocked: !!t.actionSuccess,
        message: `Malware ${t.actionSuccess ? 'blocked' : 'detected (remediation failed)'}: ${t.name}`,
        details: { resources: t.resources }, key: `threat:${id}:${t.threatId}:${t.time}`,
      });
    }
  }

  // Point-in-time security events (attacks, blocks, suspicious activity). Critical and
  // high events also open an alert, which stays open until an administrator acknowledges it.
  const insertEvent = db.prepare(
    'INSERT OR IGNORE INTO events (agent_id, ts, type, severity, blocked, message, details, dedupe_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );
  function recordEvent(agentId, e) {
    const severity = SEVERITY_RANK[e.severity] ? e.severity : 'info';
    const ts = Date.parse(e.time) || Date.now();
    const r = insertEvent.run(agentId, ts, String(e.type || 'event').slice(0, 40), severity, e.blocked ? 1 : 0,
      String(e.message || '').slice(0, 1000), e.details ? JSON.stringify(e.details).slice(0, 8000) : null, e.key ? String(e.key).slice(0, 200) : null);
    if (r.changes && (severity === 'critical' || severity === 'high')) {
      raise(agentId, `evt_${String(e.type).slice(0, 40)}`, severity, String(e.message).slice(0, 500));
    }
  }

  function evaluateInventory(agent, inv) {
    const pending = inv.pendingUpdates;
    rule(agent.id, 'updates', pending && pending.count > 0,
      pending?.securityCount > 0 ? 'high' : 'warning',
      `${pending?.count} pending Windows update(s)` +
      (pending?.securityCount ? `, ${pending.securityCount} security` : ''));
  }

  // Periodic: offline detection, command timeouts, retention.
  function sweep() {
    const now = Date.now();
    const cutoff = now - config.offlineAfterMin * 60 * 1000;
    for (const a of db.prepare('SELECT id, last_seen FROM agents WHERE last_seen < ?').all(cutoff)) {
      const mins = Math.round((now - a.last_seen) / 60000);
      raise(a.id, 'offline', 'high', `Endpoint has not checked in for ${mins >= 120 ? Math.round(mins / 60) + ' hours' : mins + ' minutes'}`);
    }
    db.prepare("UPDATE commands SET status = 'timeout', completed_at = ? WHERE status IN ('pending','sent') AND created_at < ?")
      .run(now, now - 24 * 3600 * 1000);
    db.prepare('DELETE FROM metrics WHERE ts < ?').run(now - config.metricRetentionDays * 86400 * 1000);
    db.prepare('DELETE FROM alerts WHERE resolved_at IS NOT NULL AND resolved_at < ?').run(now - 90 * 86400 * 1000);
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now);
    db.prepare('DELETE FROM events WHERE ts < ?').run(now - 180 * 86400 * 1000);
  }

  return { evaluate, evaluateInventory, recordEvent, sweep };
}
