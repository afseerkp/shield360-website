// Protection policy model, attack surface reduction rules and indicator (IOC) validation.

import crypto from 'node:crypto';

// Microsoft Defender attack surface reduction rules (GUIDs are fixed by Microsoft).
export const ASR_RULES = [
  { id: '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2', name: 'Block credential stealing from LSASS', default: 'block' },
  { id: '56a863a9-875e-4185-98a7-b882c64b5ce5', name: 'Block abuse of exploited vulnerable signed drivers', default: 'block' },
  { id: 'e6db77e5-3df2-4cf1-b95a-636979351e5b', name: 'Block persistence through WMI event subscription', default: 'block' },
  { id: 'c1db55ab-c21a-4637-bb3f-a12568109d35', name: 'Use advanced protection against ransomware', default: 'block' },
  { id: 'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550', name: 'Block executable content from email client and webmail', default: 'block' },
  { id: 'd3e037e1-3eb8-44c8-a917-57927947596d', name: 'Block JavaScript or VBScript from launching downloaded executable content', default: 'block' },
  { id: '5beb7efe-fd9a-4556-801d-275e5ffc04cc', name: 'Block execution of potentially obfuscated scripts', default: 'block' },
  { id: '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b', name: 'Block Win32 API calls from Office macros', default: 'block' },
  { id: '3b576869-a4ec-4529-8536-b80a7769e899', name: 'Block Office applications from creating executable content', default: 'block' },
  { id: '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84', name: 'Block Office applications from injecting code into other processes', default: 'block' },
  { id: 'd4f940ab-401b-4efc-aadc-ad5f3c50688a', name: 'Block all Office applications from creating child processes', default: 'audit' },
  { id: '26190899-1602-49e8-8b27-eb1d0a1ce869', name: 'Block Office communication application from creating child processes', default: 'audit' },
  { id: '7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c', name: 'Block Adobe Reader from creating child processes', default: 'block' },
  { id: 'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4', name: 'Block untrusted and unsigned processes that run from USB', default: 'block' },
  { id: 'd1e49aac-8f56-4280-b9ba-993a6d77406c', name: 'Block process creations originating from PSExec and WMI commands', default: 'audit' },
  { id: '01443614-cd74-433a-b99e-2ecdc07bfc25', name: 'Block executables unless they meet a prevalence, age, or trusted list criterion', default: 'audit' },
  { id: 'a8f5898e-1dc8-49a9-9878-85004b8a61e6', name: 'Block webshell creation for servers', default: 'block' },
  // Newer rules (recent Defender platform); older systems accept the setting but don't enforce it.
  { id: '33ddedf1-c6e0-47cb-833e-de6133960387', name: 'Block rebooting machine in Safe Mode (ransomware evasion)', default: 'block' },
  { id: 'c0033c00-d16d-4114-a5a0-dc9b3a7d2ceb', name: 'Block use of copied or impersonated system tools', default: 'audit' },
];

const MODES = ['off', 'audit', 'block'];

export function defaultPolicySettings() {
  return {
    enforce: true,   // false = report compliance only, change nothing on the endpoint
    antivirus: {
      realTimeProtection: true,
      behaviorMonitoring: true,
      scriptScanning: true,
      downloadScanning: true,
      cloudProtection: true,
      cloudBlockLevel: 'high',          // default | high | highplus | zerotolerance
      puaProtection: 'block',           // off | audit | block
      networkProtection: 'block',       // blocks connections to malicious sites/IPs
      controlledFolderAccess: 'block',  // ransomware folder protection; allow business apps below if they are blocked
      cfaAllowedApps: [],               // full paths of programs allowed to change protected folders
      cfaProtectedFolders: [],          // extra folders to protect (e.g. D:\Shares); Documents, Desktop etc. are always protected
      signatureUpdateIntervalHours: 4,
      autoUpdateSignatures: true,       // agent updates definitions itself, falling back to the server mirror
      dailyQuickScan: true,
      exclusions: [],
    },
    asr: Object.fromEntries(ASR_RULES.map((r) => [r.id, r.default])),
    firewall: { enforceOn: true, blockInboundByDefault: true },
    hardening: {
      disableSmb1: true,
      disableLlmnr: true,
      disableWdigest: true,
      requireRdpNla: true,
      powershellLogging: true,
      lsaProtection: false,   // needs a restart and can break old drivers; enable after testing
    },
    bruteForce: { enabled: true, threshold: 10, windowMinutes: 10, blockMinutes: 60, allowlist: [] },
    iocEnforcement: true,
    // Automatically cut a compromised endpoint off the network (the Shield360 server stays reachable).
    autoIsolate: {
      enabled: true,
      excludeServers: true,           // servers only alert; isolating them automatically can cause outages
      malwareNotRemediated: true,     // Defender detected malware but could not clean it
      malwareAny: false,              // any malware detection, even if Defender removed it
      blocklistedFile: true,          // a blocklisted (IOC) program was running
      ransomware: true,               // ransomware protection blocked an encryption attempt
      antivirusDisabled: false,       // Defender protection was turned off
      logCleared: true,               // the Security event log was wiped
      attackPowerShell: false,        // PowerShell with attack-tool techniques ran
    },
    // USB mass storage: allow | readonly | block. Keyboards, mice and other USB devices are not affected.
    deviceControl: { usbStorage: 'allow' },
    // Websites blocked in Edge/Chrome/Firefox (incl. subdomains) and system-wide via the hosts file.
    webFilter: { blockedSites: [] },
  };
}

// Ready-made lists the console can add to a policy's blocked websites.
export const WEBSITE_PRESETS = {
  'Social media': ['facebook.com', 'instagram.com', 'tiktok.com', 'x.com', 'twitter.com', 'snapchat.com', 'pinterest.com', 'reddit.com', 'linkedin.com'],
  'Video streaming': ['youtube.com', 'netflix.com', 'twitch.tv', 'vimeo.com', 'dailymotion.com', 'primevideo.com', 'disneyplus.com', 'hulu.com'],
  'Gaming': ['steampowered.com', 'epicgames.com', 'roblox.com', 'miniclip.com', 'poki.com', 'crazygames.com'],
  'File sharing & personal cloud': ['wetransfer.com', 'mega.nz', 'mediafire.com', 'dropbox.com', 'box.com', '4shared.com', 'sendspace.com'],
  'Web mail (personal)': ['mail.yahoo.com', 'gmx.com', 'proton.me', 'mail.com', 'zoho.com'],
  'Remote access tools': ['anydesk.com', 'teamviewer.com', 'rustdesk.com', 'getscreen.me', 'splashtop.com'],
};

export const AUTO_ISOLATE_TRIGGERS = [
  ['malwareNotRemediated', 'Malware detected that Defender could not remove'],
  ['malwareAny', 'Any malware detection (even if removed)'],
  ['blocklistedFile', 'Blocklisted program was running'],
  ['ransomware', 'Ransomware activity blocked'],
  ['antivirusDisabled', 'Antivirus protection turned off'],
  ['logCleared', 'Security event log cleared'],
  ['attackPowerShell', 'Attack-like PowerShell executed'],
];

const bool = (v, d) => (typeof v === 'boolean' ? v : d);
const oneOf = (v, list, d) => (list.includes(v) ? v : d);
const num = (v, min, max, d) => (Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Math.round(Number(v)))) : d);
const strList = (v, max = 100) =>
  (Array.isArray(v) ? v : String(v || '').split(/[\r\n,]+/)).map((s) => String(s).trim()).filter(Boolean).slice(0, max).map((s) => s.slice(0, 260));

// Normalise untrusted input from the console into a complete, valid policy.
export function sanitizePolicy(input = {}) {
  const d = defaultPolicySettings();
  const av = input.antivirus || {};
  const fw = input.firewall || {};
  const h = input.hardening || {};
  const bf = input.bruteForce || {};
  return {
    enforce: bool(input.enforce, d.enforce),
    antivirus: {
      realTimeProtection: bool(av.realTimeProtection, d.antivirus.realTimeProtection),
      behaviorMonitoring: bool(av.behaviorMonitoring, d.antivirus.behaviorMonitoring),
      scriptScanning: bool(av.scriptScanning, d.antivirus.scriptScanning),
      downloadScanning: bool(av.downloadScanning, d.antivirus.downloadScanning),
      cloudProtection: bool(av.cloudProtection, d.antivirus.cloudProtection),
      cloudBlockLevel: oneOf(av.cloudBlockLevel, ['default', 'high', 'highplus', 'zerotolerance'], d.antivirus.cloudBlockLevel),
      puaProtection: oneOf(av.puaProtection, MODES, d.antivirus.puaProtection),
      networkProtection: oneOf(av.networkProtection, MODES, d.antivirus.networkProtection),
      controlledFolderAccess: oneOf(av.controlledFolderAccess, MODES, d.antivirus.controlledFolderAccess),
      signatureUpdateIntervalHours: num(av.signatureUpdateIntervalHours, 1, 24, d.antivirus.signatureUpdateIntervalHours),
      autoUpdateSignatures: bool(av.autoUpdateSignatures, d.antivirus.autoUpdateSignatures),
      dailyQuickScan: bool(av.dailyQuickScan, d.antivirus.dailyQuickScan),
      exclusions: strList(av.exclusions),
      cfaAllowedApps: strList(av.cfaAllowedApps),
      cfaProtectedFolders: strList(av.cfaProtectedFolders),
    },
    asr: Object.fromEntries(ASR_RULES.map((r) => [r.id, oneOf(input.asr?.[r.id], MODES, r.default)])),
    firewall: {
      enforceOn: bool(fw.enforceOn, d.firewall.enforceOn),
      blockInboundByDefault: bool(fw.blockInboundByDefault, d.firewall.blockInboundByDefault),
    },
    hardening: Object.fromEntries(Object.keys(d.hardening).map((k) => [k, bool(h[k], d.hardening[k])])),
    bruteForce: {
      enabled: bool(bf.enabled, d.bruteForce.enabled),
      threshold: num(bf.threshold, 3, 1000, d.bruteForce.threshold),
      windowMinutes: num(bf.windowMinutes, 1, 1440, d.bruteForce.windowMinutes),
      blockMinutes: num(bf.blockMinutes, 1, 10080, d.bruteForce.blockMinutes),
      allowlist: strList(bf.allowlist).filter(isIp),
    },
    iocEnforcement: bool(input.iocEnforcement, d.iocEnforcement),
    autoIsolate: Object.fromEntries(Object.keys(d.autoIsolate).map((k) => [k, bool(input.autoIsolate?.[k], d.autoIsolate[k])])),
    deviceControl: { usbStorage: oneOf(input.deviceControl?.usbStorage, ['allow', 'readonly', 'block'], d.deviceControl.usbStorage) },
    webFilter: { blockedSites: normalizeSites(input.webFilter?.blockedSites).valid },
  };
}

// Accepts "facebook.com", "*.facebook.com", "https://www.facebook.com/page"; returns unique base domains.
export function normalizeSites(list) {
  const valid = new Set();
  const invalid = [];
  for (const raw of strList(list, 500)) {
    const cleaned = raw.toLowerCase().replace(/^\*\./, '').replace(/^https?:\/\//, '').replace(/[/?#].*$/, '').replace(/^www\./, '');
    try { valid.add(normalizeIoc('domain', cleaned)); } catch { invalid.push(raw); }
  }
  return { valid: [...valid], invalid };
}

export const versionOf = (obj) => crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex').slice(0, 16);

export function isIp(v) {
  const s = String(v);
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(\/(\d|[12]\d|3[0-2]))?$/.exec(s);
  if (m) return m.slice(1, 5).every((o) => Number(o) <= 255);
  return /^[0-9a-f:]+(\/\d{1,3})?$/i.test(s) && s.includes(':');
}

// Returns a normalised indicator value, or throws with a user-facing message.
export function normalizeIoc(type, value) {
  const v = String(value || '').trim();
  if (type === 'hash') {
    if (!/^[a-f0-9]{64}$/i.test(v)) throw new Error('File hash must be a SHA-256 (64 hex characters)');
    return v.toUpperCase();
  }
  if (type === 'ip') {
    if (!isIp(v)) throw new Error('Enter a valid IPv4/IPv6 address or CIDR range');
    if (/^(0\.0\.0\.0|127\.)/.test(v) || v === '::1') throw new Error('Refusing to block a loopback or wildcard address');
    return v;
  }
  if (type === 'domain') {
    const d = v.toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!/^(?=.{1,253}$)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/.test(d)) throw new Error('Enter a valid domain name, e.g. evil.example.com');
    return d;
  }
  throw new Error('Type must be hash, ip or domain');
}

// Commands an administrator may send. `param` declares a required parameter.
export const COMMAND_ACTIONS = {
  refresh_inventory: { label: 'Refresh inventory' },
  apply_policy: { label: 'Re-apply protection policy now' },
  defender_quick_scan: { label: 'Defender quick scan' },
  defender_full_scan: { label: 'Defender full scan' },
  defender_update_signatures: { label: 'Update Defender signatures' },
  remove_threats: { label: 'Remove active threats' },
  scan_path: { label: 'Scan a file or folder', param: 'path' },
  quarantine_file: { label: 'Quarantine a file', param: 'path', danger: true },
  kill_process: { label: 'Kill a process', param: 'pid', danger: true },
  list_processes: { label: 'List top processes' },
  list_connections: { label: 'List network connections' },
  unblock_ip: { label: 'Unblock an auto-blocked IP', param: 'ip' },
  isolate: { label: 'Isolate from network', danger: true },
  release_isolation: { label: 'Release network isolation' },
  restart: { label: 'Restart computer (2 min warning)', danger: true },
  cancel_restart: { label: 'Cancel pending restart' },
  uninstall_agent: { label: 'Uninstall agent', danger: true },
};

// Actions that may be sent to many endpoints at once from the Endpoints list.
export const BULK_ACTIONS = ['uninstall_agent', 'defender_quick_scan', 'defender_update_signatures', 'apply_policy', 'refresh_inventory'];

export function validateCommandParams(action, params = {}) {
  const def = COMMAND_ACTIONS[action];
  if (!def) throw new Error('Unknown action');
  if (!def.param) return {};
  const v = params[def.param];
  if (def.param === 'pid') {
    const pid = Number(v);
    if (!Number.isInteger(pid) || pid <= 4) throw new Error('Enter a valid process ID');
    return { pid };
  }
  if (def.param === 'path') {
    const p = String(v || '').trim();
    if (!/^[a-zA-Z]:\\[^\r\n<>"|?*]{0,255}$/.test(p)) throw new Error('Enter a full local path, e.g. C:\\Users\\Public\\file.exe');
    return { path: p };
  }
  if (def.param === 'ip') {
    if (!isIp(v)) throw new Error('Enter a valid IP address');
    return { ip: String(v) };
  }
  return {};
}
