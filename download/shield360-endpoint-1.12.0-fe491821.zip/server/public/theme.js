'use strict';
// Applies the saved color theme before the page paints, so it never flashes the wrong theme.
// No saved choice means "match the system" (prefers-color-scheme).
try {
  const t = localStorage.getItem('s360-theme');
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
} catch { /* storage blocked: follow the system theme */ }
