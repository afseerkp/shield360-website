// Alert notifications: email (SMTP), Microsoft Teams (Workflows webhook) and a generic JSON webhook.
// New alerts are queued and sent in one batch every 30 seconds so an incident doesn't flood inboxes.
// No external dependencies: the SMTP client below speaks the protocol directly.

import net from 'node:net';
import tls from 'node:tls';
import os from 'node:os';
import crypto from 'node:crypto';

const RANK = { critical: 4, high: 3, warning: 2, info: 1 };

// ---------------------------------------------------------------- minimal SMTP client

function lineReader() {
  let buf = '';
  let lines = [];
  let waiter = null;
  let failure = null;
  const tryResolve = () => {
    if (!waiter) return;
    if (failure) { const w = waiter; waiter = null; w.reject(failure); return; }
    const end = lines.findIndex((l) => /^\d{3}( |$)/.test(l));
    if (end < 0) return;
    const block = lines.splice(0, end + 1);
    const w = waiter; waiter = null;
    w.resolve({ code: Number(block[end].slice(0, 3)), text: block.map((l) => l.slice(4)).join('\n') });
  };
  return {
    onData(chunk) {
      buf += chunk.toString('utf8');
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { lines.push(buf.slice(0, i).replace(/\r$/, '')); buf = buf.slice(i + 1); }
      tryResolve();
    },
    fail(err) { failure = err; tryResolve(); },
    next() { return new Promise((resolve, reject) => { waiter = { resolve, reject }; tryResolve(); }); },
  };
}

const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
const wrap76 = (s) => s.match(/.{1,76}/g)?.join('\r\n') || '';

function buildMessage({ from, to, subject, text }) {
  return [
    `From: Shield360 Endpoint <${from}>`,
    `To: ${to.join(', ')}`,
    `Subject: =?UTF-8?B?${b64(subject)}?=`,
    `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${crypto.randomUUID()}@shield360>`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=utf-8',
    'Content-Transfer-Encoding: base64',   // base64 lines never start with ".", so no dot-stuffing is needed
    '',
    wrap76(b64(text)),
  ].join('\r\n');
}

export async function sendMail(o, { subject, text }) {
  const to = (o.to || []).filter(Boolean);
  if (!o.host || !o.from || !to.length) throw new Error('Email needs an SMTP server, a sender and at least one recipient.');
  const port = Number(o.port) || (o.security === 'tls' ? 465 : 587);
  const tlsOptions = { servername: o.host, rejectUnauthorized: !o.allowSelfSigned };
  const reader = lineReader();
  let sock = await new Promise((resolve, reject) => {
    const s = o.security === 'tls' ? tls.connect({ host: o.host, port, ...tlsOptions }) : net.connect({ host: o.host, port });
    s.once(o.security === 'tls' ? 'secureConnect' : 'connect', () => resolve(s));
    s.once('error', reject);
  });
  const attach = (s) => {
    s.setTimeout(20000, () => s.destroy(new Error('SMTP server timed out')));
    s.on('data', (d) => reader.onData(d));
    s.on('error', (e) => reader.fail(e));
  };
  attach(sock);
  const expect = async (codes) => {
    const r = await reader.next();
    if (!codes.includes(r.code)) throw new Error(`SMTP server replied ${r.code}: ${r.text.split('\n')[0]}`);
    return r;
  };
  const cmd = (line, codes) => { sock.write(`${line}\r\n`); return expect(codes); };
  try {
    await expect([220]);
    const me = os.hostname().replace(/[^\w.-]/g, '') || 'shield360';
    let ehlo = await cmd(`EHLO ${me}`, [250]);
    if (o.security === 'starttls') {
      await cmd('STARTTLS', [220]);
      sock.removeAllListeners('data');
      sock = await new Promise((resolve, reject) => {
        const t = tls.connect({ socket: sock, ...tlsOptions }, () => resolve(t));
        t.once('error', reject);
      });
      attach(sock);
      ehlo = await cmd(`EHLO ${me}`, [250]);
    }
    if (o.username) {
      if (/AUTH[^\n]*\bPLAIN\b/i.test(ehlo.text)) await cmd(`AUTH PLAIN ${b64(`\0${o.username}\0${o.password || ''}`)}`, [235]);
      else { await cmd('AUTH LOGIN', [334]); await cmd(b64(o.username), [334]); await cmd(b64(o.password || ''), [235]); }
    }
    await cmd(`MAIL FROM:<${o.from}>`, [250]);
    for (const r of to) await cmd(`RCPT TO:<${r}>`, [250, 251]);
    await cmd('DATA', [354]);
    sock.write(`${buildMessage({ from: o.from, to, subject, text })}\r\n.\r\n`);
    await expect([250]);
    sock.write('QUIT\r\n');
  } finally {
    sock.end();
  }
}

// ---------------------------------------------------------------- Teams and webhooks

async function postJson(url, body) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text().catch(() => '')).slice(0, 120)}`);
}

// Adaptive Card in the format accepted by Teams "Workflows" webhooks (Post to a channel when a webhook request is received).
function teamsCard(title, items, consoleUrl) {
  return {
    type: 'message',
    attachments: [{
      contentType: 'application/vnd.microsoft.card.adaptive',
      contentUrl: null,
      content: {
        $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
        type: 'AdaptiveCard',
        version: '1.4',
        body: [
          { type: 'TextBlock', size: 'Medium', weight: 'Bolder', text: title, wrap: true },
          ...items.slice(0, 15).map((a) => ({
            type: 'TextBlock', wrap: true, spacing: 'Small',
            text: `**${a.severity.toUpperCase()}** · ${a.hostname}: ${a.message}`,
            color: a.severity === 'critical' || a.severity === 'high' ? 'Attention' : 'Warning',
          })),
          ...(items.length > 15 ? [{ type: 'TextBlock', text: `…and ${items.length - 15} more`, isSubtle: true }] : []),
        ],
        actions: consoleUrl ? [{ type: 'Action.OpenUrl', title: 'Open Shield360 console', url: `${consoleUrl}/#/alerts` }] : [],
      },
    }],
  };
}

function textSummary(items, consoleUrl) {
  return [
    ...items.slice(0, 50).map((a) => `[${a.severity.toUpperCase()}] ${a.hostname}: ${a.message}  (${new Date(a.time).toLocaleString('en-GB')})`),
    ...(items.length > 50 ? [`...and ${items.length - 50} more`] : []),
    '',
    consoleUrl ? `Open the console: ${consoleUrl}/#/alerts` : 'Open the Shield360 console to review and respond.',
  ].join('\n');
}

// ---------------------------------------------------------------- notifier

export const DEFAULT_NOTIFICATIONS = {
  minSeverity: 'high',
  workstationOffline: false,   // workstations go offline every evening; servers going offline is always reported
  email: { enabled: false, host: '', port: 587, security: 'starttls', username: '', password: '', from: '', to: [], allowSelfSigned: false },
  teams: { enabled: false, url: '' },
  webhook: { enabled: false, url: '' },
};

export function createNotifier({ getSettings, lookupAgent, consoleUrl }) {
  const queue = [];
  const status = {};   // channel -> { ok, at, error }

  function enqueue(alert) { queue.push({ ...alert, time: Date.now() }); }

  async function deliver(s, items, title) {
    const url = consoleUrl();
    const jobs = [];
    if (s.email?.enabled) jobs.push(['email', () => sendMail(s.email, { subject: title, text: `${title}\n\n${textSummary(items, url)}` })]);
    if (s.teams?.enabled && s.teams.url) jobs.push(['teams', () => postJson(s.teams.url, teamsCard(title, items, url))]);
    if (s.webhook?.enabled && s.webhook.url) {
      jobs.push(['webhook', () => postJson(s.webhook.url, { source: 'Shield360 Endpoint', text: `${title}\n${textSummary(items, url)}`, alerts: items })]);
    }
    const results = {};
    for (const [name, run] of jobs) {
      try { await run(); status[name] = results[name] = { ok: true, at: Date.now() }; }
      catch (e) {
        status[name] = results[name] = { ok: false, at: Date.now(), error: e.message };
        console.error(`[notify] ${name} delivery failed: ${e.message}`);
      }
    }
    return results;
  }

  async function flush() {
    if (!queue.length) return;
    const s = getSettings();
    const items = queue.splice(0).map((a) => {
      const agent = lookupAgent(a.agentId);
      return { ...a, hostname: agent?.hostname || 'unknown', workstation: agent?.product_type === 1 };
    }).filter((a) => (RANK[a.severity] || 0) >= (RANK[s.minSeverity] || 3))
      .filter((a) => !(a.type === 'offline' && a.workstation && !s.workstationOffline));
    if (!items.length) return;
    const worst = items.some((a) => a.severity === 'critical') ? 'Critical' : items.some((a) => a.severity === 'high') ? 'High' : 'Warning';
    const hosts = [...new Set(items.map((a) => a.hostname))];
    const title = `Shield360 ${worst}: ${items.length === 1 ? items[0].message.slice(0, 80) : `${items.length} new alerts`} (${hosts.slice(0, 3).join(', ')}${hosts.length > 3 ? ', ...' : ''})`;
    await deliver(s, items, title);
  }

  setInterval(() => { flush().catch((e) => console.error('[notify]', e)); }, 30000).unref();

  async function test(s) {
    const item = { severity: 'high', hostname: os.hostname(), message: 'Test notification from Shield360 Endpoint. If you can read this, alerts will reach you.', time: Date.now(), type: 'test' };
    return deliver(s, [item], 'Shield360 test notification');
  }

  return { enqueue, flush, test, status: () => ({ ...status }) };
}
