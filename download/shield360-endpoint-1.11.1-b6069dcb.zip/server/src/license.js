// Shield360 Endpoint licensing: Ed25519-signed license files verified offline, a trial when no
// license is installed, seat limits, expiry warnings and a grace period before restricted mode.

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

// Public half of the vendor signing key (license-tools/keys). Licenses signed with any other key are rejected.
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEASLycTSG84ZLrt5omjc8gM6q2FYg9pvMgxaOra7pmFCo=
-----END PUBLIC KEY-----`;

export const TRIAL_DAYS = 30;
export const TRIAL_SEATS = 25;
export const WARN_DAYS = 30;    // banner before expiry
export const GRACE_DAYS = 14;   // full function after expiry, then restricted mode

const DAY = 86400 * 1000;

export function parseLicense(text) {
  const body = String(text || '')
    .replace(/-----(BEGIN|END) SHIELD360 LICENSE-----/g, '')
    .replace(/\s+/g, '');
  const [p, s, extra] = body.split('.');
  if (!p || !s || extra !== undefined) throw new Error('This is not a Shield360 license. Paste the whole license text, including the BEGIN/END lines.');
  const payload = Buffer.from(p, 'base64url');
  let valid = false;
  try { valid = crypto.verify(null, payload, PUBLIC_KEY, Buffer.from(s, 'base64url')); } catch { valid = false; }
  if (!valid) throw new Error('License signature is invalid: the license was modified or was not issued by Shield360.');
  const lic = JSON.parse(payload.toString('utf8'));
  if (lic.product !== 'Shield360 Endpoint' || !Number.isInteger(lic.seats) || lic.seats < 1 || !lic.customer) {
    throw new Error('License content is not valid for Shield360 Endpoint.');
  }
  if (lic.expiresAt && Number.isNaN(Date.parse(lic.expiresAt))) throw new Error('License has an invalid expiry date.');
  return lic;
}

export function createLicensing(db, dataDir) {
  db.exec('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
  const getSetting = (k) => db.prepare('SELECT value FROM settings WHERE key = ?').get(k)?.value;
  const setSetting = (k, v) => db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(k, String(v));

  // Identifies this installation; licenses can be locked to it.
  if (!getSetting('serverId')) setSetting('serverId', crypto.randomUUID());
  if (!getSetting('trialStartedAt')) setSetting('trialStartedAt', Date.now());
  const serverId = getSetting('serverId');
  const licenseFile = path.join(dataDir, 'license.lic');

  let license = null;
  let loadError = null;
  function load() {
    license = null;
    loadError = null;
    if (!fs.existsSync(licenseFile)) return;
    try {
      const lic = parseLicense(fs.readFileSync(licenseFile, 'utf8'));
      if (lic.serverId && lic.serverId !== serverId) throw new Error('The installed license belongs to a different Shield360 server.');
      license = lic;
    } catch (e) {
      loadError = e.message;
      console.error(`[license] ${e.message} Running without a valid license.`);
    }
  }
  load();

  function status() {
    const now = Date.now();
    const seatsUsed = db.prepare('SELECT COUNT(*) AS n FROM agents').get().n;
    let s;
    if (!license) {
      const ends = Number(getSetting('trialStartedAt')) + TRIAL_DAYS * DAY;
      const daysLeft = Math.ceil((ends - now) / DAY);
      s = {
        state: daysLeft > 0 ? 'trial' : 'trial_expired', licensed: false, customer: null, edition: 'Trial',
        seats: TRIAL_SEATS, expiresAt: new Date(ends).toISOString(), daysLeft: Math.max(0, daysLeft),
      };
    } else {
      const exp = license.expiresAt ? Date.parse(license.expiresAt) : null;
      const daysLeft = exp ? Math.ceil((exp - now) / DAY) : null;
      let state = 'active';
      if (exp && now > exp + GRACE_DAYS * DAY) state = 'expired';
      else if (exp && now > exp) state = 'grace';
      else if (exp && daysLeft <= WARN_DAYS) state = 'expiring';
      s = {
        state, licensed: true, licenseId: license.licenseId, customer: license.customer, edition: license.edition,
        seats: license.seats, issuedAt: license.issuedAt, expiresAt: license.expiresAt, daysLeft,
        graceEndsAt: exp ? new Date(exp + GRACE_DAYS * DAY).toISOString() : null,
        lockedToServer: !!license.serverId, notes: license.notes || '',
      };
    }
    s.serverId = serverId;
    s.seatsUsed = seatsUsed;
    s.seatsFree = Math.max(0, s.seats - seatsUsed);
    s.overSeats = seatsUsed > s.seats;
    s.restricted = s.state === 'expired' || s.state === 'trial_expired';
    s.canEnroll = !s.restricted && seatsUsed < s.seats;
    s.loadError = loadError;
    s.message = describe(s);
    return s;
  }

  function describe(s) {
    const date = s.expiresAt ? new Date(s.expiresAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '';
    switch (s.state) {
      case 'trial': return `Trial: ${s.daysLeft} day(s) left, up to ${s.seats} endpoints. Install a license to continue after the trial.`;
      case 'trial_expired': return 'The trial has ended. Endpoints stay protected, but enrolling endpoints and changing configuration are disabled until a license is installed.';
      case 'expiring': return `License expires on ${date} (${s.daysLeft} day(s)). Contact your Shield360 provider to renew.`;
      case 'grace': return `License expired on ${date}. Grace period ends ${new Date(s.graceEndsAt).toLocaleDateString('en-GB')}; after that enrolling endpoints and configuration changes are disabled.`;
      case 'expired': return 'License expired. Endpoints stay protected, but enrolling endpoints and changing configuration are disabled until the license is renewed.';
      default: return s.overSeats ? `${s.seatsUsed} endpoints enrolled but the license covers ${s.seats}. Remove endpoints or upgrade the license.` : '';
    }
  }

  function install(text) {
    const lic = parseLicense(text);
    if (lic.serverId && lic.serverId !== serverId) {
      throw new Error(`This license is locked to another server (${lic.serverId}). This server's ID is ${serverId}.`);
    }
    if (lic.expiresAt && Date.now() > Date.parse(lic.expiresAt) + GRACE_DAYS * DAY) throw new Error('This license has already expired.');
    fs.writeFileSync(licenseFile, String(text).trim() + '\n');
    load();
    return lic;
  }

  function remove() {
    fs.rmSync(licenseFile, { force: true });
    load();
  }

  return { status, install, remove, serverId };
}
