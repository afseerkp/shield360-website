// Local mirror of Microsoft Defender's full definition package (mpam-fe.exe), so endpoints that
// cannot reach Microsoft (isolated, air-gapped, proxy-restricted) still get the latest virus database.

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { once } from 'node:events';
import { execFile } from 'node:child_process';

// Official Microsoft download links for the latest security intelligence update.
const SOURCES = {
  x64: 'https://go.microsoft.com/fwlink/?LinkID=121721&arch=x64',
  x86: 'https://go.microsoft.com/fwlink/?LinkID=121721&arch=x86',
  arm64: 'https://go.microsoft.com/fwlink/?LinkID=121721&arch=arm',
};

export const DEFINITION_ARCHES = Object.keys(SOURCES);

export function compareVersions(a, b) {
  const pa = String(a || '').split('.').map(Number);
  const pb = String(b || '').split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

// On Windows, read the file version and verify Microsoft's Authenticode signature.
function inspectPackage(file) {
  if (process.platform !== 'win32') return Promise.resolve({ version: null, signature: 'unchecked (non-Windows server)' });
  const p = file.replace(/'/g, "''");
  const script = `$s = Get-AuthenticodeSignature -LiteralPath '${p}'; ` +
    `[pscustomobject]@{ status = [string]$s.Status; signer = [string]$s.SignerCertificate.Subject; ` +
    `version = (Get-Item -LiteralPath '${p}').VersionInfo.FileVersion } | ConvertTo-Json -Compress`;
  // A PSModulePath inherited from PowerShell 7 stops Windows PowerShell 5.1 loading its own modules.
  const env = Object.fromEntries(Object.entries(process.env).filter(([k]) => k.toLowerCase() !== 'psmodulepath'));
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 120000, env }, (err, stdout, stderr) => {
      if (err) return reject(new Error(`Could not inspect package: ${err.message}`));
      let info;
      try { info = JSON.parse(stdout); } catch { return reject(new Error(`Could not inspect package: ${stderr || stdout}`.trim())); }
      if (info.status !== 'Valid' || !/O=Microsoft Corporation/.test(info.signer)) {
        return reject(new Error(`Package signature is not a valid Microsoft signature (${info.status || stderr.trim() || 'no status'})`));
      }
      resolve({ version: info.version, signature: 'Valid (Microsoft Corporation)' });
    });
  });
}

export function createDefinitionMirror(dataDir, options) {
  const dir = path.join(dataDir, 'definitions');
  fs.mkdirSync(dir, { recursive: true });
  const metaFile = path.join(dir, 'mirror.json');
  let meta = {};
  try { meta = JSON.parse(fs.readFileSync(metaFile, 'utf8')); } catch { /* first run */ }
  const state = { running: false, lastCheck: null, lastError: null };
  let current = null;

  const fileFor = (arch) => path.join(dir, `mpam-fe-${arch}.exe`);

  async function refreshArch(arch) {
    // A HEAD request tells us whether Microsoft published something new since the last download.
    const head = await fetch(SOURCES[arch], { method: 'HEAD', redirect: 'follow' });
    if (!head.ok) throw new Error(`${arch}: Microsoft returned HTTP ${head.status}`);
    const stamp = [head.url, head.headers.get('etag'), head.headers.get('last-modified'), head.headers.get('content-length')].join('|');
    if (meta[arch]?.stamp === stamp && fs.existsSync(fileFor(arch))) return false;

    const res = await fetch(SOURCES[arch], { redirect: 'follow' });
    if (!res.ok || !res.body) throw new Error(`${arch}: download failed with HTTP ${res.status}`);
    // Keep the .exe extension: Windows picks the signature verifier by file extension.
    const tmp = path.join(dir, `download-${arch}.exe`);
    const out = fs.createWriteStream(tmp);
    const hash = crypto.createHash('sha256');
    let size = 0;
    try {
      for await (const chunk of res.body) {
        hash.update(chunk);
        size += chunk.length;
        if (!out.write(chunk)) await once(out, 'drain');
      }
      out.end();
      await once(out, 'finish');
      if (size < 1024 * 1024) throw new Error(`${arch}: package is suspiciously small (${size} bytes)`);
      const info = await inspectPackage(tmp);
      fs.renameSync(tmp, fileFor(arch));
      meta[arch] = {
        version: info.version, signature: info.signature, size, sha256: hash.digest('hex').toUpperCase(),
        downloadedAt: Date.now(), stamp,
      };
      fs.writeFileSync(metaFile, JSON.stringify(meta, null, 2));
      return true;
    } catch (e) {
      out.destroy();
      fs.rmSync(tmp, { force: true });
      throw e;
    }
  }

  function refresh() {
    if (current) return current;
    current = (async () => {
      state.running = true;
      const errors = [];
      const updated = [];
      for (const arch of options.arches) {
        try {
          if (await refreshArch(arch)) updated.push(`${arch} ${meta[arch].version || ''}`.trim());
        } catch (e) { errors.push(e.message); }
      }
      state.lastCheck = Date.now();
      state.lastError = errors.join('; ') || null;
      if (updated.length) console.log(`[definitions] Mirrored latest Defender definitions: ${updated.join(', ')}`);
      if (errors.length) console.error(`[definitions] ${state.lastError}`);
      return { updated, errors };
    })().finally(() => { state.running = false; current = null; });
    return current;
  }

  function start() {
    if (!options.enabled) return;
    setTimeout(refresh, 15000).unref();
    setInterval(refresh, options.refreshHours * 3600 * 1000).unref();
  }

  // What agents need: version per architecture (the download itself is authenticated).
  const forAgents = () => Object.fromEntries(
    Object.entries(meta).filter(([a]) => fs.existsSync(fileFor(a))).map(([a, m]) => [a, { version: m.version, size: m.size, sha256: m.sha256 }])
  );

  const status = () => ({
    enabled: !!options.enabled, arches: options.arches, refreshHours: options.refreshHours,
    running: state.running, lastCheck: state.lastCheck, lastError: state.lastError,
    packages: Object.fromEntries(Object.entries(meta).map(([a, m]) => [a, { ...m, stamp: undefined, available: fs.existsSync(fileFor(a)) }])),
  });

  return { refresh, start, forAgents, status, fileFor };
}
