// Ransomware readiness: scores an endpoint on the measures that decide whether an attack is
// stopped, contained and recoverable. Checks without data are reported as unknown and not scored.

const HOUR = 3600 * 1000;

// Newest recovery point (restore point or Windows Server Backup) as epoch ms, or null.
export function newestRecoveryPoint(recovery) {
  const times = [
    ...(recovery?.restorePoints || []).map((p) => Date.parse(p.newest)),
    Date.parse(recovery?.windowsBackup?.lastSuccess),
  ].filter((t) => Number.isFinite(t));
  return times.length ? Math.max(...times) : null;
}

// All signed-in users have Desktop and Documents in OneDrive (and at least one user is known).
export function oneDriveCovered(recovery) {
  const users = recovery?.oneDriveUsers || [];
  return users.length > 0 && users.every((u) => u.documents && u.desktop);
}

const shortName = (n) => String(n || '').split('\\').pop().toLowerCase();

export function computeReadiness(state, inventory, productType, policy, loggedOnUsers = []) {
  const sec = state?.security || {};
  const comp = state?.protection?.compliance || [];
  const actual = (setting) => comp.find((c) => c.setting === setting)?.actual;
  const def = sec.defender || {};
  const maxAge = policy?.recovery?.backupMonitoring?.maxAgeHours || 48;
  const isServer = productType !== 1;
  const checks = [];
  const add = (key, name, ok, detail, fix) => checks.push({ key, name, ok, detail, fix });

  add('realtime', 'Antivirus real-time protection', def.present === undefined ? null : !!(def.present && def.realTimeProtection),
    def.present ? (def.realTimeProtection ? 'On' : 'Off') : 'Microsoft Defender not active', 'Turn on real-time protection in the policy.');

  add('definitions', 'Virus definitions up to date', def.signatureAgeDays == null ? null : def.signatureAgeDays <= 3,
    def.signatureAgeDays == null ? 'Unknown' : `${def.signatureAgeDays} day(s) old`, 'Update virus definitions.');

  const asr = actual('Use advanced protection against ransomware');
  add('asr', 'Advanced ransomware protection rule', asr == null ? null : asr === 'Block', asr || 'Unknown',
    'Set the rule to Block in the policy (Exploit protection).');

  const cfa = actual('Ransomware protection (controlled folders)');
  add('cfa', 'Controlled folder access blocks ransomware', cfa == null ? null : cfa === 'Block', cfa || 'Unknown',
    'Set ransomware protection (controlled folders) to Block, after adding business apps to the allowed list.');

  const ai = policy?.autoIsolate || {};
  const isolates = !!(policy?.enforce && ai.enabled && ai.ransomware && (!isServer || !ai.excludeServers));
  add('isolation', 'Automatic isolation on ransomware', isolates,
    isolates ? 'On' : isServer && ai.excludeServers ? 'Servers excluded (alert only)' : 'Off',
    'Turn on automatic isolation with the ransomware trigger in the policy.');

  const smb1 = actual('SMBv1 server disabled (WannaCry/EternalBlue)');
  add('smb1', 'SMBv1 disabled', smb1 == null ? null : smb1 === 'Yes', smb1 || 'Unknown', 'Turn on "Disable SMBv1" in the policy.');

  const rdpOk = sec.rdpEnabled == null ? null : (!sec.rdpEnabled || sec.rdpNla === true);
  add('rdp', 'Remote Desktop off or protected by NLA', rdpOk,
    sec.rdpEnabled == null ? 'Unknown' : !sec.rdpEnabled ? 'Off' : sec.rdpNla ? 'On with NLA' : 'On without NLA', 'Require NLA for Remote Desktop in the policy.');

  const fw = sec.firewall || [];
  const fwOff = fw.filter((p) => !p.enabled).map((p) => p.name);
  add('firewall', 'Firewall on for all profiles', fw.length ? fwOff.length === 0 : null,
    !fw.length ? 'Unknown' : fwOff.length ? `${fwOff.join(', ')} off` : 'All on', 'Keep Windows Firewall on.');

  // Users who sign in to this PC should not be local administrators (direct membership).
  const users = (loggedOnUsers || []).map(shortName);
  const admins = (inventory?.localAdmins || []).map((a) => shortName(a.name));
  const adminUsers = users.filter((u) => admins.includes(u));
  add('admins', 'Signed-in users are not local administrators', !users.length || !inventory ? null : adminUsers.length === 0,
    !users.length ? 'No one signed in' : adminUsers.length ? `Admin: ${adminUsers.join(', ')}` : 'Standard users',
    'Remove local administrator rights from everyday user accounts.');

  const newest = newestRecoveryPoint(sec.recovery);
  const recent = newest && Date.now() - newest <= maxAge * HOUR;
  const covered = oneDriveCovered(sec.recovery);
  add('recovery', `Recent backup or restore point (${maxAge} h)${isServer ? '' : ', or files in OneDrive'}`,
    sec.recovery ? !!(recent || (!isServer && covered)) : null,
    !sec.recovery ? 'Unknown' : recent ? `Latest ${Math.round((Date.now() - newest) / HOUR)} h ago` : covered ? 'User folders in OneDrive' : newest ? `Latest ${Math.round((Date.now() - newest) / HOUR)} h ago` : 'None found',
    isServer ? 'Set up Windows Server Backup or turn on scheduled restore points in the policy.'
      : 'Turn on OneDrive folder protection or scheduled restore points in the policy.');

  const scored = checks.filter((c) => c.ok !== null);
  const score = scored.length ? Math.round((scored.filter((c) => c.ok).length / scored.length) * 100) : null;
  return { score, checks };
}
