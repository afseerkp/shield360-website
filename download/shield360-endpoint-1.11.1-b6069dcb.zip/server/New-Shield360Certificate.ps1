#Requires -Version 5.1
<#
.SYNOPSIS
    Creates a self-signed HTTPS certificate for the Shield360 server and enables TLS in config.json.
    Prefer a certificate from your internal CA when you have one (set tls.pfx in config.json).

.EXAMPLE
    .\New-Shield360Certificate.ps1 -DnsName shield360.corp.local, shield360
#>
[CmdletBinding()]
param(
    [string[]]$DnsName = @([Net.Dns]::GetHostEntry('').HostName, $env:COMPUTERNAME),
    [int]$Port = 8443,
    [int]$ValidYears = 5
)

$ErrorActionPreference = 'Stop'
$dataDir = Join-Path $PSScriptRoot 'data'
if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory $dataDir | Out-Null }

$cert = New-SelfSignedCertificate -DnsName ($DnsName | Select-Object -Unique) -CertStoreLocation Cert:\LocalMachine\My `
    -FriendlyName 'Shield360 Endpoint Server' -KeyExportPolicy Exportable -KeyAlgorithm RSA -KeyLength 2048 `
    -NotAfter (Get-Date).AddYears($ValidYears)

$bytes = New-Object byte[] 24
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
$passphrase = [Convert]::ToBase64String($bytes)
$secure = ConvertTo-SecureString $passphrase -AsPlainText -Force
Export-PfxCertificate -Cert $cert -FilePath (Join-Path $dataDir 'server.pfx') -Password $secure | Out-Null
Export-Certificate -Cert $cert -FilePath (Join-Path $dataDir 'server.cer') | Out-Null

$configPath = Join-Path $PSScriptRoot 'config.json'
$config = if (Test-Path $configPath) { Get-Content $configPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
$tls = [pscustomobject]@{ pfx = 'data/server.pfx'; passphrase = $passphrase; cert = ''; key = '' }
$config | Add-Member -NotePropertyName tls -NotePropertyValue $tls -Force
$config | Add-Member -NotePropertyName port -NotePropertyValue $Port -Force
$config | ConvertTo-Json -Depth 5 | Set-Content $configPath -Encoding UTF8

Write-Host "Certificate created for: $($DnsName -join ', ') (thumbprint $($cert.Thumbprint))" -ForegroundColor Green
Write-Host "TLS enabled on port $Port in config.json. Restart the server (and re-run Install-Shield360Server.ps1 to update the firewall port)."
Write-Host "Agents must trust data\server.cer: the console's Deploy page offers it, pass it with -CertificateFile, or push it via GPO."
