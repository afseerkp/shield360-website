# Testing enforcement and automatic isolation

This plan uses a spare test PC or virtual machine and takes about 30–45 minutes. It only uses harmless test files.

## Before you start

- **Take a snapshot of the VM** so you can roll back afterwards.
- **Use the hypervisor console (Hyper-V, VMware, VirtualBox), not RDP.** Isolation cuts RDP, so an RDP session will drop.
- **The server must be reachable from the VM.** Run the server with `npm start` in the `server` folder. It listens on port 8080 on all interfaces by default. Open that port in the server machine's firewall, and use its **IP or hostname, not `localhost`**, as the server URL.

## 1. Install the agent on the VM

1. On the console's **Deploy agent** page, copy the one-line install command. Check that the URL in it is the server's network address.
2. On the VM, open **PowerShell as Administrator** and paste the command.
3. Within a minute the VM appears under **Endpoints**.
4. **Wait at least 2 minutes before step 4.** On its first run the agent records Defender detections that already exist as a baseline, so older detections don't trigger isolation.

## 2. Create a test policy and assign it

1. Go to **Protection policies**, then **New policy**, and name it `Isolation test`.
2. Set **Mode** to **Enforce**.
3. Under **Automatic isolation**:
   - Tick **Isolate automatically when compromised**.
   - Tick **Any malware detection (even if removed)**. The test file in step 4 is always removed by Defender, so the default "could not remove" trigger would never fire.
   - If the VM runs **Windows Server**, untick **Servers: alert only**.
4. Save. Open the VM's endpoint page, go to the **Protection** tab, choose `Isolation test`, and click **Assign**.

Your other endpoints stay on their own policy, so only the VM is affected.

## 3. Test enforcement and self-healing

1. After about 1–2 minutes the **Protection** tab shows the status **Applied** and a compliance list. Most settings should now be green.
2. On the VM, check the results:
   ```powershell
   Get-MpPreference | Select PUAProtection, EnableNetworkProtection, CloudBlockLevel
   Get-NetFirewallProfile | Select Name, Enabled, DefaultInboundAction
   Get-Content C:\ProgramData\Shield360\logs\agent.log -Tail 20
   ```
3. To test tamper repair, turn one setting off on the VM:
   ```powershell
   Set-MpPreference -PUAProtection 0
   ```
4. In the console, run **Actions → Re-apply protection policy now**, or wait up to 15 minutes. Then run `Get-MpPreference` again: `PUAProtection` should be back to `1`.

## 4. Trigger a safe test detection

Use the **EICAR test file**. It's the industry-standard harmless file that every antivirus product detects on purpose; it contains no malicious code.

1. On the VM, open Edge and go to **eicar.org**. Find the anti-malware test file page and download `eicar.com.txt`.
2. Defender blocks or removes it within seconds and shows a notification.
3. Within about 1 minute (one agent cycle), the agent sees the new detection and **isolates the VM**.

## 5. Verify isolation

**In the console:**

- The endpoint shows a red **ISOLATED** badge.
- **Alerts** has a critical *"Automatically isolated from the network: malware …"* alert.
- **Attack events** shows *Malware blocked* and *AUTO-ISOLATED*.

**On the VM:**

```powershell
Test-NetConnection 8.8.8.8 -Port 443                     # should FAIL (internet blocked)
Test-NetConnection <server-ip> -Port 8080                # should SUCCEED (console still reachable)
Get-NetFirewallRule -Group 'Shield360 Isolation' | Select DisplayName, Enabled, Direction
```

Websites in Edge should fail to load, and so should pinging or browsing another machine on the LAN.

**Restart the VM.** After it boots it should still be isolated and still reporting to the console.

## 6. Release isolation

**From the console (normal way):** open the endpoint page, click **Release isolation**, and confirm. Within about a minute:

- The badge and alert clear.
- `Get-NetFirewallRule -Group 'Shield360 Isolation'` returns nothing.
- `Test-NetConnection 8.8.8.8 -Port 443` succeeds again.

**Break-glass (if the VM can't reach the server):** in an elevated PowerShell on the VM:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Program Files\Shield360\Shield360Agent.ps1" -ReleaseIsolation
```

If you want to see a manual isolation too, click **Isolate** on the endpoint page, check that the reason says "Isolated manually", then release it.

## 7. Optional extra tests

- **USB control:** in the `Isolation test` policy, set **USB storage** to **Block completely** and save. After a minute, plug a USB flash drive into the VM (pass it through from the hypervisor). It should not open in Explorer, and the **Protection** tab shows *USB storage: Blocked*. Switch to **Read-only**, reconnect the drive: files open, but copying a file onto it fails with *access denied*. Switch back to **Allow** to restore access.
- **Website blocking:** add `example.com` (or click **+ Social media**) under **Website blocking** and save. After a minute, open the site in Edge on the VM: you should see *"blocked by your organization"*. `edge://policy` lists it under `URLBlocklist`, and `ping example.com` resolves to `0.0.0.0`. Remove it and save; after a minute the site loads again.

- **Virus definitions:** open **Virus definitions** in the console. The mirror should show **Ready** about a minute after the server starts, and the VM should show **Latest**. Click **Update all endpoints now**; within a minute the VM's **Actions** tab shows the result, for example *"Virus definitions are 1.461.x (unchanged)"*. To test the mirror itself, isolate the VM and run the update again: the result should say *"Isolated: skipping Microsoft update servers"*. If the VM was behind, it should also say *"Installed definitions from the Shield360 server mirror"*.

- **Brute-force blocking:** from another machine, try to RDP to the VM with a wrong password 10 times within 10 minutes. That machine's IP then appears under **Protection → Auto-blocked attackers** and an event is logged. Click **Unblock** to remove it.
- **Domain blocklist:** on the **Blocklist** page, add a harmless domain such as `example.org`. After a minute, `ping example.org` on the VM resolves to `0.0.0.0`. **Remove it afterwards:** the blocklist is global, so every endpoint with an enforcing policy blocks it.

## 8. Clean up

1. Acknowledge the test alerts.
2. Remove any test blocklist entries.
3. Either run `Uninstall-Shield360Agent.ps1` as Administrator on the VM and remove the endpoint in the console, or revert the VM to its snapshot.

## If something doesn't happen

- **First stop: the agent log** at `C:\ProgramData\Shield360\logs\agent.log`. Every cycle, policy apply, detection and isolation is logged there, including the reason when something is skipped. For example, a "report-only" or "servers are excluded" message means the policy settings in step 2 aren't applied yet.
- **No isolation after the EICAR test:** check that "Any malware detection" is ticked and that the policy shows **Applied**. Also check the 2-minute wait from step 1.
- **Endpoint not appearing:** the VM probably can't reach the server URL. Run `Test-NetConnection <server> -Port 8080` on the VM.
