#Requires -Version 5.1
<#
.SYNOPSIS
    Registers the Shield360 Endpoint server to start automatically on this
    Windows Server (scheduled task running as SYSTEM) and opens the firewall port.

.EXAMPLE
    .\Install-Shield360Server.ps1
    .\Install-Shield360Server.ps1 -Uninstall
#>
[CmdletBinding()]
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$TaskName = 'Shield360 Server'
$TaskPath = '\Shield360\'
$FirewallRule = 'Shield360 Endpoint Server'
$ServerDir = $PSScriptRoot

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated (Administrator) PowerShell.'
}

if ($Uninstall) {
    Stop-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false -ErrorAction SilentlyContinue
    Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
    Write-Host 'Shield360 server task and firewall rule removed (data and config kept).'
    return
}

$node = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
if (-not $node) { throw 'Node.js 22.13+ is required. Install the LTS from https://nodejs.org and re-run.' }
$major = [int]((& $node --version).TrimStart('v').Split('.')[0])
if ($major -lt 22) { throw "Node.js 22.13+ is required (found $(& $node --version))." }

# First run creates config.json, the database and the admin password.
$configPath = Join-Path $ServerDir 'config.json'
if (-not (Test-Path $configPath)) {
    Write-Host 'Initialising configuration...'
    $p = Start-Process -FilePath $node -ArgumentList '--disable-warning=ExperimentalWarning', 'src/server.js' `
        -WorkingDirectory $ServerDir -PassThru -WindowStyle Hidden
    Start-Sleep -Seconds 3
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
}
$config = Get-Content $configPath -Raw | ConvertFrom-Json

# Restricts a file or folder to SYSTEM and Administrators. A folder gets inheritable grants and everything
# inside is reset to inherit them; a file gets file grants. (Applying folder inheritance flags to files,
# or /T together with /inheritance:r, can leave files with no access at all - not even for SYSTEM.)
function Protect-Shield360Path([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $isDir = Test-Path -LiteralPath $Path -PathType Container
    if ($isDir) {
        & icacls.exe $Path /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /Q | Out-Null
        if ($LASTEXITCODE -eq 0 -and (Get-ChildItem -LiteralPath $Path -Force | Select-Object -First 1)) {
            & icacls.exe (Join-Path $Path '*') /reset /T /C /Q | Out-Null
        }
    } else {
        & icacls.exe $Path /inheritance:r /grant:r '*S-1-5-18:F' '*S-1-5-32-544:F' /Q | Out-Null
    }
    if ($LASTEXITCODE -ne 0) { throw "Failed to set permissions on $Path" }
    $items = @(Get-Item -LiteralPath $Path -Force)
    if ($isDir) { $items += @(Get-ChildItem -LiteralPath $Path -Recurse -Force) }
    foreach ($i in $items) {
        $sids = (Get-Acl -LiteralPath $i.FullName).Access | ForEach-Object { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
        if ($sids -notcontains 'S-1-5-18') { throw "Permissions on $($i.FullName) no longer allow SYSTEM to read it." }
    }
}

# Protect the config (enrollment token, TLS passphrase) and the data folder (database, certificate).
Protect-Shield360Path $configPath
Protect-Shield360Path (Join-Path $ServerDir 'data')

$action = New-ScheduledTaskAction -Execute $node -Argument '--disable-warning=ExperimentalWarning src/server.js' -WorkingDirectory $ServerDir
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
$taskPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Stop-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Action $action -Trigger (New-ScheduledTaskTrigger -AtStartup) `
    -Settings $settings -Principal $taskPrincipal -Description 'Shield360 Endpoint management server' -Force | Out-Null

Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $FirewallRule -Direction Inbound -Protocol TCP -LocalPort $config.port -Action Allow | Out-Null

Start-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath
$scheme = if ($config.tls.pfx -or $config.tls.cert) { 'https' } else { 'http' }

# Confirm the server is actually listening before reporting success.
$listening = $false
for ($i = 0; $i -lt 20 -and -not $listening; $i++) {
    Start-Sleep -Seconds 1
    $listening = [bool](Get-NetTCPConnection -State Listen -LocalPort $config.port -ErrorAction SilentlyContinue)
}
Write-Host ''
if (-not $listening) {
    $log = Join-Path $ServerDir 'data\logs\server.log'
    Write-Host "The Shield360 server did not start on port $($config.port)." -ForegroundColor Red
    if (Test-Path $log) { Write-Host 'Last lines of the server log:'; Get-Content $log -Tail 15 | ForEach-Object { Write-Host "    $_" } }
    Write-Host "To see the error directly: Stop-ScheduledTask -TaskName '$TaskName' -TaskPath '$TaskPath'; cd '$ServerDir'; node src/server.js"
    throw 'Shield360 server failed to start.'
}
Write-Host "Shield360 server running: $($scheme)://$($env:COMPUTERNAME):$($config.port)" -ForegroundColor Green
Write-Host "  On this server:  $($scheme)://localhost:$($config.port)"

# Show the initial admin sign-in so nobody has to open the protected data folder.
# The file only exists until the administrator deletes it after the first sign-in.
$pwFile = Join-Path $ServerDir 'data\initial-admin-password.txt'
if (Test-Path $pwFile) {
    $lines = Get-Content $pwFile
    $user = ($lines | Where-Object { $_ -like 'username:*' } | Select-Object -First 1) -replace '^username:\s*', ''
    $pass = ($lines | Where-Object { $_ -like 'password:*' } | Select-Object -First 1) -replace '^password:\s*', ''
    if ($user -and $pass) {
        Write-Host ''
        Write-Host '  ================ Initial admin sign-in ================' -ForegroundColor Yellow
        Write-Host "    Username : $user" -ForegroundColor Yellow
        Write-Host "    Password : $pass" -ForegroundColor Yellow
        Write-Host '  =======================================================' -ForegroundColor Yellow
        Write-Host '  At first sign-in you must choose a new password; this initial one then stops'
        Write-Host '  working and its file is deleted automatically.'
    }
}
