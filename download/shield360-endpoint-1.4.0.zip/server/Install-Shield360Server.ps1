#Requires -Version 5.1
<#
.SYNOPSIS
    Registers the Shield360 Endpoint server to start automatically on this
    Windows Server (scheduled task running as SYSTEM) and opens the firewall port.

.EXAMPLE
    .\Install-Shield360Server.ps1
    .\Install-Shield360Server.ps1 -Uninstall
#>
[CmdletBinding()]
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$TaskName = 'Shield360 Server'
$TaskPath = '\Shield360\'
$FirewallRule = 'Shield360 Endpoint Server'
$ServerDir = $PSScriptRoot

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated (Administrator) PowerShell.'
}

if ($Uninstall) {
    Stop-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false -ErrorAction SilentlyContinue
    Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
    Write-Host 'Shield360 server task and firewall rule removed (data and config kept).'
    return
}

$node = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
if (-not $node) { throw 'Node.js 22.13+ is required. Install the LTS from https://nodejs.org and re-run.' }
$major = [int]((& $node --version).TrimStart('v').Split('.')[0])
if ($major -lt 22) { throw "Node.js 22.13+ is required (found $(& $node --version))." }

# First run creates config.json, the database and the admin password.
$configPath = Join-Path $ServerDir 'config.json'
if (-not (Test-Path $configPath)) {
    Write-Host 'Initialising configuration...'
    $p = Start-Process -FilePath $node -ArgumentList '--disable-warning=ExperimentalWarning', 'src/server.js' `
        -WorkingDirectory $ServerDir -PassThru -WindowStyle Hidden
    Start-Sleep -Seconds 3
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
}
$config = Get-Content $configPath -Raw | ConvertFrom-Json

# Protect the config (enrollment token, TLS passphrase) and database.
foreach ($item in $configPath, (Join-Path $ServerDir 'data')) {
    & icacls.exe $item /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /T /Q | Out-Null
}

$action = New-ScheduledTaskAction -Execute $node -Argument '--disable-warning=ExperimentalWarning src/server.js' -WorkingDirectory $ServerDir
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
$taskPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Stop-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Action $action -Trigger (New-ScheduledTaskTrigger -AtStartup) `
    -Settings $settings -Principal $taskPrincipal -Description 'Shield360 Endpoint management server' -Force | Out-Null

Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $FirewallRule -Direction Inbound -Protocol TCP -LocalPort $config.port -Action Allow | Out-Null

Start-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath
$scheme = if ($config.tls.pfx -or $config.tls.cert) { 'https' } else { 'http' }
Write-Host ''
Write-Host "Shield360 server running: $($scheme)://$($env:COMPUTERNAME):$($config.port)" -ForegroundColor Green
$pw = Join-Path $ServerDir 'data\initial-admin-password.txt'
if (Test-Path $pw) { Write-Host "Initial admin credentials: $pw" }
