'use strict';

// ---------------------------------------------------------------- helpers

const $ = (sel, root = document) => root.querySelector(sel);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  if (res.status === 401 && !url.startsWith('/api/login')) { showLogin(); throw new Error('Not signed in'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add('hidden'), 3500);
}

function ago(ts) {
  if (!ts) return 'never';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return `${Math.max(s, 0)}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}
const fmtDate = (v) => (v ? new Date(v).toLocaleString() : '—');
const pct = (v) => (v == null ? '—' : `${Math.round(v)}%`);

function meter(v) {
  if (v == null) return '<span class="muted">—</span>';
  const cls = v >= 90 ? 'bad' : v >= 75 ? 'warn' : '';
  return `<div class="meter"><div class="bar"><i class="${cls}" style="width:${Math.min(100, v)}%"></i></div><span>${Math.round(v)}%</span></div>`;
}

const sevBadge = (s) => `<span class="badge ${esc(s)}">${esc(s)}</span>`;
const statusDot = (on) => `<span class="dot ${on ? 'on' : 'off'}" title="${on ? 'Online' : 'Offline'}"></span>`;
const protBadge = (p) => `<span class="badge ${esc(p.level)}">${esc(p.label)}</span>`;
const bool = (v, good = 'Yes', bad = 'No') =>
  v == null ? '<span class="badge">Unknown</span>' : v ? `<span class="badge good">${good}</span>` : `<span class="badge bad">${bad}</span>`;

// SVG line chart for metric history.
function lineChart(rows, series) {
  const W = 600, H = 180, L = 30, R = 8, T = 8, B = 20;
  if (rows.length < 2) return '<div class="empty">Not enough data yet</div>';
  const t0 = rows[0].t, t1 = rows[rows.length - 1].t;
  const x = (t) => L + ((t - t0) / Math.max(1, t1 - t0)) * (W - L - R);
  const y = (v) => T + (1 - Math.min(100, Math.max(0, v)) / 100) * (H - T - B);
  let svg = `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">`;
  for (const g of [0, 25, 50, 75, 100]) {
    svg += `<line class="grid-line" x1="${L}" x2="${W - R}" y1="${y(g)}" y2="${y(g)}"/><text class="axis" x="${L - 4}" y="${y(g) + 3}" text-anchor="end">${g}</text>`;
  }
  for (const i of [0, Math.floor(rows.length / 2), rows.length - 1]) {
    const d = new Date(rows[i].t);
    svg += `<text class="axis" x="${x(rows[i].t)}" y="${H - 4}" text-anchor="${i === 0 ? 'start' : i === rows.length - 1 ? 'end' : 'middle'}">${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}</text>`;
  }
  for (const s of series) {
    const pts = rows.filter((r) => r[s.key] != null).map((r) => `${x(r.t).toFixed(1)},${y(r[s.key]).toFixed(1)}`).join(' ');
    svg += `<polyline fill="none" stroke="var(${s.color})" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round" points="${pts}"/>`;
  }
  svg += '</svg>';
  svg += `<div class="legend">${series.map((s) => `<span><i style="background:var(${s.color})"></i>${s.label}</span>`).join('')}</div>`;
  return svg;
}

// ---------------------------------------------------------------- auth

let me = null;

function showLogin() {
  me = null;
  $('#app').classList.add('hidden');
  $('#login').classList.remove('hidden');
  $('#login-form [name=password]').focus();
}

async function boot() {
  try {
    me = await api('GET', '/api/me');
  } catch { return; }
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#whoami').textContent = `Signed in as ${me.username} · v${me.version}`;
  const banner = $('#banner');
  if (me.mustChange) {
    banner.innerHTML = 'You are using the initial admin password. <a href="#/settings">Change it now</a>.';
    banner.classList.remove('hidden');
  } else banner.classList.add('hidden');
  render();
}

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  $('#login-error').textContent = '';
  try {
    await api('POST', '/api/login', { username: f.get('username'), password: f.get('password') });
    e.target.password.value = '';
    boot();
  } catch (err) { $('#login-error').textContent = err.message; }
});

$('#logout').addEventListener('click', async () => {
  await api('POST', '/api/logout').catch(() => {});
  showLogin();
});

// ---------------------------------------------------------------- router

const view = () => $('#view');
let refreshTimer = null;
let detailTab = 'overview';

function route() {
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  return { page: parts[0] || 'overview', id: parts[1] };
}

async function render(soft = false) {
  if (!me) return;
  const r = route();
  document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === r.page));
  clearTimeout(refreshTimer);
  try {
    if (r.page === 'overview') await renderOverview();
    else if (r.page === 'endpoints' && r.id) await renderEndpoint(r.id, soft);
    else if (r.page === 'endpoints') await renderEndpoints(soft);
    else if (r.page === 'alerts') await renderAlerts(soft);
    else if (r.page === 'events') await renderEvents();
    else if (r.page === 'policies') { if (!soft) await renderPolicies(r.id); }
    else if (r.page === 'groups') { if (!soft) await renderGroups(r.id); }
    else if (r.page === 'blocklist') { if (!soft) await renderBlocklist(); }
    else if (r.page === 'definitions') await renderDefinitions();
    else if (r.page === 'deploy') { if (!soft) await renderDeploy(); }
    else if (r.page === 'settings') { if (!soft) await renderSettings(); }
    else view().innerHTML = '<div class="empty">Page not found</div>';
    updateAlertPill();
  } catch (err) {
    if (me) view().innerHTML = `<div class="card error">${esc(err.message)}</div>`;
  }
  if (['overview', 'endpoints', 'alerts', 'events', 'definitions'].includes(r.page)) {
    refreshTimer = setTimeout(() => render(true), 15000);
  }
}

window.addEventListener('hashchange', () => { detailTab = 'overview'; render(); });

async function updateAlertPill() {
  const s = await api('GET', '/api/summary').catch(() => null);
  if (!s) return;
  const n = (s.alertsBySeverity.critical || 0) + (s.alertsBySeverity.high || 0);
  const pill = $('#nav-alert-count');
  pill.textContent = n;
  pill.classList.toggle('hidden', n === 0);
}

// ---------------------------------------------------------------- overview

async function renderOverview() {
  const s = await api('GET', '/api/summary');
  const sev = s.alertsBySeverity;
  const offline = s.total - s.online;
  const unprotected = s.total - s.protected;
  view().innerHTML = `
    <div class="page-head"><div><h1>Overview</h1><div class="muted">Security posture across all managed endpoints</div></div></div>
    <div class="tiles">
      <div class="tile"><div class="label">Endpoints</div><div class="value">${s.total}</div><div class="sub">${s.servers} servers · ${s.workstations} workstations</div></div>
      <div class="tile good"><div class="label">Online</div><div class="value">${s.online}</div><div class="sub">${offline} offline</div></div>
      <div class="tile ${unprotected ? 'bad' : 'good'}"><div class="label">Protected</div><div class="value">${s.total ? Math.round((s.protected / s.total) * 100) : 0}%</div><div class="sub">${unprotected} need attention</div></div>
      <div class="tile ${sev.critical ? 'bad' : ''}"><div class="label">Critical alerts</div><div class="value">${sev.critical || 0}</div><div class="sub">${sev.high || 0} high</div></div>
      <div class="tile"><div class="label">Warnings</div><div class="value">${sev.warning || 0}</div><div class="sub">${sev.info || 0} informational</div></div>
    </div>
    <div class="tiles">
      <div class="tile good"><div class="label">Attacks blocked (24h)</div><div class="value">${s.blocked24h}</div><div class="sub">malware, exploits, brute force, bad sites</div></div>
      <div class="tile ${s.malware24h ? 'bad' : ''}"><div class="label">Malware detections (24h)</div><div class="value">${s.malware24h}</div></div>
      <div class="tile ${s.compliance != null && s.compliance < 90 ? 'bad' : 'good'}"><div class="label">Policy compliance</div><div class="value">${s.compliance == null ? '—' : s.compliance + '%'}</div><div class="sub"><a href="#/policies">Protection policies</a></div></div>
      <div class="tile ${s.isolated ? 'bad' : ''}"><div class="label">Isolated endpoints</div><div class="value">${s.isolated}</div></div>
      <div class="tile ${s.definitions.outdated ? 'bad' : 'good'}"><div class="label">Virus definitions up to date</div>
        <div class="value">${s.definitions.upToDate}/${s.definitions.total}</div>
        <div class="sub"><a href="#/definitions">Latest ${esc(s.definitions.latest || '—')}</a></div></div>
    </div>
    <div class="card" style="margin-bottom:16px">
      <h2>Latest attack activity</h2>
      ${s.recentEvents.length ? eventsList(s.recentEvents, true) + '<div style="margin-top:10px"><a href="#/events">All attack events →</a></div>'
        : '<div class="empty">No attacks or blocks recorded yet.</div>'}
    </div>
    <div class="grid two">
      <div class="card">
        <h2>Open alerts</h2>
        ${s.recentAlerts.length ? `<div class="list">${s.recentAlerts.map((a) => `
          <div class="row">${sevBadge(a.severity)}
            <div class="grow"><div><a href="#/endpoints/${esc(a.agent_id)}">${esc(a.hostname)}</a> — ${esc(a.message)}</div></div>
            <span class="muted nowrap">${ago(a.updated_at)}</span></div>`).join('')}</div>
          <div style="margin-top:10px"><a href="#/alerts">View all alerts →</a></div>`
        : '<div class="empty">No open alerts. All clear.</div>'}
      </div>
      <div class="card">
        <h2>Needs attention</h2>
        ${s.attention.length ? `<div class="list">${s.attention.map((a) => `
          <div class="row">${statusDot(a.online)}
            <div class="grow"><div><a href="#/endpoints/${esc(a.id)}">${esc(a.hostname)}</a> <span class="muted">· ${esc(a.type)}</span></div></div>
            ${sevBadge(a.worstSeverity)}<span class="muted nowrap">${a.openAlerts} alert${a.openAlerts === 1 ? '' : 's'}</span></div>`).join('')}</div>`
        : s.total ? '<div class="empty">No endpoints with critical or high alerts.</div>'
          : '<div class="empty">No endpoints enrolled yet. <a href="#/deploy">Deploy the agent</a>.</div>'}
      </div>
    </div>`;
}

// ---------------------------------------------------------------- endpoints list

const listState = { q: '', filter: 'all', group: '', selected: new Set() };

async function renderEndpoints(soft) {
  const [agents, { groups }] = await Promise.all([api('GET', '/api/agents'), api('GET', '/api/groups')]);
  const known = new Set(agents.map((a) => a.id));
  for (const id of listState.selected) if (!known.has(id)) listState.selected.delete(id);
  if (!soft || !$('#ep-table')) {
    view().innerHTML = `
      <div class="page-head"><div><h1>Endpoints</h1><div class="muted">${agents.length} enrolled</div></div>
        <div class="actions"><a class="btn" href="#/groups">Endpoint groups</a><a class="btn primary" href="#/deploy">Add endpoint</a></div></div>
      <div class="toolbar">
        <input id="ep-search" placeholder="Search hostname, IP, user, OS, group…" value="${esc(listState.q)}">
        <select id="ep-group">
          <option value="">All groups</option>
          ${groups.map((g) => `<option value="${g.id}" ${String(listState.group) === String(g.id) ? 'selected' : ''}>${esc(g.name)} (${g.endpoints})</option>`).join('')}
        </select>
        <select id="ep-filter">
          ${[['all', 'All endpoints'], ['servers', 'Servers'], ['workstations', 'Workstations'], ['offline', 'Offline'], ['risk', 'At risk']]
            .map(([v, l]) => `<option value="${v}" ${listState.filter === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </div>
      <div id="bulk-bar" class="card hidden" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px;padding:10px 14px">
        <b id="bulk-count"></b>
        <span class="muted">Move to group</span>
        <select id="bulk-group" style="width:auto">${groups.map((g) => `<option value="${g.id}">${esc(g.name)} (policy: ${esc(g.policyName)})</option>`).join('')}</select>
        <button class="btn primary" id="bulk-move">Move</button>
        <button class="btn ghost" id="bulk-clear">Clear selection</button>
      </div>
      <div class="card table-wrap"><table id="ep-table"></table></div>`;
    $('#ep-search').addEventListener('input', (e) => { listState.q = e.target.value; drawTable(); });
    $('#ep-filter').addEventListener('change', (e) => { listState.filter = e.target.value; drawTable(); });
    $('#ep-group').addEventListener('change', (e) => { listState.group = e.target.value; drawTable(); });
    $('#bulk-clear').addEventListener('click', () => { listState.selected.clear(); drawTable(); });
    $('#bulk-move').addEventListener('click', async () => {
      const g = groups.find((x) => String(x.id) === $('#bulk-group').value);
      if (!confirm(`Move ${listState.selected.size} endpoint(s) to "${g.name}"? They will apply the "${g.policyName}" policy at their next check-in.`)) return;
      const r = await api('POST', `/api/groups/${g.id}/members`, { agentIds: [...listState.selected] });
      toast(`${r.moved} endpoint(s) moved to ${g.name}`);
      listState.selected.clear();
      renderEndpoints();
    });
  }
  function drawTable() {
    const q = listState.q.toLowerCase();
    const rows = agents.filter((a) => {
      const f = listState.filter;
      if (listState.group && String(a.groupId) !== String(listState.group)) return false;
      if (f === 'servers' && a.type === 'Workstation') return false;
      if (f === 'workstations' && a.type !== 'Workstation') return false;
      if (f === 'offline' && a.online) return false;
      if (f === 'risk' && !(a.worstSeverity === 'critical' || a.worstSeverity === 'high' || a.protection.level === 'bad')) return false;
      if (!q) return true;
      return [a.hostname, a.osName, a.domain, a.tags, a.groupName, ...a.ipAddresses, ...a.loggedOnUsers].join(' ').toLowerCase().includes(q);
    });
    const allChecked = rows.length > 0 && rows.every((a) => listState.selected.has(a.id));
    $('#ep-table').innerHTML = `
      <thead><tr><th><input type="checkbox" id="sel-all" title="Select all shown" ${allChecked ? 'checked' : ''}></th><th></th><th>Hostname</th><th>Group</th><th>Type</th>
        <th class="hide-sm">OS</th><th class="hide-sm">IP address</th><th class="hide-sm">User</th>
        <th>CPU</th><th>Memory</th><th>Disk</th><th>Protection</th><th>Alerts</th><th>Last seen</th></tr></thead>
      <tbody>${rows.length ? rows.map((a) => `
        <tr class="clickable" data-id="${esc(a.id)}">
          <td><input type="checkbox" data-sel="${esc(a.id)}" ${listState.selected.has(a.id) ? 'checked' : ''}></td>
          <td>${statusDot(a.online)}</td>
          <td><b>${esc(a.hostname)}</b>${a.tags ? `<div class="muted" style="font-size:12px">${esc(a.tags)}</div>` : ''}</td>
          <td class="nowrap"><a href="#/groups/${a.groupId}">${esc(a.groupName)}</a>
            <div class="muted" style="font-size:12px">${esc(a.policyName)}${a.policySource === 'override' ? ' (override)' : ''}</div></td>
          <td class="nowrap">${esc(a.type)}</td>
          <td class="hide-sm">${esc((a.osName || '').replace('Microsoft ', ''))}</td>
          <td class="hide-sm mono">${esc(a.ipAddresses[0] || '')}</td>
          <td class="hide-sm">${esc(a.loggedOnUsers.join(', '))}</td>
          <td>${meter(a.online ? a.cpu : null)}</td><td>${meter(a.online ? a.mem : null)}</td><td>${meter(a.disk)}</td>
          <td class="nowrap">${a.isolated ? '<span class="badge isolated">ISOLATED</span> ' : ''}${protBadge(a.protection)}${a.compliance != null ? ` <span class="muted" title="Policy compliance">${a.compliance}%</span>` : ''}</td>
          <td>${a.openAlerts ? sevBadge(a.worstSeverity) + ` <span class="muted">${a.openAlerts}</span>` : '<span class="muted">—</span>'}</td>
          <td class="nowrap muted">${ago(a.lastSeen)}</td>
        </tr>`).join('') : `<tr><td colspan="14" class="empty">${agents.length ? 'No endpoints match.' : 'No endpoints enrolled yet. <a href="#/deploy">Deploy the agent</a>.'}</td></tr>`}
      </tbody>`;
    $('#ep-table').querySelectorAll('tr[data-id]').forEach((tr) =>
      tr.addEventListener('click', (e) => {
        if (e.target.closest('input, a')) return;   // checkboxes and group links don't open the endpoint
        location.hash = `#/endpoints/${tr.dataset.id}`;
      }));
    $('#ep-table').querySelectorAll('[data-sel]').forEach((cb) => cb.addEventListener('change', () => {
      if (cb.checked) listState.selected.add(cb.dataset.sel); else listState.selected.delete(cb.dataset.sel);
      updateBulkBar();
    }));
    $('#sel-all')?.addEventListener('change', (e) => {
      for (const a of rows) { if (e.target.checked) listState.selected.add(a.id); else listState.selected.delete(a.id); }
      drawTable();
    });
    updateBulkBar();
  }
  function updateBulkBar() {
    const n = listState.selected.size;
    $('#bulk-bar').classList.toggle('hidden', n === 0);
    $('#bulk-count').textContent = `${n} selected`;
  }
  drawTable();
}

// ---------------------------------------------------------------- endpoint detail

let actionNames = null;

async function renderEndpoint(id, soft) {
  const [a, metrics, pol, { groups }] = await Promise.all([
    api('GET', `/api/agents/${id}`), api('GET', `/api/agents/${id}/metrics?hours=24`), api('GET', '/api/policies'), api('GET', '/api/groups'),
  ]);
  actionNames = actionNames || (await api('GET', '/api/command-actions'));
  const sec = a.state.security || {};
  const m = a.state.metrics || {};
  const prot = a.state.protection || {};
  const inv = a.inventory || {};
  const openAlerts = a.alerts.filter((x) => !x.resolved_at);
  const compliance = prot.compliance || [];
  const failing = compliance.filter((c) => !c.ok);

  const tabs = [
    ['overview', 'Overview'], ['protection', `Protection${failing.length ? ` (${failing.length} issues)` : ''}`],
    ['security', 'Security'], ['events', `Attack events (${a.events.length})`],
    ['software', `Software (${(inv.software || []).length})`],
    ['updates', 'Updates & services'], ['network', 'Network'], ['alerts', `Alerts (${openAlerts.length})`], ['commands', 'Actions'],
  ];

  const def = sec.defender || {};
  const areas = [...new Set(compliance.map((c) => c.area))];
  const panels = {
    protection: `
      <div class="grid two">
        <div class="card"><h2>Protection policy</h2>
          <div style="display:grid;gap:10px">
            <label>Endpoint group<select id="group-select">${groups.map((g) =>
              `<option value="${g.id}" ${g.id === a.groupId ? 'selected' : ''}>${esc(g.name)} (policy: ${esc(g.policyName)})</option>`).join('')}</select></label>
            <label>Policy<select id="policy-select">
              <option value="" ${a.policySource === 'group' ? 'selected' : ''}>Use the group's policy</option>
              ${pol.policies.map((p) => `<option value="${p.id}" ${a.policySource === 'override' && p.id === a.policyOverride ? 'selected' : ''}>Override: ${esc(p.name)}</option>`).join('')}
            </select></label>
            <div><button class="btn primary" id="policy-save">Save</button></div>
          </div>
          <dl class="kv" style="margin-top:14px">
            <dt>Effective policy</dt><dd><b>${esc(a.policyName)}</b> <span class="muted">${a.policySource === 'override'
              ? '(endpoint override)' : `(from group <a href="#/groups/${a.groupId}">${esc(a.groupName)}</a>)`}</span></dd>
            <dt>Status</dt><dd>${!prot.policyVersion ? '<span class="badge warn">Waiting for agent</span>'
              : a.policyApplied ? '<span class="badge good">Applied</span>' : '<span class="badge info">Update pending (next check-in)</span>'}
              ${prot.enforce === false ? ' <span class="badge warn">Report only</span>' : ''}</dd>
            <dt>Compliance</dt><dd>${a.compliance == null ? '—' : `${a.compliance}% (${compliance.length - failing.length}/${compliance.length} settings)`}</dd>
            <dt>Last enforced</dt><dd>${fmtDate(prot.lastEnforced)}</dd>
            <dt>Network</dt><dd>${prot.isolated ? `<span class="badge isolated">ISOLATED</span> only the Shield360 server is reachable
              <div style="margin-top:4px">${prot.isolationReason ? `<b>Automatic:</b> ${esc(prot.isolationReason)}` : 'Isolated manually by an administrator'}</div>
              <button class="btn small" style="margin-top:6px" data-action="release_isolation">Release isolation</button>`
              : '<span class="badge good">Normal</span>'}</dd>
          </dl>
          <div class="section-title">USB storage</div>
          <div>${{ Blocked: '<span class="badge bad">Blocked</span>', 'Read-only': '<span class="badge warn">Read-only</span>', Allowed: '<span class="badge good">Allowed</span>' }[sec.usbStorageState] || '<span class="badge">Unknown</span>'}</div>
          ${(sec.usbDevices || []).length ? `<table style="margin-top:6px"><tbody>${sec.usbDevices.map((u) => `<tr><td>${esc(u.model)}</td>
              <td class="muted nowrap">${esc(u.sizeGB)} GB</td><td class="mono muted" style="font-size:12px">${esc(u.serial)}</td></tr>`).join('')}</tbody></table>`
            : '<div class="muted" style="margin-top:4px">No USB drives connected.</div>'}
          <div class="section-title">Auto-blocked attackers (brute force)</div>
          ${(prot.blockedIps || []).length ? `<table><tbody>${prot.blockedIps.map((b) => `<tr><td class="mono">${esc(b.ip)}</td>
              <td class="muted" style="font-size:12.5px">${esc(b.reason)}<br>until ${fmtDate(b.until)}</td>
              <td><button class="btn small" data-action="unblock_ip" data-param="${esc(b.ip)}">Unblock</button></td></tr>`).join('')}</tbody></table>`
            : '<div class="muted">None right now.</div>'}
          <div class="section-title">Quarantine</div>
          ${(prot.quarantine || []).length ? `<table><tbody>${prot.quarantine.map((q) => `<tr><td><div class="mono" style="font-size:12px;overflow-wrap:anywhere">${esc(q.path)}</div>
              <div class="muted" style="font-size:12px">${esc(q.reason)} · ${fmtDate(q.time)}</div></td></tr>`).join('')}</tbody></table>`
            : '<div class="muted">No files quarantined by Shield360.</div>'}
        </div>
        <div class="card table-wrap"><h2>Policy compliance</h2>
          ${compliance.length ? areas.map((area) => `<div class="section-title">${esc(area)}</div><table><tbody>
            ${compliance.filter((c) => c.area === area).map((c) => `<tr><td>${esc(c.setting)}</td>
              <td class="nowrap">${c.ok ? `<span class="badge good">${esc(c.actual)}</span>`
                : `<span class="badge bad">${esc(c.actual)}</span> <span class="muted" style="font-size:12px">want ${esc(c.expected)}</span>`}</td></tr>`).join('')}
            </tbody></table>`).join('') : '<div class="empty">No compliance data yet. It appears after the agent applies its policy.</div>'}
        </div>
      </div>`,
    events: `<div class="card">${a.events.length ? eventsList(a.events, false) : '<div class="empty">No attack activity recorded on this endpoint.</div>'}</div>`,
    overview: `
      <div class="grid two">
        <div class="card"><h2>System</h2><dl class="kv">
          <dt>Hostname</dt><dd>${esc(a.hostname)}</dd>
          <dt>Type</dt><dd>${esc(a.type)}</dd>
          <dt>Operating system</dt><dd>${esc(a.osName)} <span class="muted">(build ${esc(a.osBuild)})</span></dd>
          <dt>Domain</dt><dd>${esc(a.domain)}</dd>
          <dt>Logged-on users</dt><dd>${esc(a.loggedOnUsers.join(', ') || 'None')}</dd>
          <dt>Last boot</dt><dd>${fmtDate(a.lastBoot)}</dd>
          <dt>Manufacturer</dt><dd>${esc(a.manufacturer)} ${esc(a.model)}</dd>
          <dt>Serial</dt><dd class="mono">${esc(a.serial)}</dd>
          <dt>CPU</dt><dd>${esc(a.cpuModel)} <span class="muted">(${esc(a.cores)} logical)</span></dd>
          <dt>Memory</dt><dd>${a.ramTotalMB ? (a.ramTotalMB / 1024).toFixed(1) + ' GB' : '—'}</dd>
          <dt>Agent</dt><dd>v${esc(a.agentVersion)} · enrolled ${fmtDate(a.firstSeen)}</dd>
        </dl></div>
        <div class="card"><h2>Performance (24h)</h2>
          ${lineChart(metrics, [{ key: 'cpu', label: 'CPU %', color: '--chart-cpu' }, { key: 'mem', label: 'Memory %', color: '--chart-mem' }, { key: 'disk', label: 'Fullest disk %', color: '--chart-disk' }])}
          <h2 style="margin-top:18px">Disks</h2>
          ${(m.disks || []).map((d) => `<div class="row" style="display:flex;gap:10px;align-items:center;margin-bottom:6px">
            <b style="width:28px">${esc(d.drive)}</b><div style="flex:1">${meter(d.usedPct)}</div>
            <span class="muted nowrap">${esc(d.freeGB)} GB free of ${esc(d.sizeGB)} GB</span></div>`).join('') || '<div class="muted">No data</div>'}
        </div>
      </div>`,
    security: `
      <div class="posture">
        <div class="item"><div class="t">Antivirus</div>${protBadge(a.protection)}</div>
        <div class="item"><div class="t">Defender real-time</div>${def.present ? bool(def.realTimeProtection, 'On', 'Off') : '<span class="badge">Not present</span>'}</div>
        <div class="item"><div class="t">Defender mode</div><span class="badge">${esc(def.mode || (def.present ? 'Normal' : '—'))}</span></div>
        <div class="item"><div class="t">Tamper protection</div>${def.present ? bool(def.tamperProtected, 'On', 'Off') : '—'}</div>
        <div class="item"><div class="t">Signatures</div>${def.present ? `<span class="badge ${def.signatureAgeDays > 3 ? 'warn' : 'good'}">${esc(def.signatureAgeDays)} day(s) old</span><div class="muted" style="font-size:12px;margin-top:4px">${esc(def.signatureVersion)}</div>` : '—'}</div>
        <div class="item"><div class="t">Last quick scan</div>${def.present && def.quickScanAgeDays != null ? `${esc(def.quickScanAgeDays)} day(s) ago` : '—'}</div>
        <div class="item"><div class="t">Firewall</div>${(sec.firewall || []).map((p) => `<span class="badge ${p.enabled ? 'good' : 'bad'}">${esc(p.name)}</span>`).join(' ') || '—'}</div>
        <div class="item"><div class="t">BitLocker</div>${(sec.bitlocker || []).map((v) => `<span class="badge ${v.protected ? 'good' : 'warn'}">${esc(v.drive)} ${v.protected ? 'On' : 'Off'}</span>`).join(' ') || '<span class="badge">Not available</span>'}</div>
        <div class="item"><div class="t">Failed logons (1h)</div><span class="badge ${sec.failedLogons1h >= 20 ? 'bad' : sec.failedLogons1h > 0 ? 'warn' : 'good'}">${esc(sec.failedLogons1h ?? '—')}</span></div>
        <div class="item"><div class="t">Pending restart</div>${sec.pendingReboot ? '<span class="badge info">Yes</span>' : '<span class="badge good">No</span>'}</div>
        <div class="item"><div class="t">UAC</div>${bool(sec.uacEnabled, 'Enabled', 'Disabled')}</div>
        <div class="item"><div class="t">RDP</div>${sec.rdpEnabled == null ? '—' : sec.rdpEnabled ? `<span class="badge warn">Enabled${sec.rdpNla === false ? ' (no NLA)' : ''}</span>` : '<span class="badge good">Disabled</span>'}</div>
      </div>
      <div class="grid two" style="margin-top:16px">
        <div class="card"><h2>Threat detections (7 days)</h2>
          ${(sec.threats || []).length ? `<table><thead><tr><th>Time</th><th>Threat</th><th>Result</th></tr></thead><tbody>
            ${sec.threats.map((t) => `<tr><td class="nowrap">${fmtDate(t.time)}</td><td>${esc(t.name)}<div class="muted mono" style="font-size:11.5px">${esc((t.resources || []).join(', '))}</div></td>
              <td>${t.actionSuccess ? '<span class="badge good">Remediated</span>' : '<span class="badge bad">Failed</span>'}</td></tr>`).join('')}</tbody></table>`
          : '<div class="empty">No threats detected.</div>'}
        </div>
        <div class="card"><h2>Local administrators</h2>
          ${(inv.localAdmins || []).length ? `<div class="list">${inv.localAdmins.map((u) => `<div class="row"><div class="grow"><div>${esc(u.name)}</div></div><span class="muted">${esc(u.source || '')}</span></div>`).join('')}</div>` : '<div class="empty">No data (refresh inventory)</div>'}
          ${(sec.antivirus || []).length ? `<h2 style="margin-top:16px">Security Center products</h2><div class="list">${sec.antivirus.map((p) => `<div class="row"><div class="grow"><div>${esc(p.name)}</div></div>${bool(p.enabled, 'Enabled', 'Disabled')} ${bool(p.upToDate, 'Up to date', 'Outdated')}</div>`).join('')}</div>` : ''}
        </div>
      </div>`,
    software: `<div class="card table-wrap">${inventoryNote(a)}
      <input id="sw-search" placeholder="Filter software…" style="max-width:300px;margin-bottom:10px">
      <table><thead><tr><th>Name</th><th>Version</th><th>Publisher</th><th>Installed</th></tr></thead><tbody id="sw-body"></tbody></table></div>`,
    updates: `<div class="grid two">
      <div class="card">${inventoryNote(a)}<h2>Windows Update</h2><dl class="kv">
        <dt>Pending updates</dt><dd>${inv.pendingUpdates ? `${esc(inv.pendingUpdates.count)} (${esc(inv.pendingUpdates.securityCount || 0)} security)` : '—'}</dd>
        <dt>Last patch installed</dt><dd>${fmtDate(inv.lastPatchDate)}</dd></dl>
        ${(inv.pendingUpdates?.titles || []).length ? `<div class="list" style="margin-top:10px">${inv.pendingUpdates.titles.map((t) => `<div class="row"><div class="grow"><div title="${esc(t)}">${esc(t)}</div></div></div>`).join('')}</div>` : ''}
        <h2 style="margin-top:16px">Recent hotfixes</h2>
        ${(inv.hotfixes || []).length ? `<table><tbody>${inv.hotfixes.map((h) => `<tr><td class="mono">${esc(h.id)}</td><td>${esc(h.description)}</td><td class="nowrap muted">${fmtDate(h.installedOn)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">No data</div>'}
      </div>
      <div class="card"><h2>Automatic services not running</h2>
        ${(inv.stoppedServices || []).length ? `<table><thead><tr><th>Service</th><th>Name</th></tr></thead><tbody>${inv.stoppedServices.map((s) => `<tr><td>${esc(s.displayName)}</td><td class="mono muted">${esc(s.name)}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">All automatic services are running.</div>'}
      </div></div>`,
    network: `<div class="grid two">
      <div class="card"><h2>Addresses</h2><dl class="kv">
        <dt>IP addresses</dt><dd class="mono">${esc(a.ipAddresses.join(', '))}</dd>
        <dt>MAC addresses</dt><dd class="mono">${esc(a.macAddresses.join(', '))}</dd>
        <dt>Seen from</dt><dd class="mono">${esc(a.remoteIp)}</dd></dl>
        <h2 style="margin-top:16px">Shared folders</h2>
        ${(inv.shares || []).length ? `<table><tbody>${inv.shares.map((s) => `<tr><td><b>${esc(s.name)}</b></td><td class="mono muted">${esc(s.path)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">None</div>'}
      </div>
      <div class="card table-wrap">${inventoryNote(a)}<h2>Listening ports</h2>
        ${(inv.listeningPorts || []).length ? `<table><thead><tr><th>Port</th><th>Address</th><th>Process</th></tr></thead><tbody>${inv.listeningPorts.map((p) => `<tr><td class="mono">${esc(p.protocol)}/${esc(p.port)}</td><td class="mono muted">${esc(p.address)}</td><td>${esc(p.process)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">No data</div>'}
      </div></div>`,
    alerts: `<div class="card table-wrap">${alertsTable(a.alerts, false)}</div>`,
    commands: `<div class="grid two">
      <div class="card"><h2>Run an action</h2>
        <p class="muted" style="margin-top:-6px">Actions are picked up at the next check-in (about one minute).</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px">${Object.entries(actionNames)
          .filter(([k]) => k !== (a.isolated ? 'isolate' : 'release_isolation'))
          .map(([k, d]) => `<button class="btn ${d.danger ? 'danger' : ''}" data-action="${esc(k)}">${esc(d.label)}${d.param ? '…' : ''}</button>`).join('')}</div>
        <h2 style="margin-top:20px">Endpoint</h2>
        <label>Tags (for grouping and search)<div style="display:flex;gap:8px"><input id="tags" value="${esc(a.tags)}" placeholder="e.g. finance, datacenter-1"><button class="btn" id="save-tags">Save</button></div></label>
        <div style="margin-top:16px"><button class="btn danger" id="remove-agent">Remove endpoint from console</button></div>
      </div>
      <div class="card"><h2>History</h2>
        ${a.commands.length ? a.commands.map((c) => `<div style="border-bottom:1px solid var(--border);padding:8px 0">
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><b>${esc(actionNames[c.action]?.label || c.action)}</b>
            ${c.params && Object.keys(c.params).length ? `<span class="mono muted">${esc(Object.values(c.params).join(' '))}</span>` : ''}
            <span class="badge ${c.status === 'success' ? 'good' : c.status === 'failed' || c.status === 'timeout' ? 'bad' : 'info'}">${esc(c.status)}</span>
            <span class="muted" style="margin-left:auto;font-size:12px">${esc(c.created_by)} · ${ago(c.created_at)}</span></div>
          ${c.output ? `<pre class="output">${esc(c.output)}</pre>` : ''}</div>`).join('') : '<div class="empty">No actions yet.</div>'}
      </div></div>`,
  };

  view().innerHTML = `
    <div class="page-head">
      <div><div class="muted"><a href="#/endpoints">Endpoints</a> /</div>
        <h1 style="display:flex;align-items:center;gap:10px">${statusDot(a.online)} ${esc(a.hostname)} ${a.isolated ? '<span class="badge isolated">ISOLATED</span>' : ''}</h1>
        <div class="muted">${esc(a.type)} · ${esc(a.osName)} · ${a.online ? 'Online' : 'Offline'} · last seen ${ago(a.lastSeen)} · group <a href="#/groups/${a.groupId}">${esc(a.groupName)}</a> · policy ${esc(a.policyName)}</div></div>
      <div class="actions">
        <button class="btn" data-action="refresh_inventory">Refresh inventory</button>
        ${a.isolated ? '<button class="btn" data-action="release_isolation">Release isolation</button>'
          : '<button class="btn danger" data-action="isolate">Isolate</button>'}
        <button class="btn primary" data-action="defender_quick_scan">Quick scan</button>
      </div>
    </div>
    <div class="tiles">
      <div class="tile"><div class="label">CPU</div><div class="value">${a.online ? pct(m.cpu) : '—'}</div></div>
      <div class="tile"><div class="label">Memory</div><div class="value">${a.online ? pct(m.memPct) : '—'}</div><div class="sub">${m.memUsedMB ? (m.memUsedMB / 1024).toFixed(1) + ' GB used' : ''}</div></div>
      <div class="tile"><div class="label">Fullest disk</div><div class="value">${pct(a.disk)}</div></div>
      <div class="tile"><div class="label">Protection</div><div class="value" style="font-size:18px;margin-top:8px">${protBadge(a.protection)}</div></div>
      <div class="tile ${openAlerts.some((x) => x.severity === 'critical') ? 'bad' : ''}"><div class="label">Open alerts</div><div class="value">${openAlerts.length}</div></div>
    </div>
    <div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${k === detailTab ? 'active' : ''}">${l}</button>`).join('')}</div>
    <div id="tab-panel">${panels[detailTab]}</div>`;

  view().querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => { detailTab = b.dataset.tab; renderEndpoint(id); }));
  view().querySelectorAll('[data-action]').forEach((b) => b.addEventListener('click', async () => {
    const action = b.dataset.action;
    const def = actionNames[action];
    const params = {};
    if (def.param) {
      const hint = { pid: 'Process ID (from "List top processes")', path: 'Full path, e.g. C:\\Users\\Public\\evil.exe', ip: 'IP address' }[def.param];
      const v = b.dataset.param || prompt(`${def.label}\n${hint}:`);
      if (!v) return;
      params[def.param] = v.trim();
    }
    const warnings = {
      release_isolation: `Reconnect ${a.hostname} to the network? Only do this after the threat is cleaned up.`,
      restart: `Restart ${a.hostname}? Users get a 2-minute warning.`,
      isolate: `Isolate ${a.hostname}? All network traffic except to this console will be blocked until you release it.`,
      kill_process: `Kill process ${params.pid} on ${a.hostname}?`,
      quarantine_file: `Quarantine ${params.path} on ${a.hostname}?`,
    };
    if (warnings[action] && !confirm(warnings[action])) return;
    try {
      await api('POST', `/api/agents/${id}/commands`, { action, params });
      toast(`Queued: ${def.label}`);
      if (detailTab === 'commands') renderEndpoint(id);
    } catch (err) { toast(err.message); }
  }));
  bindAlertAcks(() => renderEndpoint(id));

  if (detailTab === 'software') {
    const sw = (inv.software || []).slice().sort((x, y) => (x.name || '').localeCompare(y.name || ''));
    const draw = (q = '') => {
      $('#sw-body').innerHTML = sw.filter((s) => !q || `${s.name} ${s.publisher}`.toLowerCase().includes(q.toLowerCase()))
        .map((s) => `<tr><td>${esc(s.name)}</td><td class="mono">${esc(s.version)}</td><td class="muted">${esc(s.publisher)}</td><td class="muted nowrap">${esc(s.installDate || '')}</td></tr>`).join('')
        || '<tr><td colspan="4" class="empty">No software data</td></tr>';
    };
    $('#sw-search').addEventListener('input', (e) => draw(e.target.value));
    draw();
  }
  if (detailTab === 'protection') {
    $('#policy-save').addEventListener('click', async () => {
      const ov = $('#policy-select').value;
      await api('PATCH', `/api/agents/${id}`, { groupId: Number($('#group-select').value), policyOverride: ov ? Number(ov) : null });
      toast('Saved. The endpoint applies its policy at the next check-in.');
      renderEndpoint(id);
    });
  }
  if (detailTab === 'commands') {
    $('#save-tags').addEventListener('click', async () => {
      await api('PATCH', `/api/agents/${id}`, { tags: $('#tags').value });
      toast('Tags saved');
    });
    $('#remove-agent').addEventListener('click', async () => {
      if (!confirm(`Remove ${a.hostname} and all of its history? Uninstall the agent on the machine too, or it will stop authenticating.`)) return;
      await api('DELETE', `/api/agents/${id}`);
      toast('Endpoint removed');
      location.hash = '#/endpoints';
    });
  }
  // Auto-refresh only on read-only tabs so typing isn't interrupted.
  if (['overview', 'security', 'events', 'alerts', 'commands'].includes(detailTab)) {
    refreshTimer = setTimeout(() => { if (route().id === id && !document.activeElement?.matches('input')) renderEndpoint(id); }, 15000);
  }
}

function inventoryNote(a) {
  return `<div class="muted" style="font-size:12px;margin-bottom:8px">Inventory collected ${a.inventoryAt ? ago(a.inventoryAt) : 'not yet'} (refreshes every 6 hours)</div>`;
}

// ---------------------------------------------------------------- alerts

function alertsTable(alerts, withHost) {
  if (!alerts.length) return '<div class="empty">No alerts.</div>';
  return `<table><thead><tr><th>Severity</th>${withHost ? '<th>Endpoint</th>' : ''}<th>Alert</th><th>Raised</th><th>Status</th><th></th></tr></thead><tbody>
    ${alerts.map((a) => `<tr>
      <td>${sevBadge(a.severity)}</td>
      ${withHost ? `<td><a href="#/endpoints/${esc(a.agent_id)}">${esc(a.hostname)}</a></td>` : ''}
      <td>${esc(a.message)}</td>
      <td class="nowrap muted" title="${fmtDate(a.created_at)}">${ago(a.created_at)}</td>
      <td class="nowrap">${a.resolved_at ? `<span class="badge good">Resolved ${ago(a.resolved_at)}</span>`
        : a.acknowledged_by ? `<span class="badge info">Ack'd by ${esc(a.acknowledged_by)}</span>` : '<span class="badge warn">Open</span>'}</td>
      <td>${!a.resolved_at && !a.acknowledged_by ? `<button class="btn small" data-ack="${a.id}">Acknowledge</button>` : ''}</td>
    </tr>`).join('')}</tbody></table>`;
}

function bindAlertAcks(after) {
  view().querySelectorAll('[data-ack]').forEach((b) => b.addEventListener('click', async () => {
    await api('POST', `/api/alerts/${b.dataset.ack}/ack`);
    after();
  }));
}

let alertFilter = 'open';
async function renderAlerts() {
  const alerts = await api('GET', `/api/alerts?status=${alertFilter}`);
  view().innerHTML = `
    <div class="page-head"><div><h1>Alerts</h1><div class="muted">Alerts resolve automatically when the endpoint reports the issue is fixed</div></div></div>
    <div class="toolbar"><select id="alert-filter">
      ${[['open', 'Open'], ['resolved', 'Resolved'], ['all', 'All']].map(([v, l]) => `<option value="${v}" ${alertFilter === v ? 'selected' : ''}>${l}</option>`).join('')}
    </select></div>
    <div class="card table-wrap">${alertsTable(alerts, true)}</div>`;
  $('#alert-filter').addEventListener('change', (e) => { alertFilter = e.target.value; renderAlerts(); });
  bindAlertAcks(renderAlerts);
}

// ---------------------------------------------------------------- attack events

const EVENT_LABELS = {
  malware: 'Malware', blocklisted_file: 'Blocklisted file', bruteforce_blocked: 'Brute force blocked',
  asr_blocked: 'Exploit / ASR block', ransomware_blocked: 'Ransomware blocked', network_blocked: 'Malicious site blocked',
  suspicious_behavior: 'Suspicious behavior', av_disabled: 'Antivirus disabled', log_cleared: 'Log cleared',
  account_created: 'Account created', privileged_group_change: 'Admin group change', suspicious_service: 'Suspicious service',
  service_installed: 'Service installed', suspicious_powershell: 'Suspicious PowerShell',
  auto_isolated: 'AUTO-ISOLATED', compromise_detected: 'Compromise detected',
};

function eventsList(events, withHost) {
  return `<div class="list">${events.map((e) => `
    <div class="row">${sevBadge(e.severity)}
      <div class="grow"><div title="${esc(e.message)}">
        ${e.blocked ? '<span class="badge good">Blocked</span> ' : ''}<b>${esc(EVENT_LABELS[e.type] || e.type)}</b>
        ${withHost ? ` · <a href="#/endpoints/${esc(e.agent_id)}">${esc(e.hostname)}</a>` : ''} — ${esc(e.message)}</div></div>
      <span class="muted nowrap" title="${fmtDate(e.ts)}">${ago(e.ts)}</span></div>`).join('')}</div>`;
}

let eventFilter = '';
async function renderEvents() {
  const q = eventFilter === 'blocked' ? '?blocked=1' : eventFilter ? `?severity=${eventFilter}` : '';
  const events = await api('GET', `/api/events${q}`);
  view().innerHTML = `
    <div class="page-head"><div><h1>Attack events</h1>
      <div class="muted">Malware, blocked exploits and ransomware, brute-force attacks, and suspicious activity from all endpoints</div></div></div>
    <div class="toolbar"><select id="event-filter">
      ${[['', 'All events'], ['blocked', 'Blocked attacks'], ['critical', 'Critical'], ['high', 'High'], ['warning', 'Warning'], ['info', 'Info']]
        .map(([v, l]) => `<option value="${v}" ${eventFilter === v ? 'selected' : ''}>${l}</option>`).join('')}
    </select></div>
    <div class="card">${events.length ? eventsList(events, true) : '<div class="empty">No events.</div>'}</div>`;
  $('#event-filter').addEventListener('change', (e) => { eventFilter = e.target.value; renderEvents(); });
}

// ---------------------------------------------------------------- endpoint groups

async function renderGroups(selectedId) {
  const [data, pol, agents] = await Promise.all([api('GET', '/api/groups'), api('GET', '/api/policies'), api('GET', '/api/agents')]);
  const isNew = selectedId === 'new';
  const current = isNew
    ? { id: null, name: '', description: '', policyId: 1, priority: 100, rules: { types: [], hostnames: [] }, endpoints: 0 }
    : data.groups.find((g) => String(g.id) === String(selectedId)) || data.groups[0];
  const members = isNew ? [] : agents.filter((a) => a.groupId === current.id);

  view().innerHTML = `
    <div class="page-head"><div><h1>Endpoint groups</h1>
      <div class="muted">Organise endpoints into groups. Each group gets a protection policy, so different departments or server roles get different protection.</div></div>
      <div class="actions"><a class="btn" href="#/endpoints">Move endpoints…</a><a class="btn primary" href="#/groups/new">New group</a></div></div>
    <div class="grid policy-layout">
      <div class="card policy-list" style="align-self:start">
        ${data.groups.map((g) => `<div class="row ${!isNew && g.id === current.id ? 'active' : ''}" data-group="${g.id}">
          <div class="grow"><div><b>${esc(g.name)}</b></div>
            <div class="muted" style="font-size:12px">${g.endpoints} endpoint(s) · ${g.online} online</div>
            <div class="muted" style="font-size:12px">Policy: ${esc(g.policyName)}</div></div></div>`).join('')}
        ${isNew ? '<div class="row active"><div class="grow"><b>New group</b></div></div>' : ''}
      </div>
      <div style="display:grid;gap:16px;align-content:start">
        <form id="group-form" class="card">
          <div class="form-grid">
            <label>Group name<input name="name" required maxlength="60" value="${esc(current.name)}" ${current.isDefault ? 'readonly' : ''}
              placeholder="e.g. Finance Workstations, Production Servers"></label>
            <label>Description<input name="description" maxlength="200" value="${esc(current.description)}"></label>
            <label>Protection policy<select name="policyId">${pol.policies.map((p) =>
              `<option value="${p.id}" ${p.id === current.policyId ? 'selected' : ''}>${esc(p.name)}${p.settings.enforce ? '' : ' (report only)'}</option>`).join('')}</select></label>
          </div>
          ${current.isDefault ? `<p class="muted">New endpoints join the <b>Default</b> group unless an auto-assignment rule of another group matches.
              The Default group cannot be renamed or deleted.</p>` : `
          <div class="section-title">Auto-assignment for newly enrolled endpoints</div>
          <p class="muted" style="margin-top:0">A new endpoint joins this group when it matches. If both are set, both must match.
            Groups are checked in priority order (lowest number first). Leave empty to assign endpoints manually only.</p>
          <div class="form-grid">
            <div style="display:grid;gap:8px;align-content:start"><span class="muted" style="font-size:13px">Endpoint type</span>
              ${data.types.map((t) => `<label class="check"><input type="checkbox" name="type" value="${esc(t)}" ${current.rules.types.includes(t) ? 'checked' : ''}> ${esc(t)}</label>`).join('')}</div>
            <label><span>Hostname patterns (one per line, <code>*</code> and <code>?</code> wildcards)</span>
              <textarea name="hostnames" rows="4" placeholder="FIN-*&#10;ACC-PC??">${esc(current.rules.hostnames.join('\n'))}</textarea></label>
            <label>Priority<input type="number" name="priority" min="1" max="999" value="${current.priority}"></label>
          </div>`}
          <div id="group-error" class="error" style="margin-top:12px"></div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
            <button class="btn primary" type="submit">${isNew ? 'Create group' : 'Save group'}</button>
            ${!isNew && !current.isDefault ? '<button class="btn danger" type="button" id="group-delete">Delete group</button>' : ''}
            ${!isNew && !current.isDefault ? '<button class="btn" type="button" id="apply-rules">Apply rules to endpoints in Default</button>' : ''}
          </div>
        </form>
        ${isNew ? '' : `<div class="card table-wrap"><h2>Members (${members.length})</h2>
          ${members.length ? `<table><thead><tr><th></th><th>Hostname</th><th>Type</th><th>Policy</th><th>Compliance</th><th>Last seen</th></tr></thead><tbody>
            ${members.map((a) => `<tr class="clickable" data-id="${esc(a.id)}"><td>${statusDot(a.online)}</td><td><b>${esc(a.hostname)}</b></td>
              <td>${esc(a.type)}</td><td>${esc(a.policyName)}${a.policySource === 'override' ? ' <span class="badge info">override</span>' : ''}</td>
              <td>${a.compliance == null ? '—' : a.compliance + '%'}</td><td class="muted nowrap">${ago(a.lastSeen)}</td></tr>`).join('')}</tbody></table>`
            : '<div class="empty">No endpoints in this group. Use <a href="#/endpoints">Endpoints</a> to select and move endpoints here.</div>'}
        </div>`}
      </div>
    </div>`;

  view().querySelectorAll('[data-group]').forEach((r) => r.addEventListener('click', () => { location.hash = `#/groups/${r.dataset.group}`; }));
  view().querySelectorAll('tr[data-id]').forEach((tr) => tr.addEventListener('click', () => { location.hash = `#/endpoints/${tr.dataset.id}`; }));
  $('#group-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const body = {
      name: f.elements.name.value, description: f.elements.description.value, policyId: Number(f.elements.policyId.value),
      priority: Number(f.elements.priority?.value || 100),
      rules: {
        types: [...f.querySelectorAll('input[name=type]:checked')].map((x) => x.value),
        hostnames: (f.elements.hostnames?.value || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean),
      },
    };
    try {
      if (isNew) {
        const r = await api('POST', '/api/groups', body);
        toast('Group created');
        location.hash = `#/groups/${r.id}`;
      } else {
        await api('PUT', `/api/groups/${current.id}`, body);
        toast(`Group saved. Its ${current.endpoints} endpoint(s) apply the policy at their next check-in.`);
        renderGroups(current.id);
      }
    } catch (err) { $('#group-error').textContent = err.message; }
  });
  $('#group-delete')?.addEventListener('click', async () => {
    if (!confirm(`Delete group "${current.name}"? Its ${current.endpoints} endpoint(s) move to the Default group.`)) return;
    await api('DELETE', `/api/groups/${current.id}`);
    toast('Group deleted');
    location.hash = '#/groups';
  });
  $('#apply-rules')?.addEventListener('click', async () => {
    const r = await api('POST', '/api/groups/apply-rules');
    toast(`${r.moved} endpoint(s) moved out of Default by auto-assignment rules`);
    renderGroups(current.id);
  });
}

// ---------------------------------------------------------------- protection policies

async function renderPolicies(selectedId) {
  const data = await api('GET', '/api/policies');
  const isNew = selectedId === 'new';
  const current = isNew
    ? { id: null, name: '', description: '', settings: data.defaults, endpoints: 0 }
    : data.policies.find((p) => String(p.id) === String(selectedId)) || data.policies[0];
  const s = current.settings;
  const av = s.antivirus;
  const modeSelect = (name, value, opts = [['off', 'Off'], ['audit', 'Audit (log only)'], ['block', 'Block']]) =>
    `<select name="${name}">${opts.map(([v, l]) => `<option value="${v}" ${value === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
  const check = (name, value, label) => `<label class="check"><input type="checkbox" name="${name}" ${value ? 'checked' : ''}> ${label}</label>`;

  view().innerHTML = `
    <div class="page-head"><div><h1>Protection policies</h1>
      <div class="muted">Antivirus, exploit and ransomware protection, firewall, hardening and attack blocking, enforced on every endpoint</div></div>
      <div class="actions"><a class="btn" href="#/policies/new">New policy</a></div></div>
    <div class="grid policy-layout">
      <div class="card policy-list" style="align-self:start">
        ${data.policies.map((p) => `<div class="row ${!isNew && p.id === current.id ? 'active' : ''}" data-policy="${p.id}">
          <div class="grow"><div><b>${esc(p.name)}</b></div><div class="muted" style="font-size:12px">${p.endpoints} endpoint(s)${p.settings.enforce ? '' : ' · report only'}</div>
          ${p.groups.length ? `<div class="muted" style="font-size:12px">Groups: ${esc(p.groups.join(', '))}</div>` : ''}</div></div>`).join('')}
        ${isNew ? '<div class="row active"><div class="grow"><b>New policy</b></div></div>' : ''}
      </div>
      <form id="policy-form" class="card">
        <div class="form-grid">
          <label>Name<input name="name" required value="${esc(current.name)}" ${current.id === 1 ? 'readonly' : ''}></label>
          <label>Description<input name="description" value="${esc(current.description)}"></label>
          <label>Mode<select name="enforce">
            <option value="1" ${s.enforce ? 'selected' : ''}>Enforce (apply and self-heal settings)</option>
            <option value="0" ${!s.enforce ? 'selected' : ''}>Report only (check compliance, change nothing)</option></select></label>
        </div>

        <div class="section-title">Antivirus (Microsoft Defender engine)</div>
        <div class="form-grid">
          ${check('av.realTimeProtection', av.realTimeProtection, 'Real-time protection')}
          ${check('av.behaviorMonitoring', av.behaviorMonitoring, 'Behavior monitoring')}
          ${check('av.scriptScanning', av.scriptScanning, 'Script scanning (AMSI)')}
          ${check('av.downloadScanning', av.downloadScanning, 'Scan downloads & attachments')}
          ${check('av.cloudProtection', av.cloudProtection, 'Cloud-delivered protection')}
          ${check('av.dailyQuickScan', av.dailyQuickScan, 'Daily quick scan')}
          ${check('av.autoUpdateSignatures', av.autoUpdateSignatures, 'Auto-update virus definitions (server mirror fallback)')}
          <label>Cloud block level<select name="av.cloudBlockLevel">${[['default', 'Default'], ['high', 'High'], ['highplus', 'High+'], ['zerotolerance', 'Zero tolerance']]
            .map(([v, l]) => `<option value="${v}" ${av.cloudBlockLevel === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
          <label>Signature update interval (hours)<input type="number" min="1" max="24" name="av.signatureUpdateIntervalHours" value="${av.signatureUpdateIntervalHours}"></label>
          <label>Potentially unwanted apps${modeSelect('av.puaProtection', av.puaProtection)}</label>
          <label>Network protection (malicious sites/C2)${modeSelect('av.networkProtection', av.networkProtection)}</label>
          <label>Ransomware protection (controlled folders)${modeSelect('av.controlledFolderAccess', av.controlledFolderAccess)}</label>
        </div>
        <label style="margin-top:12px">Scan exclusions (one path per line)<textarea name="av.exclusions" rows="2">${esc(av.exclusions.join('\n'))}</textarea></label>

        <div class="section-title">Exploit protection: attack surface reduction rules</div>
        ${data.asrRules.map((r) => `<div class="asr-row"><span>${esc(r.name)}</span>${modeSelect('asr.' + r.id, s.asr[r.id])}</div>`).join('')}

        <div class="section-title">Brute-force attack blocking</div>
        <div class="form-grid">
          ${check('bf.enabled', s.bruteForce.enabled, 'Automatically block attacking IPs in the firewall')}
          <label>Failed logons before blocking<input type="number" min="3" name="bf.threshold" value="${s.bruteForce.threshold}"></label>
          <label>Within (minutes)<input type="number" min="1" name="bf.windowMinutes" value="${s.bruteForce.windowMinutes}"></label>
          <label>Block for (minutes)<input type="number" min="1" name="bf.blockMinutes" value="${s.bruteForce.blockMinutes}"></label>
        </div>
        <label style="margin-top:12px">Never block these IPs/CIDRs (one per line, e.g. your jump host or VPN range)<textarea name="bf.allowlist" rows="2">${esc(s.bruteForce.allowlist.join('\n'))}</textarea></label>

        <div class="section-title">Automatic isolation of compromised endpoints</div>
        <p class="muted" style="margin-top:0">When a trigger fires, the endpoint immediately blocks all internet and network traffic except to this console.
          It stays isolated, including across restarts, until you release it from the endpoint page.</p>
        <div class="form-grid">
          ${check('ai.enabled', s.autoIsolate.enabled, '<b>Isolate automatically when compromised</b>')}
          ${check('ai.excludeServers', s.autoIsolate.excludeServers, 'Servers: alert only, do not auto-isolate')}
        </div>
        <div class="form-grid" style="margin-top:10px">
          ${data.isolateTriggers.map(([k, label]) => check('ai.' + k, s.autoIsolate[k], label)).join('')}
        </div>

        <div class="section-title">USB device control</div>
        <div class="form-grid">
          <label>USB storage (flash drives, external disks, phones)<select name="usbStorage">
            ${[['allow', 'Allow'], ['readonly', 'Read-only (no copying files to USB)'], ['block', 'Block completely']]
              .map(([v, l]) => `<option value="${v}" ${s.deviceControl.usbStorage === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
          <p class="muted" style="margin:0;align-self:end;font-size:12.5px">Keyboards, mice, printers and other USB devices keep working.
            Drives already plugged in are affected when reconnected (or after a restart).</p>
        </div>

        <div class="section-title">Website blocking</div>
        <label><span>Blocked websites (one per line, subdomains included, e.g. <code>facebook.com</code> also blocks <code>www.</code> and <code>m.facebook.com</code>)</span>
          <textarea name="blockedSites" rows="5">${esc(s.webFilter.blockedSites.join('\n'))}</textarea></label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;align-items:center">
          <span class="muted" style="font-size:12.5px">Add category:</span>
          ${Object.keys(data.websitePresets).map((k) => `<button type="button" class="btn small" data-preset="${esc(k)}">+ ${esc(k)}</button>`).join('')}
        </div>
        <p class="muted" style="font-size:12.5px">Blocked in Edge, Chrome and Firefox (users see "blocked by your organization") and system-wide through the hosts file.</p>

        <div class="section-title">Firewall & system hardening</div>
        <div class="form-grid">
          ${check('fw.enforceOn', s.firewall.enforceOn, 'Keep Windows Firewall on (all profiles)')}
          ${check('fw.blockInboundByDefault', s.firewall.blockInboundByDefault, 'Block inbound by default')}
          ${check('h.disableSmb1', s.hardening.disableSmb1, 'Disable SMBv1 (WannaCry / EternalBlue)')}
          ${check('h.disableLlmnr', s.hardening.disableLlmnr, 'Disable LLMNR (name poisoning)')}
          ${check('h.disableWdigest', s.hardening.disableWdigest, 'Disable WDigest plain-text passwords')}
          ${check('h.requireRdpNla', s.hardening.requireRdpNla, 'Require NLA for Remote Desktop')}
          ${check('h.powershellLogging', s.hardening.powershellLogging, 'PowerShell script block logging')}
          ${check('h.lsaProtection', s.hardening.lsaProtection, 'LSA protection (credential theft; needs restart)')}
          ${check('iocEnforcement', s.iocEnforcement, 'Enforce the global blocklist (hashes, IPs, domains)')}
        </div>

        <div id="policy-error" class="error" style="margin-top:12px"></div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn primary" type="submit">${isNew ? 'Create policy' : 'Save policy'}</button>
          ${!isNew && current.id !== 1 ? '<button class="btn danger" type="button" id="policy-delete">Delete</button>' : ''}
        </div>
        <p class="muted" style="margin-bottom:0">Endpoints pick up changes at their next check-in and re-apply the policy every 15 minutes,
          undoing any local tampering. Settings managed by Group Policy or Intune take precedence and show as non-compliant.</p>
      </form>
    </div>`;

  view().querySelectorAll('[data-policy]').forEach((r) => r.addEventListener('click', () => { location.hash = `#/policies/${r.dataset.policy}`; }));
  view().querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', () => {
    const ta = $('#policy-form').elements.blockedSites;
    const have = new Set(ta.value.split(/\r?\n/).map((x) => x.trim()).filter(Boolean));
    const added = data.websitePresets[b.dataset.preset].filter((d) => !have.has(d));
    ta.value = [...have, ...added].join('\n');
    toast(`Added ${added.length} site(s) from ${b.dataset.preset}. Save the policy to apply.`);
  }));
  $('#policy-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const val = (n) => f.elements[n].value;
    const on = (n) => f.elements[n].checked;
    const lines = (n) => val(n).split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
    const settings = {
      enforce: val('enforce') === '1',
      antivirus: {
        realTimeProtection: on('av.realTimeProtection'), behaviorMonitoring: on('av.behaviorMonitoring'),
        scriptScanning: on('av.scriptScanning'), downloadScanning: on('av.downloadScanning'),
        cloudProtection: on('av.cloudProtection'), dailyQuickScan: on('av.dailyQuickScan'),
        autoUpdateSignatures: on('av.autoUpdateSignatures'),
        cloudBlockLevel: val('av.cloudBlockLevel'), signatureUpdateIntervalHours: Number(val('av.signatureUpdateIntervalHours')),
        puaProtection: val('av.puaProtection'), networkProtection: val('av.networkProtection'),
        controlledFolderAccess: val('av.controlledFolderAccess'), exclusions: lines('av.exclusions'),
      },
      asr: Object.fromEntries(data.asrRules.map((r) => [r.id, val('asr.' + r.id)])),
      bruteForce: {
        enabled: on('bf.enabled'), threshold: Number(val('bf.threshold')), windowMinutes: Number(val('bf.windowMinutes')),
        blockMinutes: Number(val('bf.blockMinutes')), allowlist: lines('bf.allowlist'),
      },
      firewall: { enforceOn: on('fw.enforceOn'), blockInboundByDefault: on('fw.blockInboundByDefault') },
      hardening: Object.fromEntries(['disableSmb1', 'disableLlmnr', 'disableWdigest', 'requireRdpNla', 'powershellLogging', 'lsaProtection'].map((k) => [k, on('h.' + k)])),
      iocEnforcement: on('iocEnforcement'),
      autoIsolate: Object.fromEntries(['enabled', 'excludeServers', ...data.isolateTriggers.map(([k]) => k)].map((k) => [k, on('ai.' + k)])),
      deviceControl: { usbStorage: val('usbStorage') },
      webFilter: { blockedSites: lines('blockedSites') },
    };
    const body = { name: val('name'), description: val('description'), settings };
    try {
      if (isNew) {
        const r = await api('POST', '/api/policies', body);
        toast('Policy created');
        location.hash = `#/policies/${r.id}`;
      } else {
        await api('PUT', `/api/policies/${current.id}`, body);
        toast(`Policy saved. ${current.endpoints} endpoint(s) will apply it at their next check-in.`);
        renderPolicies(current.id);
      }
    } catch (err) { $('#policy-error').textContent = err.message; }
  });
  $('#policy-delete')?.addEventListener('click', async () => {
    if (!confirm(`Delete policy "${current.name}"? Its endpoints move to the Default policy.`)) return;
    await api('DELETE', `/api/policies/${current.id}`);
    toast('Policy deleted');
    location.hash = '#/policies';
  });
}

// ---------------------------------------------------------------- virus definitions

async function renderDefinitions() {
  const d = await api('GET', '/api/definitions');
  const m = d.mirror;
  const counts = { latest: 0, behind: 0, outdated: 0 };
  for (const r of d.rows) if (counts[r.status] != null) counts[r.status]++;
  const statusBadge = (s) => ({
    latest: '<span class="badge good">Latest</span>', behind: '<span class="badge info">Update available</span>',
    outdated: '<span class="badge bad">Outdated</span>', unknown: '<span class="badge">Unknown</span>', 'n/a': '<span class="badge">Other AV</span>',
  }[s]);
  const pkgs = Object.entries(m.packages);
  view().innerHTML = `
    <div class="page-head"><div><h1>Virus definitions</h1>
      <div class="muted">Microsoft Defender security intelligence across all endpoints. Microsoft publishes new definitions several times a day.</div></div>
      <div class="actions">
        <button class="btn" id="upd-outdated" ${counts.behind + counts.outdated ? '' : 'disabled'}>Update out-of-date endpoints</button>
        <button class="btn primary" id="upd-all">Update all endpoints now</button>
      </div></div>
    <div class="tiles">
      <div class="tile"><div class="label">Latest known version</div><div class="value" style="font-size:20px;margin-top:6px">${esc(d.latest || '—')}</div></div>
      <div class="tile good"><div class="label">Up to date</div><div class="value">${counts.latest}</div></div>
      <div class="tile"><div class="label">Update available</div><div class="value">${counts.behind}</div></div>
      <div class="tile ${counts.outdated ? 'bad' : ''}"><div class="label">Outdated (&gt; 3 days)</div><div class="value">${counts.outdated}</div></div>
    </div>
    <div class="grid two" style="margin-bottom:16px">
      <div class="card"><h2>Server definition mirror</h2>
        <p class="muted" style="margin-top:-6px">This server downloads Microsoft's official full definition package every ${esc(m.refreshHours)} hours.
          Endpoints that cannot reach Microsoft (isolated, offline networks, restricted proxies) install it from here.
          Agents only run it after verifying Microsoft's digital signature.</p>
        ${!m.enabled ? '<div class="badge warn">Disabled in config.json (definitionMirror.enabled)</div>' : `
        <table><tbody>${pkgs.length ? pkgs.map(([arch, p]) => `<tr><td><b>${esc(arch)}</b></td>
            <td class="mono">${esc(p.version || 'version unknown')}</td>
            <td class="muted">${p.size ? (p.size / 1048576).toFixed(0) + ' MB' : ''} · ${ago(p.downloadedAt)}</td>
            <td>${p.available ? '<span class="badge good">Ready</span>' : '<span class="badge warn">Missing</span>'}</td></tr>`).join('')
          : '<tr><td class="muted">Nothing mirrored yet.</td></tr>'}</tbody></table>
        <div class="muted" style="font-size:12.5px;margin-top:8px">${m.running ? '<span class="badge info">Downloading from Microsoft…</span>'
          : `Last checked ${m.lastCheck ? ago(m.lastCheck) : 'never'}`}
          ${m.lastError ? `<div class="error">${esc(m.lastError)}</div>` : ''}</div>
        <div style="margin-top:10px"><button class="btn" id="mirror-refresh" ${m.running ? 'disabled' : ''}>Check Microsoft for new definitions now</button></div>`}
      </div>
      <div class="card"><h2>How endpoints stay current</h2>
        <ol style="margin:0;padding-left:18px;line-height:1.7">
          <li>Defender's own updater runs at the interval set in the protection policy.</li>
          <li>If definitions get older than that, the Shield360 agent updates them itself (every 15 min check).</li>
          <li>If Microsoft can't be reached, or the endpoint is isolated, it installs the package from this server.</li>
          <li>Endpoints with definitions older than 3 days raise an alert.</li>
        </ol>
      </div>
    </div>
    <div class="card table-wrap"><table>
      <thead><tr><th></th><th>Endpoint</th><th>Definitions</th><th>Updated</th><th>Engine</th><th>Status</th></tr></thead>
      <tbody>${d.rows.map((r) => `<tr class="clickable" data-id="${esc(r.id)}">
        <td>${statusDot(r.online)}</td><td><b>${esc(r.hostname)}</b></td>
        <td class="mono">${esc(r.signatureVersion || '—')}</td>
        <td class="nowrap muted">${r.signatureUpdated ? ago(Date.parse(r.signatureUpdated)) : '—'}</td>
        <td class="mono muted">${esc(r.engineVersion || '—')}</td><td>${statusBadge(r.status)}</td></tr>`).join('')
        || '<tr><td colspan="6" class="empty">No endpoints.</td></tr>'}</tbody></table></div>`;

  view().querySelectorAll('tr[data-id]').forEach((tr) => tr.addEventListener('click', () => { location.hash = `#/endpoints/${tr.dataset.id}`; }));
  const queue = async (onlyOutdated) => {
    const r = await api('POST', '/api/definitions/update-all', { onlyOutdated });
    toast(`Definition update queued on ${r.queued} endpoint(s). Results appear under each endpoint's Actions tab.`);
  };
  $('#upd-all').addEventListener('click', () => queue(false));
  $('#upd-outdated').addEventListener('click', () => queue(true));
  $('#mirror-refresh')?.addEventListener('click', async () => {
    await api('POST', '/api/definitions/refresh');
    toast('Checking Microsoft for new definitions…');
    setTimeout(renderDefinitions, 1500);
  });
}

// ---------------------------------------------------------------- blocklist (IOCs)

async function renderBlocklist() {
  const iocs = await api('GET', '/api/iocs');
  const typeLabel = { hash: 'File (SHA-256)', ip: 'IP / range', domain: 'Domain' };
  view().innerHTML = `
    <div class="page-head"><div><h1>Blocklist</h1>
      <div class="muted">Known-bad indicators blocked on every endpoint whose policy enforces the blocklist</div></div></div>
    <div class="grid two">
      <form id="ioc-form" class="card" style="align-self:start">
        <h2>Add indicators</h2>
        <div style="display:grid;gap:12px">
          <label>Type<select name="type">
            <option value="hash">File hash (SHA-256): matching programs are killed and quarantined</option>
            <option value="ip">IP address / CIDR: all traffic blocked in the firewall</option>
            <option value="domain">Domain: blocked through the hosts file</option></select></label>
          <label>Values (one per line, paste a whole threat feed)<textarea name="value" rows="5" required></textarea></label>
          <label>Description<input name="description" placeholder="e.g. Ransomware campaign IOC from CERT advisory"></label>
          <div id="ioc-error" class="error"></div>
          <div><button class="btn primary">Add to blocklist</button></div>
        </div>
      </form>
      <div class="card table-wrap"><h2>${iocs.length} indicator(s)</h2>
        ${iocs.length ? `<table><thead><tr><th>Type</th><th>Value</th><th>Description</th><th></th></tr></thead><tbody>
          ${iocs.map((i) => `<tr><td class="nowrap">${typeLabel[i.type]}</td><td class="mono" style="overflow-wrap:anywhere">${esc(i.value)}</td>
            <td class="muted">${esc(i.description)}<div style="font-size:12px">${esc(i.created_by)} · ${ago(i.created_at)}</div></td>
            <td><button class="btn small danger" data-del="${i.id}">Remove</button></td></tr>`).join('')}</tbody></table>`
          : '<div class="empty">The blocklist is empty.</div>'}
      </div>
    </div>`;
  $('#ioc-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('POST', '/api/iocs', Object.fromEntries(new FormData(e.target)));
      toast(`${r.added} indicator(s) added. Endpoints apply them within a minute.`);
      renderBlocklist();
    } catch (err) { $('#ioc-error').textContent = err.message; }
  });
  view().querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    await api('DELETE', `/api/iocs/${b.dataset.del}`);
    renderBlocklist();
  }));
}

// ---------------------------------------------------------------- deploy

async function renderDeploy() {
  const d = await api('GET', '/api/deploy');
  const oneLiner =
    `powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; ` +
    `iwr '${d.serverUrl}/download/Install-Shield360Agent.ps1' -UseBasicParsing -OutFile $env:TEMP\\s360-install.ps1; ` +
    `& $env:TEMP\\s360-install.ps1 -ServerUrl '${d.serverUrl}' -EnrollToken '${d.enrollToken}'"`;
  const offline = `.\\Install-Shield360Agent.ps1 -ServerUrl '${d.serverUrl}' -EnrollToken '${d.enrollToken}'`;
  const gpo = `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "\\\\<fileserver>\\share\\Shield360\\Install-Shield360Agent.ps1" -ServerUrl "${d.serverUrl}" -EnrollToken "${d.enrollToken}"`;
  view().innerHTML = `
    <div class="page-head"><div><h1>Deploy agent</h1><div class="muted">Works on Windows Server 2016+ and Windows 10/11 · runs as SYSTEM · no extra software needed</div></div></div>
    <div class="grid">
      <div class="card"><h2>1. Quick install (run in an elevated PowerShell or Command Prompt)</h2>
        <div class="copy-box"><code id="cmd-oneliner">${esc(oneLiner)}</code><button class="btn" data-copy="cmd-oneliner">Copy</button></div>
      </div>
      <div class="card"><h2>2. Offline install</h2>
        <p class="muted" style="margin-top:-6px">Download these files, copy them to the machine, and run from an elevated PowerShell in that folder:</p>
        <p>${d.files.map((f) => `<a class="btn small" href="/download/${esc(f)}">${esc(f)}</a>`).join(' ')}
          ${d.hasCertificate ? '<a class="btn small" href="/download/server.cer">server.cer</a>' : ''}</p>
        <div class="copy-box"><code id="cmd-offline">${esc(offline)}${d.hasCertificate ? " -CertificateFile '.\\server.cer'" : ''}</code><button class="btn" data-copy="cmd-offline">Copy</button></div>
      </div>
      <div class="card"><h2>3. Mass deployment (Group Policy, Intune, SCCM, RMM)</h2>
        <p class="muted" style="margin-top:-6px">Put the three files on a share readable by Domain Computers and use this as a computer startup script:</p>
        <div class="copy-box"><code id="cmd-gpo">${esc(gpo)}</code><button class="btn" data-copy="cmd-gpo">Copy</button></div>
      </div>
      <div class="card"><h2>Enrollment token</h2>
        <p class="muted" style="margin-top:-6px">Anyone holding this token can enroll a machine. Rotate it if it leaks; enrolled endpoints keep working.</p>
        <div class="copy-box"><code id="enroll-token">${esc(d.enrollToken)}</code><button class="btn" data-copy="enroll-token">Copy</button><button class="btn danger" id="rotate">Rotate</button></div>
        <p class="muted" style="margin-bottom:0">Uninstall: run <code>Uninstall-Shield360Agent.ps1</code> as administrator, then remove the endpoint from the console.</p>
      </div>
    </div>`;
  view().querySelectorAll('[data-copy]').forEach((b) => b.addEventListener('click', async () => {
    await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent).catch(() => {});
    toast('Copied to clipboard');
  }));
  $('#rotate').addEventListener('click', async () => {
    if (!confirm('Generate a new enrollment token? The old one stops working immediately.')) return;
    await api('POST', '/api/deploy/rotate-token');
    toast('Enrollment token rotated');
    renderDeploy();
  });
}

// ---------------------------------------------------------------- settings

async function renderSettings() {
  const log = await api('GET', '/api/audit');
  view().innerHTML = `
    <div class="page-head"><div><h1>Settings</h1></div></div>
    <div class="grid two">
      <div class="card"><h2>Change password</h2>
        <form id="pw-form" style="display:grid;gap:12px;max-width:360px">
          <label>Current password<input type="password" name="currentPassword" autocomplete="current-password" required></label>
          <label>New password (min 10 characters)<input type="password" name="newPassword" autocomplete="new-password" minlength="10" required></label>
          <div id="pw-error" class="error"></div>
          <div><button class="btn primary">Update password</button></div>
        </form>
        <p class="muted" style="margin-bottom:0">Alert thresholds, check-in interval and TLS are configured in <code>server/config.json</code>.</p>
      </div>
      <div class="card table-wrap"><h2>Audit log</h2>
        <table><thead><tr><th>Time</th><th>User</th><th>Event</th><th>Detail</th></tr></thead><tbody>
        ${log.map((e) => `<tr><td class="nowrap muted">${fmtDate(e.ts)}</td><td>${esc(e.username || '—')}</td><td class="mono">${esc(e.action)}</td><td>${esc(e.detail)} <span class="muted">${esc(e.ip)}</span></td></tr>`).join('')}
        </tbody></table></div>
    </div>`;
  $('#pw-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    try {
      await api('POST', '/api/account/password', Object.fromEntries(f));
      toast('Password updated');
      e.target.reset();
      boot();
    } catch (err) { $('#pw-error').textContent = err.message; }
  });
}

boot().then(() => { if (!me) showLogin(); });
