// Shield360 Endpoint - management server.
// Zero external dependencies: Node.js >= 22.13 (built-in node:sqlite).

import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDb } from './db.js';
import { createAlerting, SEVERITY_RANK } from './alerts.js';
import {
  ASR_RULES, AUTO_ISOLATE_TRIGGERS, COMMAND_ACTIONS, WEBSITE_PRESETS, defaultPolicySettings, sanitizePolicy, versionOf,
  normalizeIoc, normalizeSites, validateCommandParams, BULK_ACTIONS, isIp,
} from './protection.js';
import { createDefinitionMirror, compareVersions, DEFINITION_ARCHES } from './definitions.js';
import { createLicensing } from './license.js';
import { computeReadiness } from './readiness.js';
import { createNotifier, DEFAULT_NOTIFICATIONS } from './notify.js';

export const VERSION = '1.11.0';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const AGENT_DIR = path.resolve(ROOT, '..', 'agent');
const DATA_DIR = process.env.SHIELD360_DATA_DIR || path.join(ROOT, 'data');
const CONFIG_FILE = process.env.SHIELD360_CONFIG || path.join(ROOT, 'config.json');

const AGENT_FILES = ['Shield360Agent.ps1', 'Install-Shield360Agent.ps1', 'Uninstall-Shield360Agent.ps1'];

// ---------------------------------------------------------------- log file

// When running as a background task (no console), also write output to data/logs/server.log so
// startup and runtime errors can be diagnosed. Rotates at 5 MB, keeping one previous file.
if (!process.stdout.isTTY) {
  const logFile = path.join(DATA_DIR, 'logs', 'server.log');
  fs.mkdirSync(path.dirname(logFile), { recursive: true });
  const write = (level, args) => {
    try {
      if (fs.existsSync(logFile) && fs.statSync(logFile).size > 5 * 1024 * 1024) fs.renameSync(logFile, `${logFile}.1`);
      const text = args.map((a) => (a instanceof Error ? a.stack : typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
      fs.appendFileSync(logFile, `${new Date().toISOString()} [${level}] ${text}\n`);
    } catch { /* logging must never stop the server */ }
  };
  const log = console.log.bind(console);
  const error = console.error.bind(console);
  console.log = (...a) => { log(...a); write('INFO', a); };
  console.error = (...a) => { error(...a); write('ERROR', a); };
  process.on('uncaughtException', (e) => { write('FATAL', [e]); process.exit(1); });
}

// ---------------------------------------------------------------- config

const DEFAULT_CONFIG = {
  host: '0.0.0.0',
  port: 8080,
  publicUrl: '',          // address agents use, e.g. https://shield360.example.com:8443 (shown in install commands)
  adminAllowedIps: [],    // when set, the console and admin API only answer these IPs/CIDRs (agents: any IP)
  trustProxy: false,      // behind a reverse proxy: take the client IP from X-Forwarded-For
  tls: { pfx: '', passphrase: '', cert: '', key: '' },
  enrollToken: '',
  checkinIntervalSec: 60,
  offlineAfterMin: 5,
  metricRetentionDays: 30,
  telemetryRetentionDays: 14,   // EDR process and network history
  sessionHours: 12,
  thresholds: { cpu: 90, memory: 90, disk: 90, signatureAgeDays: 3, failedLogonsPerHour: 20 },
  // Mirror of Microsoft Defender definitions for endpoints that cannot reach Microsoft directly.
  definitionMirror: { enabled: true, arches: ['x64'], refreshHours: 4 },
};

function loadConfig() {
  let file = {};
  // Strip a BOM: Windows PowerShell 5.1 writes one when it edits the file.
  if (fs.existsSync(CONFIG_FILE)) file = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8').replace(/^﻿/, ''));
  const cfg = {
    ...DEFAULT_CONFIG, ...file,
    tls: { ...DEFAULT_CONFIG.tls, ...(file.tls || {}) },
    thresholds: { ...DEFAULT_CONFIG.thresholds, ...(file.thresholds || {}) },
    definitionMirror: { ...DEFAULT_CONFIG.definitionMirror, ...(file.definitionMirror || {}) },
  };
  cfg.definitionMirror.arches = (cfg.definitionMirror.arches || []).filter((a) => DEFINITION_ARCHES.includes(a));
  if (!cfg.enrollToken) {
    cfg.enrollToken = newEnrollToken();
    saveConfig(cfg);
    console.log(`[setup] Created ${CONFIG_FILE} with a new enrollment token.`);
  }
  return cfg;
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

function newEnrollToken() {
  return crypto.randomBytes(24).toString('base64url');
}

const config = loadConfig();
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = openDb(path.join(DATA_DIR, 'shield360.db'));
const alerting = createAlerting(db, config, (alert) => notifier.enqueue(alert));
const mirror = createDefinitionMirror(DATA_DIR, config.definitionMirror);
const licensing = createLicensing(db, DATA_DIR);   // also creates the settings table

const getSetting = (k) => db.prepare('SELECT value FROM settings WHERE key = ?').get(k)?.value;
const setSetting = (k, v) => db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(k, String(v));

// Uninstall protection: when enabled, a local uninstall on an endpoint needs this code. Agents only
// receive a salted hash; uninstalls started from the console use a one-time token instead.
function uninstallProtection() {
  try { return JSON.parse(getSetting('uninstallProtection') || '{}'); } catch { return {}; }
}

function notificationSettings() {
  let saved = {};
  try { saved = JSON.parse(getSetting('notifications') || '{}'); } catch { /* defaults */ }
  const d = DEFAULT_NOTIFICATIONS;
  return {
    ...d, ...saved,
    email: { ...d.email, ...(saved.email || {}) }, teams: { ...d.teams, ...(saved.teams || {}) }, webhook: { ...d.webhook, ...(saved.webhook || {}) },
  };
}

// The agent version this server ships (agent\Shield360Agent.ps1), with file checksums for verified self-update.
let agentReleaseCache = null;
function agentRelease() {
  const main = path.join(AGENT_DIR, 'Shield360Agent.ps1');
  try {
    const mtime = fs.statSync(main).mtimeMs;
    if (agentReleaseCache?.mtime === mtime) return agentReleaseCache;
    const files = ['Shield360Agent.ps1', 'Uninstall-Shield360Agent.ps1'].map((name) => ({
      name, sha256: crypto.createHash('sha256').update(fs.readFileSync(path.join(AGENT_DIR, name))).digest('hex').toUpperCase(),
    }));
    const version = /\$AgentVersion = '([\d.]+)'/.exec(fs.readFileSync(main, 'utf8'))?.[1] || null;
    agentReleaseCache = { mtime, version, files };
  } catch { agentReleaseCache = { mtime: 0, version: null, files: [] }; }
  return agentReleaseCache;
}
const agentAutoUpdate = () => getSetting('agentAutoUpdate') !== 'off';

const notifier = createNotifier({
  getSettings: notificationSettings,
  lookupAgent: (id) => db.prepare('SELECT hostname, product_type FROM agents WHERE id = ?').get(id),
  consoleUrl: () => (config.publicUrl || '').replace(/\/$/, ''),
});
const useTls = !!(config.tls.pfx || (config.tls.cert && config.tls.key));

// ---------------------------------------------------------------- crypto helpers

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pw, salt, 64);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(pw, stored) {
  const [, salt, hash] = String(stored).split('$');
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, 'base64');
  const actual = crypto.scryptSync(pw, Buffer.from(salt, 'base64'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

function ensureAdmin() {
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) return;
  const password = process.env.SHIELD360_ADMIN_PASSWORD || crypto.randomBytes(12).toString('base64url');
  db.prepare('INSERT INTO users (username, pass_hash, must_change, created_at) VALUES (?, ?, 1, ?)')
    .run('admin', hashPassword(password), Date.now());
  const note = path.join(DATA_DIR, 'initial-admin-password.txt');
  fs.writeFileSync(note, `username: admin\npassword: ${password}\n\nDelete this file after you sign in and change the password.\n`);
  console.log(`[setup] Created admin user. Initial password written to ${note}`);
}
ensureAdmin();

if (!db.prepare('SELECT 1 FROM policies WHERE id = 1').get()) {
  db.prepare("INSERT INTO policies (id, name, description, settings, updated_at) VALUES (1, 'Default', ?, ?, ?)")
    .run('Recommended protection for all endpoints', JSON.stringify(defaultPolicySettings()), Date.now());
}

if (!db.prepare('SELECT 1 FROM endpoint_groups WHERE id = 1').get()) {
  db.prepare("INSERT INTO endpoint_groups (id, name, description, policy_id, priority, created_at, updated_at) VALUES (1, 'Default', ?, 1, 1000, ?, ?)")
    .run('Endpoints not placed in another group', Date.now(), Date.now());
}

// ---------------------------------------------------------------- endpoint groups

const AGENT_TYPES = { 1: 'Workstation', 2: 'Domain Controller', 3: 'Server' };

function sanitizeRules(r = {}) {
  const types = (Array.isArray(r.types) ? r.types : []).filter((t) => Object.values(AGENT_TYPES).includes(t));
  const hostnames = (Array.isArray(r.hostnames) ? r.hostnames : String(r.hostnames || '').split(/[\r\n,]+/))
    .map((s) => String(s).trim()).filter((s) => /^[\w.*?-]{1,64}$/.test(s)).slice(0, 50);
  return { types: [...new Set(types)], hostnames: [...new Set(hostnames)] };
}

const wildcard = (pattern) => new RegExp('^' + pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i');

// A group with no rules never auto-matches. Types and hostname patterns must both match when both are set.
function groupMatches(rules, hostname, productType) {
  if (!rules.types.length && !rules.hostnames.length) return false;
  if (rules.types.length && !rules.types.includes(AGENT_TYPES[productType])) return false;
  if (rules.hostnames.length && !rules.hostnames.some((p) => wildcard(p).test(hostname || ''))) return false;
  return true;
}

function autoAssignGroup(hostname, productType) {
  const groups = db.prepare('SELECT id, rules FROM endpoint_groups WHERE id <> 1 ORDER BY priority, id').all();
  for (const g of groups) if (groupMatches(sanitizeRules(parse(g.rules, {})), hostname, productType)) return g.id;
  return 1;
}

// Endpoint override wins; otherwise the group's policy; otherwise Default.
function effectivePolicyId(agent) {
  if (agent.policy_override) return agent.policy_override;
  return db.prepare('SELECT policy_id FROM endpoint_groups WHERE id = ?').get(agent.group_id)?.policy_id || 1;
}

function policyFor(policyId) {
  const row = db.prepare('SELECT * FROM policies WHERE id = ?').get(policyId) || db.prepare('SELECT * FROM policies WHERE id = 1').get();
  const settings = sanitizePolicy(JSON.parse(row.settings));
  return { id: row.id, name: row.name, settings, version: versionOf(settings) };
}

function currentIocs() {
  const rows = db.prepare('SELECT type, value FROM iocs ORDER BY id').all();
  const list = { hashes: [], ips: [], domains: [] };
  for (const r of rows) list[{ hash: 'hashes', ip: 'ips', domain: 'domains' }[r.type]].push(r.value);
  return { ...list, version: versionOf(list) };
}

// ---------------------------------------------------------------- http plumbing

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.ico': 'image/x-icon', '.ps1': 'text/plain; charset=utf-8', '.cer': 'application/pkix-cert',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'",
};

function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  const payload = isBuf || typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    'Content-Type': isBuf || typeof body === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(payload);
}

function readJson(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    if (!/application\/json/i.test(req.headers['content-type'] || '')) {
      return reject(new HttpError(415, 'Content-Type must be application/json'));
    }
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Payload too large')); req.destroy(); }
      else chunks.push(c);
    });
    req.on('end', () => {
      try {
        let text = Buffer.concat(chunks).toString('utf8');
        if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
        resolve(text ? JSON.parse(text) : {});
      } catch { reject(new HttpError(400, 'Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) {
  // Behind a trusted proxy: Cloudflare's CF-Connecting-IP, otherwise the first X-Forwarded-For address.
  const forwarded = config.trustProxy
    ? String(req.headers['cf-connecting-ip'] || String(req.headers['x-forwarded-for'] || '').split(',')[0]).trim() : '';
  return (forwarded || req.socket.remoteAddress || '').replace(/^::ffff:/, '');
}

// Exact IPv4/IPv6 match, or IPv4 CIDR such as 203.0.113.0/24.
function ipMatches(ip, rule) {
  if (!rule.includes('/')) return ip.toLowerCase() === rule.toLowerCase();
  const [base, bitsText] = rule.split('/');
  const toNum = (v) => v.split('.').reduce((n, o) => (n << 8) + Number(o), 0) >>> 0;
  if (!/^\d+\.\d+\.\d+\.\d+$/.test(ip) || !/^\d+\.\d+\.\d+\.\d+$/.test(base)) return false;
  const bits = Number(bitsText);
  const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
  return (toNum(ip) & mask) === (toNum(base) & mask);
}

const isLoopback = (ip) => ip === '127.0.0.1' || ip === '::1';

// True when the browser reached us over HTTPS: directly, or through a trusted proxy that terminated TLS.
const viaHttps = (req) => useTls || (config.trustProxy && String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https');

// The console and admin API are limited to adminAllowedIps when set. Agent check-ins and agent
// downloads stay open to any address, and the server itself (loopback) is always allowed.
function adminNetworkAllowed(req) {
  const list = config.adminAllowedIps || [];
  const ip = clientIp(req);
  return !list.length || isLoopback(ip) || list.some((r) => ipMatches(ip, r));
}
const AGENT_PATHS = /^\/(api\/agent\/|download\/)/;

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

const routes = [];
const route = (method, pattern, handler) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler });
};

// ---------------------------------------------------------------- auth

const loginAttempts = new Map(); // ip -> { count, until }

function checkLoginThrottle(ip) {
  const e = loginAttempts.get(ip);
  if (e && e.until > Date.now()) throw new HttpError(429, 'Too many failed attempts. Try again in a few minutes.');
}

function noteLoginFailure(ip) {
  const e = loginAttempts.get(ip) || { count: 0, until: 0 };
  e.count += 1;
  if (e.count >= 5) { e.until = Date.now() + 5 * 60 * 1000; e.count = 0; }
  loginAttempts.set(ip, e);
}

function requireAdmin(req) {
  const token = parseCookies(req).s360_session;
  if (!token) throw new HttpError(401, 'Not signed in');
  const row = db.prepare(
    `SELECT u.id, u.username, u.must_change FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`
  ).get(sha256(token), Date.now());
  if (!row) throw new HttpError(401, 'Session expired');
  // An account still on its initial password may only identify itself and set a new password.
  if (row.must_change && !PASSWORD_CHANGE_PATHS.has(new URL(req.url, 'http://x').pathname)) {
    throw new HttpError(403, 'You must change the initial password before using the console.');
  }
  row.tokenHash = sha256(token);
  return row;
}

const PASSWORD_CHANGE_PATHS = new Set(['/api/me', '/api/account/password']);

// Returns a reason the password is not acceptable, or null.
function passwordProblem(pw, username) {
  if (pw.length < 10) return 'Use at least 10 characters.';
  if (pw.length > 200) return 'Use at most 200 characters.';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Use both letters and numbers.';
  if (username && pw.toLowerCase().includes(String(username).toLowerCase())) return 'The password must not contain the username.';
  if (/^(.)\1+$/.test(pw) || /^(password|admin|shield360)/i.test(pw)) return 'This password is too easy to guess.';
  return null;
}

function requireAgent(req) {
  const m = /^Agent ([\w-]+):([\w-]+)$/.exec(req.headers.authorization || '');
  if (!m) throw new HttpError(401, 'Missing agent credentials');
  const agent = db.prepare('SELECT * FROM agents WHERE id = ?').get(m[1]);
  if (!agent || !safeEqual(agent.key_hash, sha256(m[2]))) throw new HttpError(401, 'Invalid agent credentials');
  return agent;
}

function audit(req, user, action, detail = '') {
  db.prepare('INSERT INTO audit (ts, username, ip, action, detail) VALUES (?, ?, ?, ?, ?)')
    .run(Date.now(), user?.username ?? null, clientIp(req), action, detail);
}

// ---------------------------------------------------------------- agent API

const str = (v, max = 512) => (v == null ? null : String(v).slice(0, max));

function applySystem(agentId, sys, req, agentVersion) {
  db.prepare(
    `UPDATE agents SET hostname = ?, device_id = COALESCE(?, device_id), os_name = ?, os_version = ?, os_build = ?,
       product_type = ?, domain = ?, manufacturer = ?, model = ?, serial = ?, cpu_model = ?, cores = ?,
       ram_total_mb = ?, ip_addresses = ?, mac_addresses = ?, logged_on_users = ?, last_boot = ?,
       agent_version = COALESCE(?, agent_version), remote_ip = ?, last_seen = ?
     WHERE id = ?`
  ).run(
    str(sys.hostname, 255) || 'unknown', str(sys.deviceId, 64), str(sys.osName), str(sys.osVersion, 64), str(sys.osBuild, 64),
    Number(sys.productType) || null, str(sys.domain), str(sys.manufacturer), str(sys.model), str(sys.serial),
    str(sys.cpuModel), Number(sys.cores) || null, Number(sys.ramTotalMB) || null,
    JSON.stringify(sys.ipAddresses || []), JSON.stringify(sys.macAddresses || []),
    JSON.stringify(sys.loggedOnUsers || []), str(sys.lastBoot, 64), str(agentVersion, 32), clientIp(req), Date.now(),
    agentId,
  );
}

route('POST', '/api/agent/enroll', async (req, res) => {
  const body = await readJson(req);
  if (!safeEqual(body.enrollToken || '', config.enrollToken)) {
    audit(req, null, 'agent.enroll_rejected', str(body.system?.hostname));
    throw new HttpError(403, 'Invalid enrollment token');
  }
  const sys = body.system || {};
  const key = crypto.randomBytes(32).toString('base64url');
  // Re-installing on the same machine keeps its history (matched by Windows MachineGuid).
  const existing = sys.deviceId ? db.prepare('SELECT id FROM agents WHERE device_id = ?').get(String(sys.deviceId)) : null;
  // Re-enrolling a known machine never needs a seat; a new machine needs a valid license and a free seat.
  if (!existing) {
    const lic = licensing.status();
    if (!lic.canEnroll) {
      audit(req, null, 'agent.enroll_rejected', `${str(sys.hostname)}: ${lic.restricted ? 'license ' + lic.state : 'no free seats'}`);
      throw new HttpError(403, lic.restricted
        ? 'Shield360 license expired: new endpoints cannot be enrolled. Ask your administrator to renew the license.'
        : `Shield360 license seat limit reached (${lic.seatsUsed}/${lic.seats}). Remove unused endpoints or upgrade the license.`);
    }
  }
  const id = existing?.id || crypto.randomUUID();
  if (existing) db.prepare('UPDATE agents SET key_hash = ? WHERE id = ?').run(sha256(key), id);
  else {
    const groupId = autoAssignGroup(str(sys.hostname, 255), Number(sys.productType));
    db.prepare('INSERT INTO agents (id, key_hash, hostname, group_id, first_seen) VALUES (?, ?, ?, ?, ?)')
      .run(id, sha256(key), str(sys.hostname, 255) || 'unknown', groupId, Date.now());
  }
  applySystem(id, sys, req, body.agentVersion);
  const groupName = db.prepare('SELECT g.name FROM agents a JOIN endpoint_groups g ON g.id = a.group_id WHERE a.id = ?').get(id)?.name;
  audit(req, null, existing ? 'agent.reenrolled' : 'agent.enrolled', `${sys.hostname} (${id}) -> group ${groupName}`);
  send(res, 200, { agentId: id, agentKey: key, interval: config.checkinIntervalSec });
});

route('POST', '/api/agent/checkin', async (req, res) => {
  const agent = requireAgent(req);
  const body = await readJson(req);
  const sys = body.system || {};
  const metrics = body.metrics || {};
  applySystem(agent.id, sys, req, body.agentVersion);

  const diskMax = Math.max(0, ...(metrics.disks || []).map((d) => Number(d.usedPct) || 0));
  db.prepare('INSERT INTO metrics (agent_id, ts, cpu, mem, disk) VALUES (?, ?, ?, ?, ?)')
    .run(agent.id, Date.now(), Number(metrics.cpu) || 0, Number(metrics.memPct) || 0, diskMax);
  db.prepare('UPDATE agents SET state = ? WHERE id = ?').run(JSON.stringify({
    metrics, security: body.security || {}, protection: body.protection || null, reportedAt: Date.now(),
  }), agent.id);

  const policy = policyFor(effectivePolicyId(agent));
  alerting.evaluate(agent, body, policy.settings);
  for (const e of (body.events || []).slice(0, 200)) alerting.recordEvent(agent.id, e);
  storeTelemetry(agent.id, body.telemetry);

  const pending = db.prepare("SELECT id, action, params FROM commands WHERE agent_id = ? AND status = 'pending' ORDER BY id").all(agent.id);
  if (pending.length) {
    const mark = db.prepare("UPDATE commands SET status = 'sent', sent_at = ? WHERE id = ?");
    for (const c of pending) mark.run(Date.now(), c.id);
  }

  // Policy and blocklist are only sent when the agent's copy is out of date.
  const iocs = currentIocs();
  const reply = {
    interval: config.checkinIntervalSec,
    serverVersion: VERSION,
    commands: pending.map((c) => ({ id: c.id, action: c.action, params: parse(c.params, {}) })),
    definitions: mirror.forAgents(),
    uninstallProtection: (({ enabled, salt, hash }) => (enabled ? { enabled: true, salt, hash } : { enabled: false }))(uninstallProtection()),
  };
  // Offer a newer agent; the checksums travel in this authenticated reply, the files come from /download.
  const release = agentRelease();
  if (agentAutoUpdate() && release.version && body.agentVersion && compareVersions(release.version, body.agentVersion) > 0) {
    reply.agentUpdate = { version: release.version, files: release.files };
  }
  if (body.protection?.policyVersion !== policy.version) {
    reply.policy = {
      ...policy.settings, version: policy.version, name: policy.name,
      asrNames: Object.fromEntries(ASR_RULES.map((r) => [r.id, r.name])),
    };
  }
  if (body.protection?.iocVersion !== iocs.version) reply.iocs = iocs;
  send(res, 200, reply);
});

route('POST', '/api/agent/inventory', async (req, res) => {
  const agent = requireAgent(req);
  const inv = await readJson(req);
  db.prepare('UPDATE agents SET inventory = ?, inventory_at = ?, last_seen = ? WHERE id = ?')
    .run(JSON.stringify(inv), Date.now(), Date.now(), agent.id);
  alerting.evaluateInventory(agent, inv);
  send(res, 200, { ok: true });
});

// Sent by the uninstaller on the endpoint as its last step: remove the endpoint and free its license seat.
route('POST', '/api/agent/uninstalled', async (req, res) => {
  const agent = requireAgent(req);
  const body = await readJson(req);
  db.prepare('DELETE FROM agents WHERE id = ?').run(agent.id);
  audit(req, null, 'agent.uninstalled', `${agent.hostname} (${agent.id}) - ${body.remote ? 'from the console' : 'locally on the endpoint'}`);
  send(res, 200, { ok: true });
});

route('POST', '/api/agent/commands/:id/result', async (req, res, p) => {
  const agent = requireAgent(req);
  const body = await readJson(req);
  const r = db.prepare(
    "UPDATE commands SET status = ?, output = ?, completed_at = ? WHERE id = ? AND agent_id = ? AND status = 'sent'"
  ).run(body.success ? 'success' : 'failed', str(body.output, 64 * 1024), Date.now(), Number(p.id), agent.id);
  if (!r.changes) throw new HttpError(404, 'Command not found');
  send(res, 200, { ok: true });
});

// ---------------------------------------------------------------- admin API

const isOnline = (a) => a.last_seen && Date.now() - a.last_seen < config.offlineAfterMin * 60 * 1000;
const parse = (s, fallback) => { try { return s ? JSON.parse(s) : fallback; } catch { return fallback; } };

function protectionStatus(security) {
  const d = security?.defender || {};
  const av = (security?.antivirus || []).filter((a) => a.enabled && !/defender/i.test(a.name || ''));
  if (d.present && d.antivirusEnabled && d.mode !== 'Passive Mode') {
    if (!d.realTimeProtection) return { level: 'bad', label: 'Real-time off' };
    if (d.signatureAgeDays > config.thresholds.signatureAgeDays) return { level: 'warn', label: 'Outdated' };
    return { level: 'good', label: 'Protected' };
  }
  if (av.length) return { level: 'good', label: av[0].name };
  return { level: 'bad', label: 'Unprotected' };
}

// Lookup tables for list views, so each endpoint row doesn't hit the database again.
function lookups() {
  return {
    policies: new Map(db.prepare('SELECT id, name, settings FROM policies').all().map((p) => {
      const settings = sanitizePolicy(JSON.parse(p.settings));
      return [p.id, { name: p.name, version: versionOf(settings) }];
    })),
    groups: new Map(db.prepare('SELECT id, name, policy_id FROM endpoint_groups').all().map((g) => [g.id, g])),
  };
}

function agentSummary(a, alertStats, lk = lookups()) {
  const group = lk.groups.get(a.group_id) || lk.groups.get(1);
  const policyId = (a.policy_override && lk.policies.has(a.policy_override)) ? a.policy_override : (group?.policy_id || 1);
  const policy = lk.policies.get(policyId) || lk.policies.get(1);
  const state = parse(a.state, {});
  const m = state.metrics || {};
  const prot = state.protection || {};
  const stats = alertStats.get(a.id);
  const compliance = prot.compliance || [];
  return {
    id: a.id,
    hostname: a.hostname,
    type: a.product_type === 1 ? 'Workstation' : a.product_type === 2 ? 'Domain Controller' : a.product_type === 3 ? 'Server' : 'Unknown',
    osName: a.os_name,
    osBuild: a.os_build,
    domain: a.domain,
    ipAddresses: parse(a.ip_addresses, []),
    loggedOnUsers: parse(a.logged_on_users, []),
    online: !!isOnline(a),
    lastSeen: a.last_seen,
    agentVersion: a.agent_version,
    tags: a.tags,
    cpu: m.cpu ?? null,
    mem: m.memPct ?? null,
    disk: Math.max(0, ...(m.disks || []).map((d) => d.usedPct || 0)),
    protection: protectionStatus(state.security),
    groupId: group?.id || 1,
    groupName: group?.name || 'Default',
    policyId,
    policyName: policy?.name || 'Default',
    policySource: a.policy_override ? 'override' : 'group',
    policyOverride: a.policy_override || null,
    policyApplied: !!prot.policyVersion && prot.policyVersion === policy?.version,
    compliance: compliance.length ? Math.round((compliance.filter((c) => c.ok).length / compliance.length) * 100) : null,
    isolated: !!prot.isolated,
    openAlerts: stats?.count || 0,
    worstSeverity: stats?.worst || null,
  };
}

function openAlertStats() {
  const map = new Map();
  for (const r of db.prepare('SELECT agent_id, severity FROM alerts WHERE resolved_at IS NULL').all()) {
    const e = map.get(r.agent_id) || { count: 0, worst: null };
    e.count += 1;
    if (!e.worst || SEVERITY_RANK[r.severity] > SEVERITY_RANK[e.worst]) e.worst = r.severity;
    map.set(r.agent_id, e);
  }
  return map;
}

function getAgentOr404(id) {
  const a = db.prepare('SELECT * FROM agents WHERE id = ?').get(id);
  if (!a) throw new HttpError(404, 'Endpoint not found');
  return a;
}

route('POST', '/api/login', async (req, res) => {
  const ip = clientIp(req);
  checkLoginThrottle(ip);
  const { username, password } = await readJson(req);
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(String(username || ''));
  if (!user || !verifyPassword(String(password || ''), user.pass_hash)) {
    noteLoginFailure(ip);
    audit(req, { username: str(username, 64) }, 'login.failed');
    throw new HttpError(401, 'Invalid username or password');
  }
  loginAttempts.delete(ip);
  const token = crypto.randomBytes(32).toString('base64url');
  const maxAge = config.sessionHours * 3600;
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .run(sha256(token), user.id, Date.now() + maxAge * 1000);
  audit(req, user, 'login');
  send(res, 200, { username: user.username, mustChange: !!user.must_change }, {
    'Set-Cookie': `s360_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${viaHttps(req) ? '; Secure' : ''}`,
  });
});

route('POST', '/api/logout', async (req, res) => {
  const token = parseCookies(req).s360_session;
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  send(res, 200, { ok: true }, { 'Set-Cookie': 's360_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
});

route('GET', '/api/me', async (req, res) => {
  const u = requireAdmin(req);
  const lic = licensing.status();
  send(res, 200, {
    username: u.username, mustChange: !!u.must_change, version: VERSION,
    license: { state: lic.state, message: lic.message, restricted: lic.restricted, overSeats: lic.overSeats },
  });
});

// ---------------------------------------------------------------- licensing

route('GET', '/api/license', async (req, res) => {
  requireAdmin(req);
  send(res, 200, licensing.status());
});

route('POST', '/api/license', async (req, res) => {
  const u = requireAdmin(req);
  const { license } = await readJson(req);
  let lic;
  try { lic = licensing.install(license); } catch (e) {
    audit(req, u, 'license.install_failed', e.message);
    throw new HttpError(400, e.message);
  }
  audit(req, u, 'license.installed', `${lic.customer}, ${lic.edition}, ${lic.seats} seats, expires ${lic.expiresAt || 'never'} (${lic.licenseId})`);
  send(res, 200, licensing.status());
});

route('DELETE', '/api/license', async (req, res) => {
  const u = requireAdmin(req);
  licensing.remove();
  audit(req, u, 'license.removed');
  send(res, 200, licensing.status());
});

route('POST', '/api/account/password', async (req, res) => {
  const u = requireAdmin(req);
  const { currentPassword, newPassword } = await readJson(req);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(u.id);
  // The mandatory first change follows a sign-in with the initial password, so it isn't asked again.
  if (!user.must_change && !verifyPassword(String(currentPassword || ''), user.pass_hash)) {
    throw new HttpError(400, 'Current password is incorrect');
  }
  const pw = String(newPassword || '');
  const problem = passwordProblem(pw, user.username);
  if (problem) throw new HttpError(400, problem);
  if (verifyPassword(pw, user.pass_hash)) throw new HttpError(400, 'The new password must be different from the current one.');
  db.prepare('UPDATE users SET pass_hash = ?, must_change = 0 WHERE id = ?').run(hashPassword(pw), u.id);
  // Sign out every other session of this account.
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?').run(u.id, u.tokenHash);
  // The initial password no longer works, so its file is removed.
  let removedInitialFile = false;
  if (user.must_change) {
    const initialFile = path.join(DATA_DIR, 'initial-admin-password.txt');
    if (fs.existsSync(initialFile)) { fs.rmSync(initialFile, { force: true }); removedInitialFile = true; }
  }
  audit(req, u, user.must_change ? 'account.initial_password_changed' : 'account.password_changed',
    removedInitialFile ? 'initial password file deleted' : '');
  send(res, 200, { ok: true });
});

route('GET', '/api/summary', async (req, res) => {
  requireAdmin(req);
  const stats = openAlertStats();
  const lk = lookups();
  const agents = db.prepare('SELECT * FROM agents').all().map((a) => agentSummary(a, stats, lk));
  const sev = Object.fromEntries(
    db.prepare('SELECT severity, COUNT(*) AS n FROM alerts WHERE resolved_at IS NULL GROUP BY severity').all().map((r) => [r.severity, r.n])
  );
  const recentAlerts = db.prepare(
    `SELECT al.*, ag.hostname FROM alerts al JOIN agents ag ON ag.id = al.agent_id
     WHERE al.resolved_at IS NULL ORDER BY al.updated_at DESC LIMIT 8`
  ).all();
  const dayAgo = Date.now() - 86400 * 1000;
  const scored = agents.filter((a) => a.compliance != null);
  const defs = definitionRows();
  const withDefender = defs.rows.filter((r) => r.defender);
  const ready = readinessRows().filter((r) => r.score != null);
  send(res, 200, {
    readiness: ready.length ? Math.round(ready.reduce((s, r) => s + r.score, 0) / ready.length) : null,
    definitions: {
      latest: defs.latest, total: withDefender.length,
      upToDate: withDefender.filter((r) => r.status === 'latest').length,
      outdated: withDefender.filter((r) => r.status === 'outdated').length,
    },
    blocked24h: db.prepare('SELECT COUNT(*) AS n FROM events WHERE blocked = 1 AND ts >= ?').get(dayAgo).n,
    malware24h: db.prepare("SELECT COUNT(*) AS n FROM events WHERE type = 'malware' AND ts >= ?").get(dayAgo).n,
    isolated: agents.filter((a) => a.isolated).length,
    compliance: scored.length ? Math.round(scored.reduce((s, a) => s + a.compliance, 0) / scored.length) : null,
    recentEvents: db.prepare(
      `SELECT e.id, e.agent_id, e.ts, e.type, e.severity, e.blocked, e.message, ag.hostname FROM events e
       JOIN agents ag ON ag.id = e.agent_id WHERE e.severity IN ('critical','high') OR e.blocked = 1 ORDER BY e.ts DESC LIMIT 8`
    ).all(),
    total: agents.length,
    online: agents.filter((a) => a.online).length,
    servers: agents.filter((a) => a.type !== 'Workstation').length,
    workstations: agents.filter((a) => a.type === 'Workstation').length,
    protected: agents.filter((a) => a.protection.level === 'good').length,
    alertsBySeverity: sev,
    recentAlerts,
    attention: agents
      .filter((a) => a.worstSeverity === 'critical' || a.worstSeverity === 'high')
      .sort((x, y) => SEVERITY_RANK[y.worstSeverity] - SEVERITY_RANK[x.worstSeverity] || y.openAlerts - x.openAlerts)
      .slice(0, 8),
  });
});

route('GET', '/api/agents', async (req, res) => {
  requireAdmin(req);
  const stats = openAlertStats();
  const lk = lookups();
  const rows = db.prepare('SELECT * FROM agents ORDER BY hostname COLLATE NOCASE').all();
  send(res, 200, rows.map((a) => agentSummary(a, stats, lk)));
});

route('GET', '/api/agents/:id', async (req, res, p) => {
  requireAdmin(req);
  const a = getAgentOr404(p.id);
  const stats = openAlertStats();
  send(res, 200, {
    ...agentSummary(a, stats),
    deviceId: a.device_id,
    osVersion: a.os_version,
    manufacturer: a.manufacturer,
    model: a.model,
    serial: a.serial,
    cpuModel: a.cpu_model,
    cores: a.cores,
    ramTotalMB: a.ram_total_mb,
    macAddresses: parse(a.mac_addresses, []),
    lastBoot: a.last_boot,
    remoteIp: a.remote_ip,
    firstSeen: a.first_seen,
    state: parse(a.state, {}),
    inventory: parse(a.inventory, null),
    inventoryAt: a.inventory_at,
    alerts: db.prepare('SELECT * FROM alerts WHERE agent_id = ? ORDER BY resolved_at IS NOT NULL, updated_at DESC LIMIT 100').all(a.id),
    commands: db.prepare('SELECT * FROM commands WHERE agent_id = ? ORDER BY id DESC LIMIT 50').all(a.id)
      .map((c) => ({ ...c, params: parse(c.params, null) })),
    events: db.prepare('SELECT * FROM events WHERE agent_id = ? ORDER BY ts DESC LIMIT 200').all(a.id),
    readiness: readinessFor(a),
  });
});

route('GET', '/api/agents/:id/metrics', async (req, res, p) => {
  requireAdmin(req);
  getAgentOr404(p.id);
  const hours = Math.min(Math.max(Number(new URL(req.url, 'http://x').searchParams.get('hours')) || 24, 1), 24 * 30);
  const since = Date.now() - hours * 3600 * 1000;
  // Downsample to at most ~300 points per series.
  const bucket = Math.max(60000, Math.floor((hours * 3600 * 1000) / 300));
  const rows = db.prepare(
    `SELECT (ts / ?) * ? AS t, AVG(cpu) AS cpu, AVG(mem) AS mem, MAX(disk) AS disk
     FROM metrics WHERE agent_id = ? AND ts >= ? GROUP BY ts / ? ORDER BY t`
  ).all(bucket, bucket, p.id, since, bucket);
  send(res, 200, rows);
});

route('PATCH', '/api/agents/:id', async (req, res, p) => {
  const u = requireAdmin(req);
  getAgentOr404(p.id);
  const body = await readJson(req);
  const a = getAgentOr404(p.id);
  if (body.tags !== undefined) {
    db.prepare('UPDATE agents SET tags = ? WHERE id = ?').run(str(body.tags, 200) || '', p.id);
    audit(req, u, 'agent.tagged', `${a.hostname}: ${body.tags}`);
  }
  if (body.groupId !== undefined) {
    const g = db.prepare('SELECT id, name FROM endpoint_groups WHERE id = ?').get(Number(body.groupId));
    if (!g) throw new HttpError(400, 'Unknown group');
    db.prepare('UPDATE agents SET group_id = ? WHERE id = ?').run(g.id, p.id);
    audit(req, u, 'agent.group_changed', `${a.hostname} -> ${g.name}`);
  }
  // policyOverride: a policy id, or null to follow the group's policy again.
  if (body.policyOverride !== undefined) {
    let pol = null;
    if (body.policyOverride !== null) {
      pol = db.prepare('SELECT id, name FROM policies WHERE id = ?').get(Number(body.policyOverride));
      if (!pol) throw new HttpError(400, 'Unknown policy');
    }
    db.prepare('UPDATE agents SET policy_override = ? WHERE id = ?').run(pol?.id ?? null, p.id);
    audit(req, u, 'agent.policy_override', `${a.hostname} -> ${pol ? pol.name : 'follow group policy'}`);
  }
  send(res, 200, { ok: true });
});

route('DELETE', '/api/agents/:id', async (req, res, p) => {
  const u = requireAdmin(req);
  const a = getAgentOr404(p.id);
  db.prepare('DELETE FROM agents WHERE id = ?').run(a.id);
  audit(req, u, 'agent.deleted', `${a.hostname} (${a.id})`);
  send(res, 200, { ok: true });
});

route('POST', '/api/agents/:id/commands', async (req, res, p) => {
  const u = requireAdmin(req);
  const a = getAgentOr404(p.id);
  const { action, params } = await readJson(req);
  let clean;
  try { clean = validateCommandParams(action, params); } catch (e) { throw new HttpError(400, e.message); }
  const r = db.prepare('INSERT INTO commands (agent_id, action, params, created_by, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(a.id, action, JSON.stringify(clean), u.username, Date.now());
  audit(req, u, 'command.queued', `${action}${Object.keys(clean).length ? ' ' + JSON.stringify(clean) : ''} -> ${a.hostname}`);
  send(res, 200, { id: Number(r.lastInsertRowid) });
});

// Same action on many endpoints (Endpoints list selection). Only parameter-free actions.
route('POST', '/api/agents/bulk-commands', async (req, res) => {
  const u = requireAdmin(req);
  const { agentIds, action } = await readJson(req);
  if (!BULK_ACTIONS.includes(action)) throw new HttpError(400, 'This action cannot be sent to several endpoints at once');
  const ids = (Array.isArray(agentIds) ? agentIds : []).map(String).slice(0, 5000);
  const insert = db.prepare("INSERT INTO commands (agent_id, action, params, created_by, created_at) VALUES (?, ?, '{}', ?, ?)");
  const pending = db.prepare("SELECT 1 FROM commands WHERE agent_id = ? AND action = ? AND status IN ('pending','sent')");
  const names = [];
  for (const id of ids) {
    const a = db.prepare('SELECT id, hostname FROM agents WHERE id = ?').get(id);
    if (!a || pending.get(a.id, action)) continue;
    insert.run(a.id, action, u.username, Date.now());
    names.push(a.hostname);
  }
  audit(req, u, 'command.queued_bulk', `${action} -> ${names.length} endpoint(s): ${names.slice(0, 20).join(', ')}${names.length > 20 ? ', ...' : ''}`);
  send(res, 200, { queued: names.length });
});

// ---------------------------------------------------------------- EDR: telemetry, hunting, timeline

const insertProcess = () => db.prepare(
  `INSERT INTO telemetry_process (agent_id, ts, pid, ppid, name, path, cmdline, parent_name, username, sha256, signer, signed)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
const insertConnection = () => db.prepare(
  'INSERT INTO telemetry_net (agent_id, ts, pid, process, path, remote_ip, remote_port, local_port) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
const intOrNull = (v) => (Number.isFinite(Number(v)) && v !== null && v !== '' ? Math.trunc(Number(v)) : null);

function storeTelemetry(agentId, tel) {
  const procs = Array.isArray(tel?.processes) ? tel.processes.slice(0, 2000) : [];
  const nets = Array.isArray(tel?.connections) ? tel.connections.slice(0, 2000) : [];
  if (!procs.length && !nets.length) return;
  const now = Date.now();
  const ip = insertProcess();
  const ic = insertConnection();
  db.exec('BEGIN');
  try {
    for (const p of procs) {
      ip.run(agentId, Date.parse(p.time) || now, intOrNull(p.pid), intOrNull(p.ppid), str(p.name, 260), str(p.path, 1024), str(p.cmdline, 2000),
        str(p.parentName, 260), str(p.user, 256), p.sha256 ? String(p.sha256).toUpperCase().slice(0, 64) : null, str(p.signer, 256), p.signed ? 1 : 0);
    }
    for (const c of nets) {
      ic.run(agentId, Date.parse(c.time) || now, intOrNull(c.pid), str(c.process, 260), str(c.path, 1024),
        str(c.remoteIp, 64), intOrNull(c.remotePort), intOrNull(c.localPort));
    }
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}

const sinceHours = (req, def, max) => {
  const h = Number(new URL(req.url, 'http://x').searchParams.get('hours')) || def;
  return Date.now() - Math.min(Math.max(h, 1), max) * 3600 * 1000;
};

// Threat hunting across all endpoints: processes or network connections matching a search term.
route('GET', '/api/hunt', async (req, res) => {
  requireAdmin(req);
  const sp = new URL(req.url, 'http://x').searchParams;
  const type = sp.get('type') === 'network' ? 'network' : 'process';
  const q = String(sp.get('q') || '').trim().slice(0, 200);
  const agentId = sp.get('agentId');
  const since = sinceHours(req, 72, 24 * 90);
  const where = ['t.ts >= ?'];
  const args = [since];
  if (agentId) { where.push('t.agent_id = ?'); args.push(agentId); }
  if (type === 'process') {
    if (/^[a-f0-9]{64}$/i.test(q)) { where.push('t.sha256 = ?'); args.push(q.toUpperCase()); }
    else if (q) {
      where.push('(t.name LIKE ? OR t.path LIKE ? OR t.cmdline LIKE ? OR t.parent_name LIKE ? OR t.username LIKE ?)');
      args.push(...Array(5).fill(`%${q}%`));
    }
    if (sp.get('unsigned') === '1') where.push('t.signed = 0');
  } else if (q) {
    if (/^\d+$/.test(q)) { where.push('t.remote_port = ?'); args.push(Number(q)); }
    else { where.push('(t.remote_ip LIKE ? OR t.process LIKE ? OR t.path LIKE ?)'); args.push(`${q}%`, `%${q}%`, `%${q}%`); }
  }
  const table = type === 'process' ? 'telemetry_process' : 'telemetry_net';
  const rows = db.prepare(
    `SELECT t.*, a.hostname FROM ${table} t JOIN agents a ON a.id = t.agent_id WHERE ${where.join(' AND ')} ORDER BY t.ts DESC LIMIT 500`
  ).all(...args);
  send(res, 200, { type, rows });
});

// Programs seen on very few endpoints: something that exists on one PC only is worth a look.
route('GET', '/api/hunt/rare', async (req, res) => {
  requireAdmin(req);
  const since = sinceHours(req, 24 * 7, 24 * 90);
  const total = db.prepare('SELECT COUNT(*) AS n FROM agents').get().n;
  const maxEndpoints = total >= 10 ? 2 : 1;
  const rows = db.prepare(
    `SELECT COALESCE(t.sha256, t.path) AS id, t.sha256, MAX(t.path) AS path, MAX(t.name) AS name, MAX(t.signed) AS signed,
            MAX(t.signer) AS signer, COUNT(DISTINCT t.agent_id) AS endpoints, COUNT(*) AS starts,
            MIN(t.ts) AS first_seen, MAX(t.ts) AS last_seen, GROUP_CONCAT(DISTINCT a.hostname) AS hosts
     FROM telemetry_process t JOIN agents a ON a.id = t.agent_id
     WHERE t.ts >= ? AND t.path IS NOT NULL
     GROUP BY COALESCE(t.sha256, t.path)
     HAVING COUNT(DISTINCT t.agent_id) <= ?
     ORDER BY MAX(t.signed) ASC, MAX(t.ts) DESC LIMIT 300`
  ).all(since, maxEndpoints);
  send(res, 200, { total, maxEndpoints, rows });
});

// One endpoint's activity: process starts, connections and security events, newest first.
route('GET', '/api/agents/:id/timeline', async (req, res, p) => {
  requireAdmin(req);
  getAgentOr404(p.id);
  const since = sinceHours(req, 24, 24 * 30);
  send(res, 200, {
    processes: db.prepare('SELECT * FROM telemetry_process WHERE agent_id = ? AND ts >= ? ORDER BY ts DESC LIMIT 3000').all(p.id, since),
    connections: db.prepare('SELECT * FROM telemetry_net WHERE agent_id = ? AND ts >= ? ORDER BY ts DESC LIMIT 2000').all(p.id, since),
    events: db.prepare('SELECT * FROM events WHERE agent_id = ? AND ts >= ? ORDER BY ts DESC LIMIT 500').all(p.id, since),
  });
});

// ---------------------------------------------------------------- ransomware readiness

function readinessFor(a) {
  return computeReadiness(parse(a.state, {}), parse(a.inventory, null), a.product_type,
    policyFor(effectivePolicyId(a)).settings, parse(a.logged_on_users, []));
}

function readinessRows() {
  const lk = lookups();
  return db.prepare('SELECT * FROM agents ORDER BY hostname COLLATE NOCASE').all().map((a) => {
    const r = readinessFor(a);
    return {
      id: a.id, hostname: a.hostname, online: !!isOnline(a), groupName: lk.groups.get(a.group_id)?.name || 'Default',
      type: AGENT_TYPES[a.product_type] || 'Unknown', score: r.score, checks: r.checks,
    };
  });
}

route('GET', '/api/readiness', async (req, res) => {
  requireAdmin(req);
  const rows = readinessRows();
  const scored = rows.filter((r) => r.score != null);
  // How many endpoints fail each check: shows which measure would help the most.
  const failing = {};
  for (const r of rows) for (const c of r.checks) if (c.ok === false) failing[c.key] = (failing[c.key] || 0) + 1;
  send(res, 200, {
    average: scored.length ? Math.round(scored.reduce((s, r) => s + r.score, 0) / scored.length) : null,
    rows, failing,
  });
});

route('GET', '/api/command-actions', async (req, res) => {
  requireAdmin(req);
  send(res, 200, COMMAND_ACTIONS);
});

// ---------------------------------------------------------------- settings: notifications

const EMAIL_RE = /^[^\s@<>,]+@[^\s@<>,]+\.[^\s@<>,]+$/;

route('GET', '/api/settings/notifications', async (req, res) => {
  requireAdmin(req);
  const s = notificationSettings();
  // The SMTP password is never sent back to the browser.
  send(res, 200, { ...s, email: { ...s.email, password: '', hasPassword: !!s.email.password }, status: notifier.status() });
});

function readNotificationBody(body) {
  const cur = notificationSettings();
  const e = body.email || {};
  const url = (u, label) => {
    const v = String(u || '').trim();
    if (v && !/^https?:\/\/\S+$/i.test(v)) throw new HttpError(400, `${label} must be a web address starting with https://`);
    return v;
  };
  const to = (Array.isArray(e.to) ? e.to : String(e.to || '').split(/[\s,;]+/)).map((x) => String(x).trim()).filter(Boolean).slice(0, 20);
  for (const addr of [...to, ...(e.from ? [e.from] : [])]) if (!EMAIL_RE.test(addr)) throw new HttpError(400, `Not a valid email address: ${addr}`);
  const s = {
    minSeverity: ['critical', 'high', 'warning'].includes(body.minSeverity) ? body.minSeverity : 'high',
    workstationOffline: !!body.workstationOffline,
    email: {
      enabled: !!e.enabled, host: String(e.host || '').trim().slice(0, 200), port: Math.min(65535, Math.max(1, Number(e.port) || 587)),
      security: ['starttls', 'tls', 'none'].includes(e.security) ? e.security : 'starttls',
      username: String(e.username || '').slice(0, 200),
      password: e.password ? String(e.password).slice(0, 500) : cur.email.password,   // empty = keep the saved one
      from: String(e.from || '').trim(), to, allowSelfSigned: !!e.allowSelfSigned,
    },
    teams: { enabled: !!body.teams?.enabled, url: url(body.teams?.url, 'Teams webhook address') },
    webhook: { enabled: !!body.webhook?.enabled, url: url(body.webhook?.url, 'Webhook address') },
  };
  if (s.email.enabled && (!s.email.host || !s.email.from || !s.email.to.length)) throw new HttpError(400, 'Email needs an SMTP server, a sender address and at least one recipient.');
  if (s.teams.enabled && !s.teams.url) throw new HttpError(400, 'Enter the Teams webhook address.');
  if (s.webhook.enabled && !s.webhook.url) throw new HttpError(400, 'Enter the webhook address.');
  return s;
}

route('PUT', '/api/settings/notifications', async (req, res) => {
  const u = requireAdmin(req);
  const s = readNotificationBody(await readJson(req));
  setSetting('notifications', JSON.stringify(s));
  const channels = ['email', 'teams', 'webhook'].filter((c) => s[c].enabled);
  audit(req, u, 'settings.notifications_updated', `${channels.length ? channels.join(', ') : 'all channels off'}; minimum severity ${s.minSeverity}`);
  send(res, 200, { ok: true });
});

route('POST', '/api/settings/notifications/test', async (req, res) => {
  const u = requireAdmin(req);
  const s = notificationSettings();
  if (!s.email.enabled && !s.teams.enabled && !s.webhook.enabled) throw new HttpError(400, 'Turn on at least one channel and save first.');
  const results = await notifier.test(s);
  audit(req, u, 'settings.notifications_tested', Object.entries(results).map(([k, v]) => `${k}: ${v.ok ? 'ok' : v.error}`).join('; '));
  send(res, 200, results);
});

// ---------------------------------------------------------------- settings: agent updates

route('GET', '/api/settings/agent-updates', async (req, res) => {
  requireAdmin(req);
  const release = agentRelease();
  const versions = db.prepare('SELECT agent_version, COUNT(*) AS n FROM agents GROUP BY agent_version').all();
  const outdated = versions.filter((v) => v.agent_version && release.version && compareVersions(release.version, v.agent_version) > 0)
    .reduce((s, v) => s + v.n, 0);
  send(res, 200, {
    enabled: agentAutoUpdate(), version: release.version, outdated,
    total: versions.reduce((s, v) => s + v.n, 0),
    versions: versions.map((v) => ({ version: v.agent_version || 'unknown', count: v.n })),
  });
});

route('PUT', '/api/settings/agent-updates', async (req, res) => {
  const u = requireAdmin(req);
  const { enabled } = await readJson(req);
  setSetting('agentAutoUpdate', enabled ? 'on' : 'off');
  audit(req, u, enabled ? 'settings.agent_auto_update_on' : 'settings.agent_auto_update_off');
  send(res, 200, { enabled: !!enabled });
});

// ---------------------------------------------------------------- settings: uninstall protection

route('GET', '/api/settings/uninstall', async (req, res) => {
  requireAdmin(req);
  const p = uninstallProtection();
  send(res, 200, { enabled: !!p.enabled, updatedAt: p.updatedAt || null, updatedBy: p.updatedBy || null });
});

route('POST', '/api/settings/uninstall', async (req, res) => {
  const u = requireAdmin(req);
  const { enabled, code } = await readJson(req);
  let value = { enabled: false };
  if (enabled) {
    const c = String(code || '');
    if (c.length < 8 || !/[A-Za-z]/.test(c) || !/\d/.test(c)) throw new HttpError(400, 'Use an uninstall code of at least 8 characters with letters and numbers.');
    const salt = crypto.randomBytes(16).toString('hex');
    value = { enabled: true, salt, hash: sha256(`${salt}:${c}`) };
  }
  setSetting('uninstallProtection', JSON.stringify({ ...value, updatedAt: Date.now(), updatedBy: u.username }));
  audit(req, u, enabled ? 'settings.uninstall_protection_enabled' : 'settings.uninstall_protection_disabled');
  send(res, 200, { enabled: !!enabled });
});

route('GET', '/api/alerts', async (req, res) => {
  requireAdmin(req);
  const status = new URL(req.url, 'http://x').searchParams.get('status') || 'open';
  const where = status === 'open' ? 'WHERE al.resolved_at IS NULL' : status === 'resolved' ? 'WHERE al.resolved_at IS NOT NULL' : '';
  const rows = db.prepare(
    `SELECT al.*, ag.hostname FROM alerts al JOIN agents ag ON ag.id = al.agent_id ${where}
     ORDER BY al.resolved_at IS NOT NULL, al.updated_at DESC LIMIT 500`
  ).all();
  send(res, 200, rows);
});

route('POST', '/api/alerts/:id/ack', async (req, res, p) => {
  const u = requireAdmin(req);
  const now = Date.now();
  db.prepare('UPDATE alerts SET acknowledged_by = ?, acknowledged_at = ? WHERE id = ?').run(u.username, now, Number(p.id));
  // Event alerts (attacks, detections) have no "fixed" condition; acknowledging closes them.
  db.prepare("UPDATE alerts SET resolved_at = ? WHERE id = ? AND type LIKE 'evt\\_%' ESCAPE '\\' AND resolved_at IS NULL").run(now, Number(p.id));
  audit(req, u, 'alert.acknowledged', `#${p.id}`);
  send(res, 200, { ok: true });
});

// ---------------------------------------------------------------- protection: events, policies, blocklist

route('GET', '/api/events', async (req, res) => {
  requireAdmin(req);
  const sp = new URL(req.url, 'http://x').searchParams;
  const sev = sp.get('severity');
  const where = [];
  const args = [];
  if (sev && SEVERITY_RANK[sev]) { where.push('e.severity = ?'); args.push(sev); }
  if (sp.get('blocked') === '1') where.push('e.blocked = 1');
  const rows = db.prepare(
    `SELECT e.*, ag.hostname FROM events e JOIN agents ag ON ag.id = e.agent_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY e.ts DESC LIMIT 500`
  ).all(...args);
  send(res, 200, rows);
});

route('GET', '/api/policies', async (req, res) => {
  requireAdmin(req);
  // Endpoints counted by the policy they actually receive (group policy or override).
  const lk = lookups();
  const counts = new Map();
  for (const a of db.prepare('SELECT group_id, policy_override FROM agents').all()) {
    const pid = (a.policy_override && lk.policies.has(a.policy_override)) ? a.policy_override : (lk.groups.get(a.group_id)?.policy_id || 1);
    counts.set(pid, (counts.get(pid) || 0) + 1);
  }
  const groupsByPolicy = new Map();
  for (const g of lk.groups.values()) groupsByPolicy.set(g.policy_id, [...(groupsByPolicy.get(g.policy_id) || []), g.name]);
  const rows = db.prepare('SELECT * FROM policies ORDER BY id').all().map((p) => ({
    id: p.id, name: p.name, description: p.description, updatedAt: p.updated_at, updatedBy: p.updated_by,
    settings: sanitizePolicy(JSON.parse(p.settings)), endpoints: counts.get(p.id) || 0, groups: groupsByPolicy.get(p.id) || [],
  }));
  send(res, 200, {
    policies: rows, asrRules: ASR_RULES, isolateTriggers: AUTO_ISOLATE_TRIGGERS, websitePresets: WEBSITE_PRESETS,
    defaults: defaultPolicySettings(),
  });
});

function readPolicyBody(body) {
  const name = String(body.name || '').trim().slice(0, 60);
  if (!name) throw new HttpError(400, 'Policy name is required');
  const { invalid } = normalizeSites(body.settings?.webFilter?.blockedSites);
  if (invalid.length) throw new HttpError(400, `Not valid website(s): ${invalid.slice(0, 5).join(', ')}`);
  const od = body.settings?.recovery?.oneDrive;
  if (od?.enabled && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(od.tenantId || '').trim())) {
    throw new HttpError(400, 'OneDrive folder protection needs your Microsoft 365 tenant ID (a GUID, found in the Entra admin center under Overview).');
  }
  return { name, description: String(body.description || '').slice(0, 200), settings: sanitizePolicy(body.settings) };
}

route('POST', '/api/policies', async (req, res) => {
  const u = requireAdmin(req);
  const p = readPolicyBody(await readJson(req));
  if (db.prepare('SELECT 1 FROM policies WHERE name = ?').get(p.name)) throw new HttpError(400, 'A policy with that name exists');
  const r = db.prepare('INSERT INTO policies (name, description, settings, updated_at, updated_by) VALUES (?, ?, ?, ?, ?)')
    .run(p.name, p.description, JSON.stringify(p.settings), Date.now(), u.username);
  audit(req, u, 'policy.created', p.name);
  send(res, 200, { id: Number(r.lastInsertRowid) });
});

route('PUT', '/api/policies/:id', async (req, res, params) => {
  const u = requireAdmin(req);
  const id = Number(params.id);
  if (!db.prepare('SELECT 1 FROM policies WHERE id = ?').get(id)) throw new HttpError(404, 'Policy not found');
  const p = readPolicyBody(await readJson(req));
  if (db.prepare('SELECT 1 FROM policies WHERE name = ? AND id <> ?').get(p.name, id)) throw new HttpError(400, 'A policy with that name exists');
  db.prepare('UPDATE policies SET name = ?, description = ?, settings = ?, updated_at = ?, updated_by = ? WHERE id = ?')
    .run(p.name, p.description, JSON.stringify(p.settings), Date.now(), u.username, id);
  audit(req, u, 'policy.updated', p.name);
  send(res, 200, { ok: true });
});

route('DELETE', '/api/policies/:id', async (req, res, params) => {
  const u = requireAdmin(req);
  const id = Number(params.id);
  if (id === 1) throw new HttpError(400, 'The Default policy cannot be deleted');
  const pol = db.prepare('SELECT name FROM policies WHERE id = ?').get(id);
  if (!pol) throw new HttpError(404, 'Policy not found');
  db.prepare('UPDATE endpoint_groups SET policy_id = 1 WHERE policy_id = ?').run(id);
  db.prepare('UPDATE agents SET policy_override = NULL WHERE policy_override = ?').run(id);
  db.prepare('DELETE FROM policies WHERE id = ?').run(id);
  audit(req, u, 'policy.deleted', pol.name);
  send(res, 200, { ok: true });
});

// ---------------------------------------------------------------- endpoint groups API

function groupRows() {
  const lk = lookups();
  const members = new Map(db.prepare('SELECT group_id, COUNT(*) AS n, SUM(CASE WHEN last_seen >= ? THEN 1 ELSE 0 END) AS online FROM agents GROUP BY group_id')
    .all(Date.now() - config.offlineAfterMin * 60 * 1000).map((r) => [r.group_id, r]));
  const overrides = new Map(db.prepare('SELECT group_id, COUNT(*) AS n FROM agents WHERE policy_override IS NOT NULL GROUP BY group_id')
    .all().map((r) => [r.group_id, r.n]));
  return db.prepare('SELECT * FROM endpoint_groups ORDER BY id = 1 DESC, priority, name COLLATE NOCASE').all().map((g) => ({
    id: g.id, name: g.name, description: g.description, priority: g.priority,
    policyId: g.policy_id, policyName: lk.policies.get(g.policy_id)?.name || 'Default',
    rules: sanitizeRules(parse(g.rules, {})), endpoints: members.get(g.id)?.n || 0, online: members.get(g.id)?.online || 0,
    overrides: overrides.get(g.id) || 0, isDefault: g.id === 1,
  }));
}

route('GET', '/api/groups', async (req, res) => {
  requireAdmin(req);
  send(res, 200, { groups: groupRows(), types: Object.values(AGENT_TYPES) });
});

function readGroupBody(body, id = null) {
  const name = String(body.name || '').trim().slice(0, 60);
  if (!name) throw new HttpError(400, 'Group name is required');
  if (db.prepare('SELECT 1 FROM endpoint_groups WHERE name = ? AND id IS NOT ?').get(name, id)) throw new HttpError(400, 'A group with that name exists');
  const pol = db.prepare('SELECT id FROM policies WHERE id = ?').get(Number(body.policyId));
  if (!pol) throw new HttpError(400, 'Choose a protection policy for the group');
  return {
    name, description: String(body.description || '').slice(0, 200), policyId: pol.id,
    rules: id === 1 ? { types: [], hostnames: [] } : sanitizeRules(body.rules),
    priority: Math.min(999, Math.max(1, Math.round(Number(body.priority)) || 100)),
  };
}

route('POST', '/api/groups', async (req, res) => {
  const u = requireAdmin(req);
  const g = readGroupBody(await readJson(req));
  const r = db.prepare('INSERT INTO endpoint_groups (name, description, policy_id, rules, priority, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(g.name, g.description, g.policyId, JSON.stringify(g.rules), g.priority, Date.now(), Date.now());
  audit(req, u, 'group.created', g.name);
  send(res, 200, { id: Number(r.lastInsertRowid) });
});

route('PUT', '/api/groups/:id', async (req, res, p) => {
  const u = requireAdmin(req);
  const id = Number(p.id);
  if (!db.prepare('SELECT 1 FROM endpoint_groups WHERE id = ?').get(id)) throw new HttpError(404, 'Group not found');
  const g = readGroupBody(await readJson(req), id);
  db.prepare('UPDATE endpoint_groups SET name = ?, description = ?, policy_id = ?, rules = ?, priority = ?, updated_at = ? WHERE id = ?')
    .run(g.name, g.description, g.policyId, JSON.stringify(g.rules), id === 1 ? 1000 : g.priority, Date.now(), id);
  audit(req, u, 'group.updated', g.name);
  send(res, 200, { ok: true });
});

route('DELETE', '/api/groups/:id', async (req, res, p) => {
  const u = requireAdmin(req);
  const id = Number(p.id);
  if (id === 1) throw new HttpError(400, 'The Default group cannot be deleted');
  const g = db.prepare('SELECT name FROM endpoint_groups WHERE id = ?').get(id);
  if (!g) throw new HttpError(404, 'Group not found');
  const moved = db.prepare('UPDATE agents SET group_id = 1 WHERE group_id = ?').run(id).changes;
  db.prepare('DELETE FROM endpoint_groups WHERE id = ?').run(id);
  audit(req, u, 'group.deleted', `${g.name} (${moved} endpoint(s) moved to Default)`);
  send(res, 200, { moved });
});

// Move several endpoints into a group at once.
route('POST', '/api/groups/:id/members', async (req, res, p) => {
  const u = requireAdmin(req);
  const g = db.prepare('SELECT id, name FROM endpoint_groups WHERE id = ?').get(Number(p.id));
  if (!g) throw new HttpError(404, 'Group not found');
  const { agentIds } = await readJson(req);
  const ids = (Array.isArray(agentIds) ? agentIds : []).map(String).slice(0, 5000);
  const move = db.prepare('UPDATE agents SET group_id = ? WHERE id = ?');
  let moved = 0;
  for (const id of ids) moved += move.run(g.id, id).changes;
  audit(req, u, 'group.members_moved', `${moved} endpoint(s) -> ${g.name}`);
  send(res, 200, { moved });
});

// Re-run auto-assignment rules for endpoints that are still in the Default group.
route('POST', '/api/groups/apply-rules', async (req, res) => {
  const u = requireAdmin(req);
  const move = db.prepare('UPDATE agents SET group_id = ? WHERE id = ?');
  let moved = 0;
  for (const a of db.prepare('SELECT id, hostname, product_type FROM agents WHERE group_id = 1').all()) {
    const gid = autoAssignGroup(a.hostname, a.product_type);
    if (gid !== 1) { move.run(gid, a.id); moved++; }
  }
  audit(req, u, 'group.rules_applied', `${moved} endpoint(s) moved`);
  send(res, 200, { moved });
});

route('GET', '/api/iocs', async (req, res) => {
  requireAdmin(req);
  send(res, 200, db.prepare('SELECT * FROM iocs ORDER BY id DESC').all());
});

route('POST', '/api/iocs', async (req, res) => {
  const u = requireAdmin(req);
  const body = await readJson(req);
  const type = String(body.type || '');
  // Accept several values at once (one per line) for bulk import of threat feeds.
  const values = String(body.value || '').split(/[\r\n,;]+/).map((s) => s.trim()).filter(Boolean).slice(0, 1000);
  if (!values.length) throw new HttpError(400, 'Enter at least one value');
  const insert = db.prepare('INSERT OR IGNORE INTO iocs (type, value, description, created_by, created_at) VALUES (?, ?, ?, ?, ?)');
  let added = 0;
  for (const v of values) {
    let clean;
    try { clean = normalizeIoc(type, v); } catch (e) { throw new HttpError(400, `${v}: ${e.message}`); }
    added += insert.run(type, clean, String(body.description || '').slice(0, 200), u.username, Date.now()).changes;
  }
  audit(req, u, 'ioc.added', `${type}: ${values.length > 3 ? values.length + ' values' : values.join(', ')}`);
  send(res, 200, { added });
});

route('DELETE', '/api/iocs/:id', async (req, res, params) => {
  const u = requireAdmin(req);
  const row = db.prepare('SELECT * FROM iocs WHERE id = ?').get(Number(params.id));
  if (!row) throw new HttpError(404, 'Not found');
  db.prepare('DELETE FROM iocs WHERE id = ?').run(row.id);
  audit(req, u, 'ioc.removed', `${row.type}: ${row.value}`);
  send(res, 200, { ok: true });
});

function serverUrl(req) {
  if (config.publicUrl) return config.publicUrl.replace(/\/$/, '');
  return `${viaHttps(req) ? 'https' : 'http'}://${req.headers.host}`;
}

// ---------------------------------------------------------------- settings: server address and remote access

route('GET', '/api/settings/server', async (req, res) => {
  requireAdmin(req);
  send(res, 200, {
    publicUrl: config.publicUrl || '', detectedUrl: `${viaHttps(req) ? 'https' : 'http'}://${req.headers.host}`,
    adminAllowedIps: config.adminAllowedIps || [], yourIp: clientIp(req), trustProxy: !!config.trustProxy,
    tls: useTls,
  });
});

route('PUT', '/api/settings/server', async (req, res) => {
  const u = requireAdmin(req);
  const body = await readJson(req);
  const url = String(body.publicUrl || '').trim().replace(/\/+$/, '');
  if (url && !/^https?:\/\/[a-z0-9.-]+(:\d{1,5})?$/i.test(url)) {
    throw new HttpError(400, 'Enter the address as https://name-or-ip[:port], without a path, e.g. https://shield360.example.com:8443');
  }
  if (/^https?:\/\/(localhost|127\.|\[?::1)/i.test(url)) throw new HttpError(400, 'localhost only works on the server itself. Use the name or IP address the endpoints can reach.');
  const ips = (Array.isArray(body.adminAllowedIps) ? body.adminAllowedIps : String(body.adminAllowedIps || '').split(/[\s,]+/))
    .map((s) => String(s).trim()).filter(Boolean).slice(0, 100);
  for (const ip of ips) if (!isIp(ip)) throw new HttpError(400, `Not a valid IP address or range: ${ip}`);
  const trustProxy = body.trustProxy === undefined ? !!config.trustProxy : !!body.trustProxy;
  // Never let an administrator lock themselves out from where they are working now
  // (judged the way the server will see this browser after the change).
  const before = config.trustProxy;
  config.trustProxy = trustProxy;
  const me = clientIp(req);
  config.trustProxy = before;
  if (ips.length && !isLoopback(me) && !ips.some((r) => ipMatches(me, r))) {
    throw new HttpError(400, `Your current address (${me}) is not in the list, so you would lock yourself out. Add it, or make this change on the server itself.`);
  }
  config.publicUrl = url;
  config.adminAllowedIps = ips;
  config.trustProxy = trustProxy;
  saveConfig(config);
  audit(req, u, 'settings.server_updated', `public address: ${url || '(automatic)'}; console allowed from: ${ips.length ? ips.join(', ') : 'anywhere'}; behind proxy: ${trustProxy ? 'yes' : 'no'}`);
  send(res, 200, { ok: true });
});

route('GET', '/api/deploy', async (req, res) => {
  requireAdmin(req);
  send(res, 200, {
    serverUrl: serverUrl(req),
    publicUrlSet: !!config.publicUrl,
    localOnly: /^https?:\/\/(localhost|127\.|\[?::1)/i.test(serverUrl(req)),
    enrollToken: config.enrollToken,
    files: AGENT_FILES,
    hasCertificate: fs.existsSync(path.join(DATA_DIR, 'server.cer')),
    license: (({ seats, seatsUsed, seatsFree, canEnroll, message }) => ({ seats, seatsUsed, seatsFree, canEnroll, message }))(licensing.status()),
  });
});

route('POST', '/api/deploy/rotate-token', async (req, res) => {
  const u = requireAdmin(req);
  config.enrollToken = newEnrollToken();
  saveConfig(config);
  audit(req, u, 'enroll_token.rotated');
  send(res, 200, { enrollToken: config.enrollToken });
});

route('GET', '/api/audit', async (req, res) => {
  requireAdmin(req);
  send(res, 200, db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 300').all());
});

// ---------------------------------------------------------------- virus definitions

// Large binary; only enrolled agents may download it.
route('GET', '/api/agent/definitions/:arch', async (req, res, p) => {
  requireAgent(req);
  const file = DEFINITION_ARCHES.includes(p.arch) ? mirror.fileFor(p.arch) : null;
  if (!file || !fs.existsSync(file)) throw new HttpError(404, 'Definitions for this architecture are not mirrored');
  res.writeHead(200, {
    ...SECURITY_HEADERS, 'Content-Type': 'application/octet-stream', 'Content-Length': fs.statSync(file).size,
    'Content-Disposition': 'attachment; filename="mpam-fe.exe"',
  });
  fs.createReadStream(file).pipe(res);
});

function definitionRows() {
  const pkgs = mirror.status().packages;
  const rows = db.prepare('SELECT * FROM agents ORDER BY hostname COLLATE NOCASE').all().map((a) => {
    const d = parse(a.state, {}).security?.defender || {};
    return {
      id: a.id, hostname: a.hostname, online: !!isOnline(a), defender: !!d.present && d.mode !== 'Passive Mode',
      signatureVersion: d.signatureVersion || null, signatureUpdated: d.signatureUpdated || null,
      signatureAgeDays: d.signatureAgeDays ?? null, engineVersion: d.engineVersion || null,
    };
  });
  // "Latest" = newest version known anywhere: the mirror or any endpoint.
  let latest = null;
  for (const v of [...Object.values(pkgs).map((x) => x.version), ...rows.map((r) => r.signatureVersion)]) {
    if (v && (!latest || compareVersions(v, latest) > 0)) latest = v;
  }
  for (const r of rows) {
    r.status = !r.defender ? 'n/a' : !r.signatureVersion ? 'unknown'
      : compareVersions(r.signatureVersion, latest) >= 0 ? 'latest'
      : r.signatureAgeDays > config.thresholds.signatureAgeDays ? 'outdated' : 'behind';
  }
  return { latest, rows };
}

route('GET', '/api/definitions', async (req, res) => {
  requireAdmin(req);
  send(res, 200, { mirror: mirror.status(), ...definitionRows() });
});

route('POST', '/api/definitions/refresh', async (req, res) => {
  const u = requireAdmin(req);
  audit(req, u, 'definitions.mirror_refresh');
  mirror.refresh();   // can take minutes; the page polls status
  send(res, 202, { started: true });
});

route('POST', '/api/definitions/update-all', async (req, res) => {
  const u = requireAdmin(req);
  const { onlyOutdated } = await readJson(req);
  const { rows } = definitionRows();
  const targets = rows.filter((r) => r.defender && (!onlyOutdated || r.status !== 'latest'));
  const insert = db.prepare(
    "INSERT INTO commands (agent_id, action, params, created_by, created_at) VALUES (?, 'defender_update_signatures', '{}', ?, ?)"
  );
  const alreadyQueued = db.prepare(
    "SELECT 1 FROM commands WHERE agent_id = ? AND action = 'defender_update_signatures' AND status IN ('pending','sent')"
  );
  let queued = 0;
  for (const t of targets) {
    if (alreadyQueued.get(t.id)) continue;
    insert.run(t.id, u.username, Date.now());
    queued++;
  }
  audit(req, u, 'definitions.update_all', `${queued} endpoint(s)`);
  send(res, 200, { queued });
});

// ---------------------------------------------------------------- downloads & static

route('GET', '/download/:file', async (req, res, p) => {
  const name = decodeURIComponent(p.file);
  let file = null;
  if (AGENT_FILES.includes(name)) file = path.join(AGENT_DIR, name);
  else if (name === 'server.cer') file = path.join(DATA_DIR, 'server.cer');
  if (!file || !fs.existsSync(file)) throw new HttpError(404, 'Not found');
  send(res, 200, fs.readFileSync(file), {
    'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
    'Content-Disposition': `attachment; filename="${name}"`,
  });
});

function serveStatic(req, res) {
  let rel = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (rel === '/' || !path.extname(rel)) rel = '/index.html';
  const file = path.resolve(PUBLIC_DIR, '.' + rel);
  if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return send(res, 404, 'Not found');
  }
  send(res, 200, fs.readFileSync(file), { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
}

// In restricted mode (expired license/trial) configuration changes are refused. Still allowed: agents,
// sign-in, password and license management, acknowledging alerts and response actions on endpoints,
// so an administrator can always contain an incident.
const ALLOWED_WHEN_RESTRICTED = /^\/api\/(login|logout|account\/|license$|agent\/|alerts\/\d+\/ack$|agents\/[^/]+\/commands$|agents\/bulk-commands$)/;

function checkLicenseForChange(req, pathname) {
  if (req.method === 'GET' || req.method === 'HEAD' || !pathname.startsWith('/api/')) return;
  if (ALLOWED_WHEN_RESTRICTED.test(pathname)) return;
  const lic = licensing.status();
  if (lic.restricted) throw new HttpError(403, `${lic.message} Install a license on the License page.`);
}

async function handle(req, res) {
  const pathname = new URL(req.url, 'http://x').pathname;
  try {
    if (!AGENT_PATHS.test(pathname) && !adminNetworkAllowed(req)) {
      if (pathname.startsWith('/api/')) throw new HttpError(403, 'The Shield360 console is not available from this network.');
      return send(res, 403, 'The Shield360 console is not available from this network.');
    }
    checkLicenseForChange(req, pathname);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(pathname);
      if (!m) continue;
      const params = Object.fromEntries(r.keys.map((k, i) => [k, m[i + 1]]));
      return await r.handler(req, res, params);
    }
    if (pathname.startsWith('/api/')) throw new HttpError(404, 'Not found');
    if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
    serveStatic(req, res);
  } catch (err) {
    const status = err.status || 500;
    if (status === 500) console.error(`[error] ${req.method} ${pathname}`, err);
    if (!res.headersSent) send(res, status, { error: status === 500 ? 'Internal server error' : err.message });
  }
}

// ---------------------------------------------------------------- start

function tlsOptions() {
  if (config.tls.pfx) {
    return { pfx: fs.readFileSync(path.resolve(ROOT, config.tls.pfx)), passphrase: config.tls.passphrase || undefined };
  }
  return { cert: fs.readFileSync(path.resolve(ROOT, config.tls.cert)), key: fs.readFileSync(path.resolve(ROOT, config.tls.key)) };
}

const server = useTls ? https.createServer(tlsOptions(), handle) : http.createServer(handle);
server.on('error', (e) => {
  console.error(`Cannot listen on ${config.host}:${config.port}: ${e.code === 'EADDRINUSE' ? 'the port is already in use by another program' : e.message}`);
  process.exit(1);
});
server.listen(config.port, config.host, () => {
  console.log(`Shield360 Endpoint server ${VERSION} listening on ${useTls ? 'https' : 'http'}://${config.host}:${config.port}`);
  if (!useTls) console.log('[warn] TLS is not configured. Use HTTPS in production (see README).');
});

mirror.start();
alerting.sweep();
setInterval(() => {
  try { alerting.sweep(); } catch (e) { console.error('[sweep]', e); }
}, 60 * 1000).unref();
