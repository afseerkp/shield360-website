#Requires -Version 5.1
<#
.SYNOPSIS
    Installs the Shield360 server (API and worker) as two Windows services.

.DESCRIPTION
    Run from an elevated PowerShell. The package folder holds the published output:
        package\api\       Shield360.Api.exe and its files (including the console in wwwroot)
        package\worker\    Shield360.Worker.exe and its files
        package\agent\     the agent files the server hands out
    The server keeps its data in PostgreSQL 16 or newer (TimescaleDB is optional). Create an empty database and a
    login for it first, then pass the connection string. The first start creates the tables and the admin account;
    the initial password is printed at the end.

    Upgrading: run it again with the same parameters. Program files are replaced, settings rewritten (the
    organisation id is kept), data stays in PostgreSQL.

.EXAMPLE
    .\Install-Shield360Server.ps1 -Connection "Host=localhost;Database=shield360;Username=shield360;Password=..."
    .\Install-Shield360Server.ps1 -Connection "..." -Port 8443 -CertificatePath C:\certs\shield360.pfx -CertificatePassword ...
    .\Install-Shield360Server.ps1 -Uninstall
#>
[CmdletBinding()]
param(
    [string]$Connection,
    [string]$PackageDir = (Join-Path $PSScriptRoot 'package'),
    [string]$InstallDir = (Join-Path $env:ProgramFiles 'Shield360'),
    [string]$DataDir = (Join-Path $env:ProgramData 'Shield360'),
    [int]$Port = 8080,
    [string]$CertificatePath,
    [string]$CertificatePassword,
    [switch]$Uninstall,
    # Keep the services running as SYSTEM instead of their own low-privilege accounts.
    [switch]$RunAsLocalSystem
)

$ErrorActionPreference = 'Stop'
$Services = @(
    @{ Name = 'Shield360Server'; Display = 'Shield360 Server'; Folder = 'api'; Exe = 'Shield360.Api.exe' },
    @{ Name = 'Shield360Worker'; Display = 'Shield360 Worker'; Folder = 'worker'; Exe = 'Shield360.Worker.exe' }
)
$FirewallRule = 'Shield360 Server'

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated (Administrator) PowerShell.'
}

# The worker stops first so nothing writes while the API goes down.
function Stop-Shield360Services {
    foreach ($s in @($Services[1], $Services[0])) {
        if (Get-Service -Name $s.Name -ErrorAction SilentlyContinue) { Stop-Service -Name $s.Name -Force -ErrorAction SilentlyContinue }
    }
}

if ($Uninstall) {
    Stop-Shield360Services
    foreach ($s in $Services) { if (Get-Service -Name $s.Name -ErrorAction SilentlyContinue) { & sc.exe delete $s.Name | Out-Null } }
    Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
    Write-Host 'Shield360 services and firewall rule removed. Program files and the database are kept.'
    Write-Host "To remove the files: Remove-Item '$InstallDir' -Recurse. Server files are in '$DataDir'; the data is in PostgreSQL."
    return
}

if (-not $Connection) { throw 'Give -Connection, the PostgreSQL connection string for an empty database.' }
foreach ($s in $Services) {
    if (-not (Test-Path (Join-Path $PackageDir "$($s.Folder)\$($s.Exe)"))) { throw "Package incomplete: $($s.Folder)\$($s.Exe) not found in $PackageDir" }
}
if ($CertificatePath -and -not (Test-Path $CertificatePath)) { throw "Certificate not found: $CertificatePath" }

# Restricts a file or folder to SYSTEM and Administrators (settings hold the database password).
function Protect-Shield360Path([string]$Path) {
    $isDir = Test-Path -LiteralPath $Path -PathType Container
    $grant = if ($isDir) { @('*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F') } else { @('*S-1-5-18:F', '*S-1-5-32-544:F') }
    & icacls.exe $Path /inheritance:r /grant:r $grant /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Failed to set permissions on $Path" }
}

Stop-Shield360Services

New-Item -ItemType Directory -Force $InstallDir, $DataDir | Out-Null
foreach ($s in $Services) {
    $target = Join-Path $InstallDir $s.Folder
    New-Item -ItemType Directory -Force $target | Out-Null
    Copy-Item -Path (Join-Path $PackageDir "$($s.Folder)\*") -Destination $target -Recurse -Force
}
$agentTarget = Join-Path $InstallDir 'agent'
if (Test-Path (Join-Path $PackageDir 'agent')) {
    New-Item -ItemType Directory -Force $agentTarget | Out-Null
    Copy-Item -Path (Join-Path $PackageDir 'agent\*') -Destination $agentTarget -Recurse -Force
}

# One organisation id for the life of the installation: an upgrade reuses the one already written.
$apiSettings = Join-Path $InstallDir 'api\appsettings.Production.json'
$orgId = $null
if (Test-Path $apiSettings) { $orgId = (Get-Content $apiSettings -Raw | ConvertFrom-Json).Shield360.DefaultOrgId }
if (-not $orgId) { $orgId = [guid]::NewGuid().ToString() }

$agents = @{ DataDirectory = $DataDir; AgentDirectory = $agentTarget }
$common = @{
    ConnectionStrings = @{ Shield360 = $Connection }
    Shield360 = @{ DefaultOrgId = $orgId; MigrateOnStartup = $true; Agents = $agents }
}
$api = $common.Clone()
$api.Kestrel = if ($CertificatePath) {
    @{ Endpoints = @{ Https = @{ Url = "https://0.0.0.0:$Port"; Certificate = @{ Path = $CertificatePath; Password = $CertificatePassword } } } }
} else {
    @{ Endpoints = @{ Http = @{ Url = "http://0.0.0.0:$Port" } } }
}
foreach ($s in $Services) {
    $path = Join-Path $InstallDir "$($s.Folder)\appsettings.Production.json"
    $content = if ($s.Folder -eq 'api') { $api } else { $common }
    ($content | ConvertTo-Json -Depth 8) | Set-Content -Path $path -Encoding UTF8
    Protect-Shield360Path $path
}
New-Item -ItemType Directory -Force $DataDir | Out-Null
Protect-Shield360Path $DataDir

foreach ($s in $Services) {
    $folder = Join-Path $InstallDir $s.Folder
    $binary = "`"$(Join-Path $folder $s.Exe)`" --environment Production --contentRoot `"$folder`""
    if (Get-Service -Name $s.Name -ErrorAction SilentlyContinue) { & sc.exe config $s.Name binPath= $binary start= delayed-auto | Out-Null }
    else {
        New-Service -Name $s.Name -DisplayName $s.Display -BinaryPathName $binary -StartupType Automatic | Out-Null
        & sc.exe config $s.Name start= delayed-auto | Out-Null
    }
    # Restart after a failure: after 5 s, 30 s, then 60 s; the failure count resets after a day.
    & sc.exe failure $s.Name reset= 86400 actions= restart/5000/restart/30000/restart/60000 | Out-Null

    # Each service runs as its own virtual account (NT SERVICE\<name>) instead of SYSTEM, so a fault in the
    # network-facing server can't act as the machine. The account gets read access to its program folder and
    # settings, write access to the data folder, and read access to the certificate.
    if (-not $RunAsLocalSystem) {
        $account = "NT SERVICE\$($s.Name)"
        & sc.exe config $s.Name obj= $account | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Failed to set the account for $($s.Name)" }
        # The services log to the Application event log under their display name; only an administrator can create that source.
        if (-not [Diagnostics.EventLog]::SourceExists($s.Display)) { New-EventLog -LogName Application -Source $s.Display }
        $grants = @(
            @{ Path = $folder; Right = '(OI)(CI)RX' }
            @{ Path = (Join-Path $folder 'appsettings.Production.json'); Right = 'R' }
            @{ Path = $DataDir; Right = '(OI)(CI)M' }
        )
        if ($s.Folder -eq 'api' -and (Test-Path $agentTarget)) { $grants += @{ Path = $agentTarget; Right = '(OI)(CI)RX' } }
        if ($CertificatePath -and $s.Folder -eq 'api') { $grants += @{ Path = $CertificatePath; Right = 'R' } }
        foreach ($g in $grants) {
            & icacls.exe $g.Path /grant "$($account):$($g.Right)" /Q | Out-Null
            if ($LASTEXITCODE -ne 0) { throw "Failed to grant $account access to $($g.Path)" }
        }
    } else {
        & sc.exe config $s.Name obj= LocalSystem | Out-Null
    }
}

Remove-NetFirewallRule -DisplayName $FirewallRule -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $FirewallRule -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow | Out-Null

# The API starts first (it creates the tables); the worker starts once the API is ready.
Start-Service -Name $Services[0].Name
$scheme = if ($CertificatePath) { 'https' } else { 'http' }
$ready = $false
for ($i = 0; $i -lt 60 -and -not $ready; $i++) {
    Start-Sleep -Seconds 1
    try {
        # A self-signed certificate is fine for this local check.
        if ($scheme -eq 'https' -and $PSVersionTable.PSVersion.Major -lt 6) { [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } }
        $request = @{ Uri = "$($scheme)://localhost:$Port/health/ready"; UseBasicParsing = $true; TimeoutSec = 3 }
        if ($PSVersionTable.PSVersion.Major -ge 6) { $request.SkipCertificateCheck = $true }
        $ready = (Invoke-WebRequest @request).StatusCode -eq 200
    } catch { $ready = $false }
}
Write-Host ''
if (-not $ready) {
    Write-Host "The Shield360 server did not become ready on port $Port." -ForegroundColor Red
    Write-Host 'Check the connection string and the Windows event log (Application, source "Shield360 Server").'
    throw 'Shield360 server failed to start.'
}
Start-Service -Name $Services[1].Name
Write-Host "Shield360 server running: $($scheme)://$($env:COMPUTERNAME):$Port" -ForegroundColor Green
if (-not $CertificatePath) {
    Write-Warning 'The server is listening on plain HTTP: passwords and sign-in cookies cross the network unencrypted. Re-run with -CertificatePath (and -CertificatePassword), or put an HTTPS reverse proxy in front of it.'
}

# The initial admin sign-in exists until the administrator changes the password at first sign-in.
$pwFile = Join-Path $DataDir 'initial-admin-password.txt'
if (Test-Path $pwFile) {
    $lines = Get-Content $pwFile
    $user = ($lines | Where-Object { $_ -like 'username:*' } | Select-Object -First 1) -replace '^username:\s*', ''
    $pass = ($lines | Where-Object { $_ -like 'password:*' } | Select-Object -First 1) -replace '^password:\s*', ''
    if ($user -and $pass) {
        Write-Host ''
        Write-Host '  ================ Initial admin sign-in ================' -ForegroundColor Yellow
        Write-Host "    Username : $user" -ForegroundColor Yellow
        Write-Host "    Password : $pass" -ForegroundColor Yellow
        Write-Host '  =======================================================' -ForegroundColor Yellow
        Write-Host '  You must choose a new password at first sign-in; this one then stops working.'
    }
}
